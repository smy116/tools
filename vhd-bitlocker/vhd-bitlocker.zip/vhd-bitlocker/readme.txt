Windows VHDX + BitLocker 管理工具
===================================

这个工具用于在 Windows 上通过交互式主菜单管理一个固定 VHDX 虚拟磁盘及其 BitLocker 加密卷：

- 实时展示镜像文件、挂载状态、盘符与 BitLocker 锁定状态、本地密码状态、卸载策略及开机自启状态。
- 支持在主菜单中选择：挂载并解锁、锁定并卸载、密码维护、备份 VHDX 卷、开机自启动维护（自动解密挂载）、刷新状态。
- 支持将 VHDX 镜像与便携版 rclone 同步套件一并备份到 U 盘/外部目录，随时在任意电脑挂载解锁并 rclone sync 导出文件。
- 支持通过命令行参数直接执行一键开关、挂载、卸载、备份、密码维护或开机自启动管理（适合创建快捷方式或脚本调用）。

文件说明
--------

- start.cmd
  唯一双击入口。优先调用 PowerShell 7（pwsh.exe），未安装时自动回退到 Windows PowerShell 5.1；
  双击后申请管理员权限并打开交互式主菜单，同时透传命令行参数给核心脚本。

- vhd-bitlocker.ps1
  核心 PowerShell 脚本（UTF-8 with BOM 编码，同时兼容 PowerShell 7 与 Windows PowerShell 5.1）。一般不需要修改。

- config.ini
  统一配置文件（UTF-8 编码，支持中文路径与带双引号的路径）。VHDX 路径、镜像类型、
  密码密文、安全卸载开关、等待时间、系统通知开关都在这里。

- rclone-sync\
  rclone 同步套件目录，可在本机直接运行；执行「备份 VHDX 卷」时会将其中的脚本与程序直接
  平铺复制到备份目录（与备份的 VHDX 镜像文件处于同一目录）：
  - rclone.exe        Windows amd64 版 rclone 主程序
  - sync.cmd          同步双击入口（自动提权并调用 sync-vhdx.ps1）
  - sync-vhdx.ps1     核心同步脚本（挂载 -> 解锁 BitLocker -> rclone sync -> 自动卸载）
  - sync-config.ini   同步配置文件，持久化保存同步目标目录与排除路径规则

主菜单功能
----------

双击 start.cmd 并通过 UAC 管理员授权后，将进入交互式主菜单：

1. 顶部状态面板
   - 镜像文件：显示目标路径以及文件是否存在
   - 挂载状态：显示未挂载，或已挂载及对应磁盘号
   - 卷与加密：显示各卷盘符及 BitLocker 状态（已解锁 / 已锁定）
   - 本地密码：显示已保存（可正常解密）/ 已保存（无法解密）/ 未保存
   - 卸载策略：显示当前 SafeUnmountOnly 配置
   - 开机自启：显示 Windows 计划任务是否已启用、暂停、未启用或配置异常

2. 菜单选项
   - [1] 挂载并解锁
     - 未挂载时：挂载 VHDX 并解锁 BitLocker 卷；若解锁失败自动回滚卸载。
     - 已挂载但仍锁定时：直接补解锁 BitLocker 卷（不重复挂载）。
     - 若 config.ini 中未保存密码，会提示单次手动输入密码，不会自动写入 config.ini。
   - [2] 锁定并卸载
     - 严格遵循 config.ini 中的 SafeUnmountOnly 设置执行缓存刷新、锁定卷并卸载 VHDX。
   - [3] 密码维护（二级菜单，仅维护本地 config.ini 密文，不改动磁盘 BitLocker 保护器）
     - [1] 设置 / 更新已保存的密码：输入两次密码并用当前管理员账户 DPAPI 加密写入 config.ini
     - [2] 清除已保存的密码：确认后清空 PasswordSecret，后续挂载改为每次手动输入
     - [3] 校验当前已保存密码是否可读：验证当前账户能否正常解密 PasswordSecret（不显示明文）
     - [0] 返回主菜单
   - [4] 备份 VHDX 卷（含 rclone 同步套件）
     - 自动检测当前 VHDX 是否已挂载；若已挂载，提示并询问是否立即锁定卸载后再继续。
     - 自动扫描所有 USB 存储盘（含 U 盘与 USB 移动硬盘），默认预填 <U盘盘符>:\vhdx-backup，
       支持直接回车采用、多盘编号选择或手动输入任意目录。
     - 复制前检查剩余空间与 FAT32 单文件 4 GB 限制，显示实时复制进度，空间充足时采用临时文件
       原子替换以防中途断电/拔盘损坏旧备份。
     - 将 rclone-sync 目录内的脚本与程序直接复制到 <备份目录>（与备份的 VHDX 镜像同目录），
       并自动将备份版 sync-config.ini 中的 VhdxPath 设为 .\<VHDX文件名>（保留同步目标和排除路径）。
   - [5] 开机自启动维护（自动解密挂载，二级菜单）
     - 基于 Windows 计划任务实现：在当前用户登录时以最高权限（免 UAC 弹窗）静默运行，
       复用当前管理员账户的 DPAPI 密文（PasswordSecret）自动挂载并解锁 BitLocker 卷。
     - [1] 启用 / 更新开机自动解密挂载：校验本地密码前提（未保存时可现场引导保存），配置登录后延迟
       秒数（默认 10 秒，等待磁盘与 BitLocker 服务就绪），并自动检测/修复脚本路径或账户不一致问题。
     - [2] 暂停 / 恢复开机自启动：临时禁用或恢复计划任务，同时保留原有配置。
     - [3] 删除开机自启动任务：确认后彻底移除对应的 Windows 计划任务。
     - [4] 立即测试运行自启动任务：通过计划任务实际触发一次后台运行，并反馈返回码与运行日志。
     - [5] 查看 / 清理自启动运行日志：查看或清空 autostart.log 中的最近执行记录。
     - [0] 返回主菜单
   - [R] 刷新状态
     - 重新读取 config.ini 并刷新磁盘/BitLocker/密码/开机自启状态。
   - [0] / [Q] 退出

命令行直跑模式
--------------

除了双击 start.cmd 打开主菜单外，还可以通过命令行或 Windows 快捷方式直接指定动作：

  start.cmd -Action Toggle            一键切换（未挂载则挂载解锁，已挂载则锁定卸载）
  start.cmd -Action Mount             直接挂载并解锁
  start.cmd -Action Unmount           直接锁定并卸载
  start.cmd -Action Status            输出当前状态
  start.cmd -Action SetPassword       设置 / 更新本地保存的密码
  start.cmd -Action ClearPassword     清除本地保存的密码
  start.cmd -Action TestPassword      校验当前保存密码的可解密性
  start.cmd -Action Backup            备份 VHDX 与 rclone 同步套件（可附加 -BackupPath "E:\vhdx-backup"）
  start.cmd -Action AutoMount         无人值守自动解密挂载（供开机自启计划任务调用，写入 autostart.log）
  start.cmd -Action EnableAutoStart   启用 / 更新开机自启动（可附加 -DelaySeconds 10）
  start.cmd -Action DisableAutoStart  暂停（禁用）开机自启动任务
  start.cmd -Action RemoveAutoStart   删除开机自启动任务
  start.cmd -Action AutoStartStatus   输出当前开机自启动状态

rclone 同步套件使用说明（rclone-sync\sync.cmd）
-----------------------------------------------

rclone-sync 文件夹既可在工具主目录下直接运行（同步主 VHDX），也会在备份时将其中文件平铺复制
到 U 盘备份目录（例如 E:\vhdx-backup\，与备份镜像同目录），可在任意 Windows 电脑上独立运行：

1. 本机运行双击 rclone-sync\sync.cmd（备份目录中直接双击 E:\vhdx-backup\sync.cmd）并通过 UAC 管理员授权。
2. 界面展示当前源 VHDX、同步目标目录（SyncDestination）与排除路径（ExcludePath）：
   - 首次运行时若尚未配置 SyncDestination，会自动引导输入并持久化写入 sync-config.ini。
   - 确认提示支持：[Y] 开始同步 / [D] 模拟预演(--dry-run) / [E] 修改目标与排除路径 / [N] 取消。
3. 执行同步时：
   - 同机运行且上级 config.ini 中有当前账户可读的 DPAPI 密码时自动解锁；
     异机或无密文时自动提示手动输入 BitLocker 密码。
   - 若运行前 VHDX 未挂载，脚本会在同步结束后（无论成功或失败）自动锁定并卸载；
     若运行前已挂载，则同步后保持原状。
4. 排除规则写法（sync-config.ini 中可写多行 ExcludePath=...）：
   - 默认预置排除 System Volume Information/** 与 $RECYCLE.BIN/**，避免 NTFS 权限报错。
   - 排除目录请以 /** 结尾，例如：ExcludePath=temp/** 或 ExcludePath=/工作/缓存/**
   - 排除文件可使用通配符，例如：ExcludePath=*.tmp
5. 若同步目标为 rclone 远程存储（如 remote:bucket/path），只需把 rclone.conf 放在
   sync.cmd 同目录下，脚本会自动加载。
6. 命令行模式示例：
   - rclone-sync\sync.cmd -Mode DryRun           模拟预演（不改动目标文件）
   - rclone-sync\sync.cmd -Mode Sync -Yes        跳过二次确认直接执行同步
   - rclone-sync\sync.cmd -Mode Config           仅修改同步目标与排除路径

可选附加参数 -PauseOnExit，用于在非菜单模式下执行结束后等待按回车再关闭窗口。
在非菜单模式下，ShowNotifications=true 时会在挂载/卸载完成或失败时弹出 Windows 系统通知；
在交互式主菜单中，执行结果直接展示在终端窗口内，不重复弹出系统通知。

配置文件
--------

打开 config.ini，按需要修改：

VhdxPath=.\secure-disk.dat

  VHDX 文件路径。后缀名不一定要是 .vhdx，可以伪装成 .dat、.bin 等。
  但文件真实内容必须仍然是 VHDX。相对路径从工具目录开始算。

  相对路径例子：

  VhdxPath=.\secure-disk.vhdx
  VhdxPath=.\secure-disk.dat
  VhdxPath=.\vault\secure-disk.vhdx

  绝对路径例子：

  VhdxPath=D:\Private\secure-disk.vhdx
  VhdxPath=C:\Users\YourName\Documents\secure-disk.dat

ImageStorageType=VHDX

  强制告诉 Windows 这个文件是什么磁盘镜像类型。
  如果你的文件只是把 .vhdx 改成了其他后缀，这里保持 VHDX。

PasswordSecret=

  BitLocker 密码的 DPAPI 加密密文。不要手动填写真实密码。
  请在主菜单的「[3] 密码维护」中进行设置、更新或清除。

SafeUnmountOnly=true

  true 表示卸载时如果有文件占用，就安全失败并提示关闭文件后重试。
  不建议改成 false，强制锁定可能导致未保存数据丢失。

MountWaitSeconds=25

  挂载 VHDX 后等待 Windows 识别卷的秒数。普通情况不用改。

ShowNotifications=true

  true 表示在非菜单命令行模式下挂载/卸载完成或发生异常、以及重复双击拦截时弹出
  Windows 系统通知。设为 false 可关闭系统通知。

AutoStartDelaySeconds=10

  开机登录后延迟执行自动解密挂载的秒数（0-300，默认 10 秒）。
  可通过主菜单的「[5] 开机自启动维护」进行配置和更新。

首次使用
--------

1. 准备好 VHDX 文件，并修改 config.ini 里的 VhdxPath 指向该文件。

2. 双击 start.cmd，在弹出的 UAC 管理员权限提示中选择允许。

3. 若希望免密挂载，可先选择「[3] 密码维护」->「[1] 设置 / 更新已保存的密码」；
   若希望每次挂载手动输入密码，直接选择「[1] 挂载并解锁」按提示输入即可。

安全说明
--------

- 默认不会强制卸载被占用的磁盘，避免未保存数据丢失（取决于 SafeUnmountOnly 配置）。
- 密码不会明文写入 config.ini，PasswordSecret 只是当前管理员账户的 DPAPI 加密密文。
- 把这个工具目录复制到另一台电脑或另一个 Windows 用户下，原来的密码密文通常无法解密，
  可通过「密码维护」重新设置或清除。
- 内置防重入互斥锁：已有菜单或操作任务运行时，重复双击 start.cmd 会自动拦截并提示。

常见问题
--------

1. 提示找不到虚拟磁盘文件

   修改 config.ini 里的 VhdxPath，确保路径指向真实存在的 VHDX 文件。
   若使用伪装后缀（如 .dat、.bin），请保持 ImageStorageType=VHDX。

2. 提示无法解密已保存的密码或解锁失败

   可能是 BitLocker 密码改过、密文损坏或更换了 Windows 账户/电脑。
   在主菜单进入「[3] 密码维护」执行校验、更新或清除密码。

3. 卸载失败

   通常是虚拟磁盘里有文件被打开。请关闭资源管理器窗口、编辑器、压缩软件或命令行窗口后重试。

4. PowerShell 执行策略阻止脚本

   请从 start.cmd 启动。它会用 ExecutionPolicy Bypass 仅对本次运行放行，
   不会修改系统执行策略。
