﻿param(
    [ValidateSet('Menu', 'Toggle', 'Mount', 'Unmount', 'Status', 'SetPassword', 'ClearPassword', 'TestPassword', 'Backup', 'AutoMount', 'EnableAutoStart', 'DisableAutoStart', 'RemoveAutoStart', 'AutoStartStatus')]
    [string]$Action = 'Menu',
    [string]$BackupPath = '',
    [int]$DelaySeconds = -1,
    [switch]$PauseOnExit
)

$ErrorActionPreference = 'Stop'

# =========================
# Configuration
# =========================
$BaseDirectory = $PSScriptRoot
$ConfigPath = Join-Path -Path $BaseDirectory -ChildPath 'config.ini'
$RcloneSyncSourceDir = Join-Path -Path $BaseDirectory -ChildPath 'rclone-sync'
$AutoStartLogPath = Join-Path -Path $BaseDirectory -ChildPath 'autostart.log'
$VhdxPath = $null
$ImageStorageType = 'VHDX'
$PasswordSecret = ''
$SafeUnmountOnly = $true
$MountWaitSeconds = 25
$ShowNotifications = $true
$AutoStartDelaySeconds = 10
$IsInteractiveMenu = ($Action -eq 'Menu')
$IsUnattended = ($Action -eq 'AutoMount')
$RunMutex = $null
$RunMutexName = $null

# =========================
# Console & Notification Helpers
# =========================
function Set-ConsoleTheme {
    try {
        $Host.UI.RawUI.WindowTitle = 'VHDX BitLocker 管理工具'
        $Host.UI.RawUI.BackgroundColor = 'Black'
        $Host.UI.RawUI.ForegroundColor = 'Gray'
        Clear-Host
    }
    catch {
        # Console control is best-effort, especially in redirected hosts.
    }
}

function Write-Info {
    param([string]$Message)
    Write-Host "[信息] $Message" -ForegroundColor Cyan
}

function Write-Ok {
    param([string]$Message)
    Write-Host "[成功] $Message" -ForegroundColor Green
}

function Write-Warn {
    param([string]$Message)
    Write-Host "[警告] $Message" -ForegroundColor Yellow
}

function Write-Fail {
    param([string]$Message)
    Write-Host "[错误] $Message" -ForegroundColor Red
}

function Wait-ForMenuReturn {
    param([string]$Prompt = '按回车键返回上一级菜单')

    Write-Host ''
    Read-Host $Prompt | Out-Null
}

function Show-WindowsNotification {
    param(
        [Parameter(Mandatory = $true)][string]$Title,
        [Parameter(Mandatory = $true)][string]$Message,
        [ValidateSet('Info', 'Warning', 'Error')][string]$Level = 'Info',
        [switch]$ForceInMenu
    )

    if (-not $script:ShowNotifications) {
        return
    }

    if ($script:IsInteractiveMenu -and -not $ForceInMenu) {
        return
    }

    $trimmedMessage = $Message.Trim()
    if ($trimmedMessage.Length -gt 200) {
        $trimmedMessage = $trimmedMessage.Substring(0, 197) + '...'
    }

    # Primary path: native Windows Toast notification (Windows PowerShell 5.1)
    try {
        $null = [Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime]
        $null = [Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime]

        $template = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent(
            [Windows.UI.Notifications.ToastTemplateType]::ToastText02
        )
        $textNodes = $template.GetElementsByTagName('text')
        $textNodes.Item(0).InnerText = $Title
        $textNodes.Item(1).InnerText = $trimmedMessage

        $toast = [Windows.UI.Notifications.ToastNotification]::new($template)
        try {
            $toast.Tag = 'status'
            $toast.Group = 'vhd-bitlocker-tool'
        }
        catch {
            # Optional grouping metadata; ignore if unsupported.
        }

        $appId = '{1AC14E77-02E7-4E5D-B744-2EB1AE5198B7}\WindowsPowerShell\v1.0\powershell.exe'
        $notifier = [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier($appId)
        $notifier.Show($toast)
        return
    }
    catch {
        # Fall back to NotifyIcon balloon tip (e.g. under PowerShell 7 or restricted environments).
    }

    $notifyIcon = $null
    try {
        Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
        Add-Type -AssemblyName System.Drawing -ErrorAction Stop

        $notifyIcon = New-Object System.Windows.Forms.NotifyIcon
        switch ($Level) {
            'Warning' {
                $notifyIcon.Icon = [System.Drawing.SystemIcons]::Warning
                $notifyIcon.BalloonTipIcon = [System.Windows.Forms.ToolTipIcon]::Warning
            }
            'Error' {
                $notifyIcon.Icon = [System.Drawing.SystemIcons]::Error
                $notifyIcon.BalloonTipIcon = [System.Windows.Forms.ToolTipIcon]::Error
            }
            default {
                $notifyIcon.Icon = [System.Drawing.SystemIcons]::Information
                $notifyIcon.BalloonTipIcon = [System.Windows.Forms.ToolTipIcon]::Info
            }
        }

        $notifyIcon.BalloonTipTitle = $Title
        $notifyIcon.BalloonTipText = $trimmedMessage
        $notifyIcon.Visible = $true
        $notifyIcon.ShowBalloonTip(3000)
        Start-Sleep -Milliseconds 350
    }
    catch {
        # Notification is best-effort and must never break core operations.
    }
    finally {
        if ($null -ne $notifyIcon) {
            try {
                $notifyIcon.Visible = $false
                $notifyIcon.Dispose()
            }
            catch {
            }
        }
    }
}

# =========================
# Elevation & Single-Instance Mutex
# =========================
function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Get-InstanceMutexNames {
    $keyText = [System.IO.Path]::GetFullPath($script:ConfigPath).ToLowerInvariant()
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($keyText)
        $hashBytes = $sha.ComputeHash($bytes)
        $hash = ([BitConverter]::ToString($hashBytes)).Replace('-', '').Substring(0, 16)
    }
    finally {
        $sha.Dispose()
    }

    return @{
        Run    = "Local\VhdBitLockerTool_Run_$hash"
        Launch = "Local\VhdBitLockerTool_Launch_$hash"
    }
}

function Test-NamedMutexHeld {
    param([Parameter(Mandatory = $true)][string]$Name)

    $existing = $null
    try {
        $existing = [System.Threading.Mutex]::OpenExisting($Name)
        $acquired = $false
        try {
            $acquired = $existing.WaitOne(0)
        }
        catch [System.Threading.AbandonedMutexException] {
            $acquired = $true
        }

        if ($acquired) {
            $existing.ReleaseMutex()
            return $false
        }

        return $true
    }
    catch [System.Threading.WaitHandleCannotBeOpenedException] {
        return $false
    }
    catch [System.UnauthorizedAccessException] {
        # An elevated process owns the mutex with a higher-privilege ACL.
        return $true
    }
    finally {
        if ($null -ne $existing) {
            $existing.Dispose()
        }
    }
}

function Enter-NamedMutex {
    param([Parameter(Mandatory = $true)][string]$Name)

    $mutex = $null
    $acquired = $false

    try {
        $mutex = New-Object System.Threading.Mutex($false, $Name)
        try {
            $acquired = $mutex.WaitOne(0)
        }
        catch [System.Threading.AbandonedMutexException] {
            $acquired = $true
        }

        if (-not $acquired) {
            $mutex.Dispose()
            return $null
        }

        return $mutex
    }
    catch [System.UnauthorizedAccessException] {
        if ($null -ne $mutex) {
            $mutex.Dispose()
        }
        return $null
    }
    catch {
        if ($null -ne $mutex) {
            $mutex.Dispose()
        }
        throw
    }
}

function Exit-NamedMutex {
    param([System.Threading.Mutex]$Mutex)

    if ($null -eq $Mutex) {
        return
    }

    try {
        $Mutex.ReleaseMutex()
    }
    catch {
        # Ignore if already released or not owned.
    }
    finally {
        $Mutex.Dispose()
    }
}

function Quote-ProcessArgument {
    param([Parameter(Mandatory = $true)][string]$Argument)

    if ($Argument.Length -eq 0) {
        return '""'
    }

    return '"' + $Argument.Replace('"', '\"') + '"'
}

function Get-PreferredPowerShellExecutable {
    if ($PSVersionTable.PSEdition -eq 'Core') {
        try {
            $currentExe = [System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
            if (-not [string]::IsNullOrWhiteSpace($currentExe) -and (Test-Path -LiteralPath $currentExe -PathType Leaf)) {
                return $currentExe
            }
        }
        catch {
            # Fall through to standard pwsh discovery.
        }
    }

    $pwshCmd = Get-Command -Name 'pwsh.exe' -ErrorAction SilentlyContinue
    if ($null -ne $pwshCmd -and -not [string]::IsNullOrWhiteSpace($pwshCmd.Source)) {
        return $pwshCmd.Source
    }

    if (-not [string]::IsNullOrWhiteSpace($env:ProgramFiles)) {
        $defaultPwsh = Join-Path -Path $env:ProgramFiles -ChildPath 'PowerShell\7\pwsh.exe'
        if (Test-Path -LiteralPath $defaultPwsh -PathType Leaf) {
            return $defaultPwsh
        }
    }

    return (Join-Path -Path $env:SystemRoot -ChildPath 'System32\WindowsPowerShell\v1.0\powershell.exe')
}

function Start-ElevatedSelf {
    param([string]$RunMutexName)

    $powershell = Get-PreferredPowerShellExecutable
    $arguments = @(
        '-NoProfile',
        '-ExecutionPolicy',
        'Bypass',
        '-File',
        (Quote-ProcessArgument -Argument $PSCommandPath),
        '-Action',
        $Action
    )

    if (-not [string]::IsNullOrWhiteSpace($BackupPath)) {
        $arguments += '-BackupPath'
        $arguments += (Quote-ProcessArgument -Argument $BackupPath)
    }

    if ($DelaySeconds -ge 0) {
        $arguments += '-DelaySeconds'
        $arguments += "$DelaySeconds"
    }

    if ($PauseOnExit) {
        $arguments += '-PauseOnExit'
    }

    Write-Info '需要管理员权限，正在请求 UAC 授权...'
    try {
        $child = Start-Process -FilePath $powershell -ArgumentList $arguments -Verb RunAs -PassThru
        if ($RunMutexName) {
            $handoffDeadline = (Get-Date).AddMilliseconds(2500)
            while ((Get-Date) -lt $handoffDeadline) {
                if (Test-NamedMutexHeld -Name $RunMutexName) {
                    break
                }
                if ($null -ne $child) {
                    try {
                        if ($child.HasExited) {
                            break
                        }
                    }
                    catch {
                        # Elevated process handle may deny inspection from a non-elevated caller.
                    }
                }
                Start-Sleep -Milliseconds 50
            }
        }
        return $true
    }
    catch [System.ComponentModel.Win32Exception] {
        if ($_.Exception.NativeErrorCode -eq 1223) {
            Write-Warn '已取消管理员权限授权。'
            return $false
        }
        throw
    }
}

# =========================
# Config File Management
# =========================
function Read-ConfigLines {
    param([Parameter(Mandatory = $true)][string]$Path)

    $bytes = [System.IO.File]::ReadAllBytes($Path)
    if ($bytes.Length -eq 0) {
        return @()
    }

    # UTF-16 LE / BE BOM
    if ($bytes.Length -ge 2 -and $bytes[0] -eq 0xFF -and $bytes[1] -eq 0xFE) {
        $text = [System.Text.Encoding]::Unicode.GetString($bytes, 2, $bytes.Length - 2)
    }
    elseif ($bytes.Length -ge 2 -and $bytes[0] -eq 0xFE -and $bytes[1] -eq 0xFF) {
        $text = [System.Text.Encoding]::BigEndianUnicode.GetString($bytes, 2, $bytes.Length - 2)
    }
    # UTF-8 BOM
    elseif ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
        $text = [System.Text.Encoding]::UTF8.GetString($bytes, 3, $bytes.Length - 3)
    }
    else {
        # Prefer strict UTF-8; fall back to system ANSI encoding for legacy GBK/ANSI files.
        $strictUtf8 = New-Object System.Text.UTF8Encoding($false, $true)
        try {
            $text = $strictUtf8.GetString($bytes)
        }
        catch [System.Text.DecoderFallbackException] {
            $text = [System.Text.Encoding]::Default.GetString($bytes)
        }
    }

    $normalized = $text.Replace("`r`n", "`n").Replace("`r", "`n")
    if ($normalized.EndsWith("`n")) {
        $normalized = $normalized.Substring(0, $normalized.Length - 1)
    }

    if ($normalized.Length -eq 0) {
        return @()
    }

    return @($normalized -split "`n")
}

function Write-ConfigLines {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [AllowEmptyCollection()]
        [AllowEmptyString()]
        [Parameter(Mandatory = $true)][string[]]$Lines
    )

    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    $tempPath = "$Path.$PID.tmp"
    try {
        [System.IO.File]::WriteAllLines($tempPath, $Lines, $utf8NoBom)
        Move-Item -LiteralPath $tempPath -Destination $Path -Force -ErrorAction Stop
    }
    finally {
        if (Test-Path -LiteralPath $tempPath -PathType Leaf) {
            Remove-Item -LiteralPath $tempPath -Force -ErrorAction SilentlyContinue
        }
    }
}

function New-DefaultConfigFile {
    $defaultLines = @(
        '# Windows VHDX + BitLocker Tool configuration',
        '# Lines starting with # or ; are comments.',
        '# Relative paths start in this tool folder.',
        '',
        '# Your VHDX file path. The file extension can be disguised.',
        '# Relative path examples:',
        '#   VhdxPath=.\secure-disk.vhdx',
        '#   VhdxPath=.\secure-disk.dat',
        '# Absolute path examples:',
        '#   VhdxPath=D:\Private\secure-disk.vhdx',
        '#   VhdxPath=C:\Users\YourName\Documents\secure-disk.dat',
        'VhdxPath=.\secure-disk.dat',
        '',
        '# Force Windows to treat the file as this image type.',
        '# Keep VHDX when the real file content is VHDX, even if the suffix is disguised.',
        'ImageStorageType=VHDX',
        '',
        '# DPAPI-encrypted BitLocker password.',
        '# Do not edit this by hand. It is not the plain text password.',
        '# Use start.cmd -> Password Maintenance to save, change, or clear the password.',
        'PasswordSecret=',
        '',
        '# true: fail safely if files are open on the virtual disk.',
        '# false: allow forced BitLocker lock. This can lose unsaved data.',
        'SafeUnmountOnly=true',
        '',
        '# Seconds to wait for Windows to expose the VHDX volume after mount.',
        'MountWaitSeconds=25',
        '',
        '# true: show a Windows notification in non-menu CLI mode.',
        'ShowNotifications=true',
        '',
        '# Delay in seconds after Windows logon before auto-mounting VHDX (0-300).',
        'AutoStartDelaySeconds=10'
    )

    Write-ConfigLines -Path $script:ConfigPath -Lines $defaultLines
}

function Set-ConfigValue {
    param(
        [Parameter(Mandatory = $true)][string]$Name,
        [AllowEmptyString()][string]$Value
    )

    if (-not (Test-Path -LiteralPath $script:ConfigPath -PathType Leaf)) {
        New-DefaultConfigFile
    }

    $lines = @(Read-ConfigLines -Path $script:ConfigPath)
    $pattern = '^\s*' + [regex]::Escape($Name) + '\s*='
    $updated = $false
    $result = New-Object System.Collections.Generic.List[string]

    foreach ($line in $lines) {
        if ($line -match $pattern) {
            if (-not $updated) {
                $result.Add("$Name=$Value")
                $updated = $true
            }
            # Skip duplicate keys to keep config.ini clean.
        }
        else {
            $result.Add($line)
        }
    }

    if (-not $updated) {
        if ($result.Count -gt 0 -and $result[$result.Count - 1].Trim().Length -ne 0) {
            $result.Add('')
        }
        $result.Add("$Name=$Value")
    }

    Write-ConfigLines -Path $script:ConfigPath -Lines $result.ToArray()
}

function Remove-SurroundingQuotes {
    param([string]$Value)

    $trimmed = $Value.Trim()
    if ($trimmed.Length -ge 2) {
        $first = $trimmed[0]
        $last = $trimmed[$trimmed.Length - 1]
        if (($first -eq '"' -and $last -eq '"') -or ($first -eq "'" -and $last -eq "'")) {
            return $trimmed.Substring(1, $trimmed.Length - 2).Trim()
        }
    }

    return $trimmed
}

function Resolve-ConfigPath {
    param([Parameter(Mandatory = $true)][string]$PathValue)

    $unquoted = Remove-SurroundingQuotes -Value $PathValue
    $expanded = [Environment]::ExpandEnvironmentVariables($unquoted)
    if ([string]::IsNullOrWhiteSpace($expanded)) {
        throw 'config.ini 中的路径配置为空。'
    }

    if ([System.IO.Path]::IsPathRooted($expanded)) {
        return [System.IO.Path]::GetFullPath($expanded)
    }

    return [System.IO.Path]::GetFullPath((Join-Path -Path $script:BaseDirectory -ChildPath $expanded))
}

function ConvertTo-ConfigBoolean {
    param(
        [Parameter(Mandatory = $true)][string]$Name,
        [Parameter(Mandatory = $true)][string]$Value
    )

    switch ($Value.Trim().ToLowerInvariant()) {
        'true' { return $true }
        'yes' { return $true }
        '1' { return $true }
        'false' { return $false }
        'no' { return $false }
        '0' { return $false }
        default { throw "config.ini 中 $Name 的布尔值无效：$Value（请使用 true 或 false）。" }
    }
}

function ConvertTo-StorageType {
    param([Parameter(Mandatory = $true)][string]$Value)

    $normalized = $Value.Trim().ToUpperInvariant()
    $allowed = @('Unknown', 'ISO', 'VHD', 'VHDX', 'VHDSet')

    foreach ($candidate in $allowed) {
        if ($candidate.ToUpperInvariant() -eq $normalized) {
            return $candidate
        }
    }

    throw "config.ini 中 ImageStorageType 无效：$Value（可选值：$($allowed -join ', ')）。"
}

function Import-ToolConfig {
    param([switch]$Quiet)

    if (-not (Test-Path -LiteralPath $script:ConfigPath -PathType Leaf)) {
        New-DefaultConfigFile
        if (-not $Quiet) {
            Write-Warn "未找到配置文件，已自动生成默认配置：$script:ConfigPath"
        }
    }

    $settings = @{}
    $lineNumber = 0

    foreach ($line in (Read-ConfigLines -Path $script:ConfigPath)) {
        $lineNumber++
        $trimmed = $line.Trim()

        if ($trimmed.Length -eq 0 -or $trimmed.StartsWith('#') -or $trimmed.StartsWith(';')) {
            continue
        }

        $separatorIndex = $trimmed.IndexOf('=')
        if ($separatorIndex -lt 1) {
            throw "config.ini 第 $lineNumber 行格式错误，请使用 Key=Value 格式。"
        }

        $key = $trimmed.Substring(0, $separatorIndex).Trim()
        $value = $trimmed.Substring($separatorIndex + 1).Trim()

        if ($key.Length -eq 0) {
            throw "config.ini 第 $lineNumber 行键名为空。"
        }

        $settings[$key] = $value
    }

    if (-not $settings.ContainsKey('VhdxPath')) {
        throw 'config.ini 缺少必填项 VhdxPath。'
    }

    $script:VhdxPath = Resolve-ConfigPath -PathValue $settings['VhdxPath']

    if ($settings.ContainsKey('ImageStorageType')) {
        $script:ImageStorageType = ConvertTo-StorageType -Value $settings['ImageStorageType']
    }
    else {
        $script:ImageStorageType = 'VHDX'
    }

    if ($settings.ContainsKey('PasswordSecret')) {
        $script:PasswordSecret = $settings['PasswordSecret'].Trim()
    }
    else {
        $script:PasswordSecret = ''
    }

    if ($settings.ContainsKey('SafeUnmountOnly')) {
        $script:SafeUnmountOnly = ConvertTo-ConfigBoolean -Name 'SafeUnmountOnly' -Value $settings['SafeUnmountOnly']
    }
    else {
        $script:SafeUnmountOnly = $true
    }

    if ($settings.ContainsKey('MountWaitSeconds')) {
        $waitSeconds = 0
        if (-not [int]::TryParse($settings['MountWaitSeconds'], [ref]$waitSeconds)) {
            throw "config.ini 中 MountWaitSeconds 不是有效整数：$($settings['MountWaitSeconds'])。"
        }
        if ($waitSeconds -lt 1 -or $waitSeconds -gt 300) {
            throw 'config.ini 中 MountWaitSeconds 必须在 1 到 300 之间。'
        }

        $script:MountWaitSeconds = $waitSeconds
    }
    else {
        $script:MountWaitSeconds = 25
    }

    if ($settings.ContainsKey('ShowNotifications')) {
        $script:ShowNotifications = ConvertTo-ConfigBoolean -Name 'ShowNotifications' -Value $settings['ShowNotifications']
    }
    else {
        $script:ShowNotifications = $true
    }

    if ($settings.ContainsKey('AutoStartDelaySeconds')) {
        $autoDelay = 0
        if (-not [int]::TryParse($settings['AutoStartDelaySeconds'], [ref]$autoDelay)) {
            throw "config.ini 中 AutoStartDelaySeconds 不是有效整数：$($settings['AutoStartDelaySeconds'])。"
        }
        if ($autoDelay -lt 0 -or $autoDelay -gt 300) {
            throw 'config.ini 中 AutoStartDelaySeconds 必须在 0 到 300 之间。'
        }

        $script:AutoStartDelaySeconds = $autoDelay
    }
    else {
        $script:AutoStartDelaySeconds = 10
    }
}

function Assert-VhdxExists {
    if (-not (Test-Path -LiteralPath $script:VhdxPath -PathType Leaf)) {
        throw "找不到虚拟磁盘文件：$script:VhdxPath。请检查 config.ini 中的 VhdxPath 配置。"
    }
}

function Get-MissingRequiredCommands {
    $requiredCommands = @(
        'Get-DiskImage',
        'Mount-DiskImage',
        'Dismount-DiskImage',
        'Get-Disk',
        'Get-Partition',
        'Get-Volume',
        'Get-BitLockerVolume',
        'Unlock-BitLocker',
        'Lock-BitLocker'
    )

    $missingCommands = @()
    foreach ($commandName in $requiredCommands) {
        if (-not (Get-Command -Name $commandName -ErrorAction SilentlyContinue)) {
            $missingCommands += $commandName
        }
    }

    return $missingCommands
}

function Assert-RequiredCommands {
    $missingCommands = @(Get-MissingRequiredCommands)
    if ($missingCommands.Count -gt 0) {
        throw "缺少必需的系统 PowerShell 命令：$($missingCommands -join ', ')。本工具依赖 Windows 内置的 Storage 和 BitLocker 模块。"
    }
}

# =========================
# Password Management (DPAPI)
# =========================
function Test-SecureStringEqual {
    param(
        [Parameter(Mandatory = $true)][securestring]$Left,
        [Parameter(Mandatory = $true)][securestring]$Right
    )

    if ($Left.Length -ne $Right.Length) {
        return $false
    }

    $leftPtr = [IntPtr]::Zero
    $rightPtr = [IntPtr]::Zero

    try {
        $leftPtr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Left)
        $rightPtr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Right)
        $diff = 0
        for ($i = 0; $i -lt $Left.Length; $i++) {
            $offset = $i * 2
            $leftChar = [Runtime.InteropServices.Marshal]::ReadInt16($leftPtr, $offset)
            $rightChar = [Runtime.InteropServices.Marshal]::ReadInt16($rightPtr, $offset)
            $diff = $diff -bor ($leftChar -bxor $rightChar)
        }
        return ($diff -eq 0)
    }
    finally {
        if ($leftPtr -ne [IntPtr]::Zero) {
            [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($leftPtr)
        }
        if ($rightPtr -ne [IntPtr]::Zero) {
            [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($rightPtr)
        }
    }
}

function Read-SingleBitLockerPassword {
    param([string]$Prompt = '请输入 BitLocker 密码（直接按回车取消）')

    $entered = Read-Host $Prompt -AsSecureString
    if ($null -eq $entered -or $entered.Length -eq 0) {
        return $null
    }

    return $entered
}

function Read-NewBitLockerPassword {
    while ($true) {
        $first = Read-Host '请输入新的 BitLocker 密码（直接按回车取消）' -AsSecureString
        if ($null -eq $first -or $first.Length -eq 0) {
            return $null
        }

        $second = Read-Host '请再次输入 BitLocker 密码以确认' -AsSecureString
        if ($null -ne $second -and (Test-SecureStringEqual -Left $first -Right $second)) {
            return $first
        }

        Write-Warn '两次输入的密码不一致，请重新输入。'
    }
}

function Save-BitLockerPassword {
    param([Parameter(Mandatory = $true)][securestring]$Password)

    $script:PasswordSecret = ($Password | ConvertFrom-SecureString)
    Set-ConfigValue -Name 'PasswordSecret' -Value $script:PasswordSecret
}

function Test-SavedPasswordState {
    if ([string]::IsNullOrWhiteSpace($script:PasswordSecret)) {
        return [pscustomobject]@{
            State = 'NotSaved'
            Error = $null
        }
    }

    try {
        $null = ($script:PasswordSecret.Trim() | ConvertTo-SecureString -ErrorAction Stop)
        return [pscustomobject]@{
            State = 'SavedValid'
            Error = $null
        }
    }
    catch {
        return [pscustomobject]@{
            State = 'SavedInvalid'
            Error = $_.Exception.Message
        }
    }
}

function Set-NewStoredPassword {
    Import-ToolConfig -Quiet
    Write-Info '将为当前 Windows 管理员账户使用 DPAPI 加密保存 BitLocker 密码到 config.ini。'
    Write-Info '（注意：此操作仅更新本地缓存密码，不会修改虚拟磁盘本身的 BitLocker 密码。）'
    Write-Host ''

    $password = Read-NewBitLockerPassword
    if ($null -eq $password) {
        Write-Warn '已取消设置密码。'
        return
    }

    Save-BitLockerPassword -Password $password
    Write-Ok '已将加密后的密码保存到 config.ini 的 PasswordSecret 项。'
}

function Clear-StoredPassword {
    param([switch]$RequireConfirm)

    Import-ToolConfig -Quiet

    if ([string]::IsNullOrWhiteSpace($script:PasswordSecret)) {
        Write-Info 'config.ini 中当前没有已保存的密码。'
        return
    }

    if ($RequireConfirm) {
        $rawConfirm = Read-Host '确认清除已保存的密码吗？清除后每次挂载需手动输入密码 [y/N]'
        $confirm = if ($null -ne $rawConfirm) { $rawConfirm.Trim().ToLowerInvariant() } else { '' }
        if ($confirm -ne 'y' -and $confirm -ne 'yes') {
            Write-Warn '已取消清除密码。'
            return
        }
    }

    $script:PasswordSecret = ''
    Set-ConfigValue -Name 'PasswordSecret' -Value ''
    Write-Ok '已清除 config.ini 中保存的密码，后续挂载将改为手动输入。'

    try {
        $autoSnapshot = Get-AutoStartSnapshot
        if ($autoSnapshot.Exists -and $autoSnapshot.Enabled) {
            Write-Warn '注意：当前已启用开机自启动，清除密码后下次登录将无法自动解密挂载。请前往「开机自启动维护」关闭自启或重新保存密码。'
        }
    }
    catch {
        # Best-effort advisory warning.
    }
}

function Invoke-TestStoredPassword {
    Import-ToolConfig -Quiet
    $check = Test-SavedPasswordState

    switch ($check.State) {
        'NotSaved' {
            Write-Warn 'config.ini 中当前未保存密码（PasswordSecret 为空）。'
        }
        'SavedValid' {
            Write-Ok '密文校验通过：当前管理员账户可以正常解密 config.ini 中保存的密码。'
        }
        'SavedInvalid' {
            Write-Fail "密文校验失败：当前账户无法解密已保存的密码（可能更换了电脑/用户或密文已损坏）。请重新设置或清除密码。详情：$($check.Error)"
        }
    }
}

function Resolve-UnlockPassword {
    param([switch]$NonInteractive)

    if ([string]::IsNullOrWhiteSpace($script:PasswordSecret)) {
        if ($NonInteractive) {
            throw 'config.ini 中未保存 BitLocker 密码（PasswordSecret 为空），无法在无人值守模式下自动解锁。请进入主菜单「密码维护」保存密码。'
        }

        Write-Info '当前未保存 BitLocker 密码，请输入本次解锁密码（本次输入不会自动保存）。'
        $enteredPassword = Read-SingleBitLockerPassword
        if ($null -eq $enteredPassword) {
            return $null
        }
        return $enteredPassword
    }

    try {
        return ($script:PasswordSecret.Trim() | ConvertTo-SecureString -ErrorAction Stop)
    }
    catch {
        throw "无法解密 config.ini 中已保存的密码，请进入「密码维护」重新设置或清除密码。详情：$($_.Exception.Message)"
    }
}

# =========================
# VHDX & BitLocker Operations
# =========================
function Get-VhdxDiskImage {
    return Get-DiskImage -ImagePath $script:VhdxPath -StorageType $script:ImageStorageType -ErrorAction Stop
}

function Get-VhdxDisk {
    $image = Get-VhdxDiskImage
    if (-not $image.Attached) {
        return $null
    }

    try {
        return ($image | Get-Disk -ErrorAction Stop)
    }
    catch {
        return $null
    }
}

function Get-VhdxPartitions {
    $disk = Get-VhdxDisk
    if ($null -eq $disk) {
        return @()
    }

    return @(Get-Partition -DiskNumber $disk.Number -ErrorAction SilentlyContinue)
}

function Normalize-BitLockerMountPoint {
    param([Parameter(Mandatory = $true)][string]$MountPoint)

    $trimmed = $MountPoint.Trim()
    if ($trimmed -match '^[A-Za-z]:\\?$') {
        return $trimmed.Substring(0, 2).ToUpperInvariant()
    }

    return $trimmed
}

function Format-MountPointSummary {
    param([string[]]$MountPoints)

    $normalized = @(
        $MountPoints |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) } |
            ForEach-Object { Normalize-BitLockerMountPoint -MountPoint $_ } |
            Select-Object -Unique
    )

    if ($normalized.Count -eq 0) {
        return ''
    }

    return ($normalized -join ', ')
}

function Get-VhdxMountPoints {
    $points = @()

    foreach ($partition in Get-VhdxPartitions) {
        if ($partition.DriveLetter) {
            $points += "$($partition.DriveLetter):"
        }

        foreach ($accessPath in @($partition.AccessPaths)) {
            if (-not [string]::IsNullOrWhiteSpace($accessPath)) {
                $points += $accessPath
            }
        }

        try {
            $volumes = @($partition | Get-Volume -ErrorAction SilentlyContinue)
            foreach ($volume in $volumes) {
                if ($volume.DriveLetter) {
                    $points += "$($volume.DriveLetter):"
                }
                if (-not [string]::IsNullOrWhiteSpace($volume.Path)) {
                    $points += $volume.Path
                }
            }
        }
        catch {
            # Some locked or special partitions do not expose a regular volume yet.
        }
    }

    $points = @(
        $points |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) } |
            ForEach-Object { Normalize-BitLockerMountPoint -MountPoint $_ } |
            Select-Object -Unique
    )

    return $points
}

function Get-VhdxBitLockerVolumes {
    $volumes = @()
    $mountPoints = @(Get-VhdxMountPoints)

    foreach ($mountPoint in $mountPoints) {
        try {
            $volumes += @(Get-BitLockerVolume -MountPoint $mountPoint -ErrorAction Stop)
        }
        catch {
            # Not every partition/access path is expected to be BitLocker-managed.
        }
    }

    if ($volumes.Count -eq 0 -and $mountPoints.Count -gt 0) {
        try {
            $knownPointSet = @{}
            foreach ($mountPoint in $mountPoints) {
                $knownPointSet[$mountPoint.ToUpperInvariant()] = $true
            }

            foreach ($volume in @(Get-BitLockerVolume -ErrorAction SilentlyContinue)) {
                if (-not [string]::IsNullOrWhiteSpace($volume.MountPoint)) {
                    $candidate = (Normalize-BitLockerMountPoint -MountPoint $volume.MountPoint).ToUpperInvariant()
                    if ($knownPointSet.ContainsKey($candidate)) {
                        $volumes += $volume
                    }
                }
            }
        }
        catch {
            # The direct MountPoint lookup above is the primary path.
        }
    }

    $unique = @{}
    $result = @()

    foreach ($volume in $volumes) {
        if ([string]::IsNullOrWhiteSpace($volume.MountPoint)) {
            continue
        }

        $key = (Normalize-BitLockerMountPoint -MountPoint $volume.MountPoint).ToUpperInvariant()
        if (-not $unique.ContainsKey($key)) {
            $unique[$key] = $true
            $result += $volume
        }
    }

    return $result
}

function Wait-VhdxBitLockerVolumes {
    $deadline = (Get-Date).AddSeconds($script:MountWaitSeconds)

    do {
        $volumes = @(Get-VhdxBitLockerVolumes)
        if ($volumes.Count -gt 0) {
            return $volumes
        }

        Start-Sleep -Milliseconds 300
    } while ((Get-Date) -lt $deadline)

    return @()
}

function Flush-VolumeCacheBestEffort {
    param([Parameter(Mandatory = $true)][string]$MountPoint)

    if ($MountPoint -match '^([A-Za-z]):$') {
        $driveLetter = $matches[1]
        if (Get-Command -Name 'Write-VolumeCache' -ErrorAction SilentlyContinue) {
            try {
                Write-VolumeCache -DriveLetter $driveLetter -ErrorAction Stop
            }
            catch {
                # Best-effort cache flush before locking.
            }
        }
    }
}

function Dismount-VhdxWithRetry {
    param(
        [int]$MaxAttempts = 4,
        [int]$DelaySeconds = 1
    )

    $lastError = $null
    for ($attempt = 1; $attempt -le $MaxAttempts; $attempt++) {
        try {
            $image = Get-VhdxDiskImage
            if (-not $image.Attached) {
                return
            }

            Dismount-DiskImage -ImagePath $script:VhdxPath -StorageType $script:ImageStorageType -ErrorAction Stop | Out-Null
            return
        }
        catch {
            $lastError = $_
            if ($attempt -lt $MaxAttempts) {
                Start-Sleep -Seconds $DelaySeconds
            }
        }
    }

    if ($null -ne $lastError) {
        throw $lastError.Exception
    }
}

function Lock-VhdxBitLockerVolumes {
    param([switch]$BestEffort)

    $volumes = @(Get-VhdxBitLockerVolumes)
    $handledPoints = @()

    if ($volumes.Count -eq 0) {
        if (-not $BestEffort) {
            Write-Warn '已挂载的虚拟磁盘中未检测到 BitLocker 卷，将继续执行卸载。'
        }
        return $handledPoints
    }

    foreach ($volume in $volumes) {
        $mountPoint = Normalize-BitLockerMountPoint -MountPoint $volume.MountPoint
        $handledPoints += $mountPoint

        if ($volume.LockStatus -eq 'Locked') {
            if (-not $BestEffort) {
                Write-Info "BitLocker 卷 $mountPoint 已处于锁定状态。"
            }
            continue
        }

        Flush-VolumeCacheBestEffort -MountPoint $mountPoint

        Write-Info "正在锁定 BitLocker 卷 $mountPoint..."
        $lockParams = @{
            MountPoint  = $mountPoint
            ErrorAction = 'Stop'
            Confirm     = $false
        }

        if (-not $script:SafeUnmountOnly -or $BestEffort) {
            $lockParams['ForceDismount'] = $true
        }

        try {
            Lock-BitLocker @lockParams | Out-Null
            Write-Ok "已锁定 $mountPoint。"
        }
        catch {
            if ($BestEffort) {
                Write-Warn "回滚期间未能锁定 $mountPoint：$($_.Exception.Message)"
            }
            else {
                throw "无法锁定 $mountPoint。请关闭正在访问该虚拟磁盘的文件或程序后重试。详情：$($_.Exception.Message)"
            }
        }
    }

    return $handledPoints
}

function Unlock-VhdxBitLockerVolumes {
    param([Parameter(Mandatory = $true)][securestring]$Password)

    $volumes = @(Wait-VhdxBitLockerVolumes)

    if ($volumes.Count -eq 0) {
        throw '虚拟磁盘已挂载，但未检测到 BitLocker 卷。请确认该磁盘包含已分配盘符或挂载点的 BitLocker 卷。'
    }

    $mountPoints = @()
    foreach ($volume in $volumes) {
        $mountPoint = Normalize-BitLockerMountPoint -MountPoint $volume.MountPoint
        $mountPoints += $mountPoint

        if ($volume.LockStatus -eq 'Unlocked') {
            Write-Info "BitLocker 卷 $mountPoint 已处于解锁状态。"
            continue
        }

        Write-Info "正在解锁 BitLocker 卷 $mountPoint..."
        Unlock-BitLocker -MountPoint $mountPoint -Password $Password -ErrorAction Stop | Out-Null
        Write-Ok "已解锁 $mountPoint。"
    }

    $postVolumes = @(Get-VhdxBitLockerVolumes)
    $stillLocked = @(
        $postVolumes |
            Where-Object { $_.LockStatus -eq 'Locked' }
    )

    if ($stillLocked.Count -gt 0) {
        throw '解锁后仍有 BitLocker 卷处于锁定状态。'
    }

    $finalPoints = @(
        $postVolumes |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_.MountPoint) } |
            ForEach-Object { Normalize-BitLockerMountPoint -MountPoint $_.MountPoint } |
            Select-Object -Unique
    )
    if ($finalPoints.Count -gt 0) {
        return $finalPoints
    }

    return $mountPoints
}

function Mount-AndUnlockVhdx {
    param([switch]$NonInteractive)

    Import-ToolConfig -Quiet
    Assert-RequiredCommands
    Assert-VhdxExists

    $image = Get-VhdxDiskImage
    if ($image.Attached) {
        $existingVolumes = @(Get-VhdxBitLockerVolumes)
        $lockedVolumes = @($existingVolumes | Where-Object { $_.LockStatus -eq 'Locked' })

        if ($existingVolumes.Count -gt 0 -and $lockedVolumes.Count -eq 0) {
            $summary = Format-MountPointSummary -MountPoints @($existingVolumes | ForEach-Object { $_.MountPoint })
            $msg = if ($summary) { "虚拟磁盘已挂载且已解锁：$summary" } else { '虚拟磁盘已挂载且已解锁。' }
            Write-Info $msg
            Show-WindowsNotification -Title 'VHDX BitLocker' -Message $msg -Level 'Info'
            return
        }

        Write-Info '检测到虚拟磁盘已挂载但存在未解锁的 BitLocker 卷，正在尝试直接解锁...'
        $password = Resolve-UnlockPassword -NonInteractive:$NonInteractive
        if ($null -eq $password) {
            Write-Warn '已取消解锁操作。'
            return
        }

        $mountPoints = @(Unlock-VhdxBitLockerVolumes -Password $password)
        $summary = Format-MountPointSummary -MountPoints $mountPoints
        $doneMsg = if ($summary) { "解锁完成：$summary" } else { '已完成虚拟磁盘解锁。' }
        Write-Ok $doneMsg
        Show-WindowsNotification -Title 'VHDX BitLocker' -Message $doneMsg -Level 'Info'
        return
    }

    # Resolve password before mounting so canceled input or DPAPI failure never leaves VHDX attached.
    $password = Resolve-UnlockPassword -NonInteractive:$NonInteractive
    if ($null -eq $password) {
        Write-Warn '已取消挂载操作。'
        return
    }

    Write-Info "正在挂载虚拟磁盘：$script:VhdxPath"
    $mountedHere = $false

    try {
        Mount-DiskImage -ImagePath $script:VhdxPath -StorageType $script:ImageStorageType -ErrorAction Stop | Out-Null
        $mountedHere = $true
        Write-Ok '虚拟磁盘已挂载。'

        $mountPoints = @(Unlock-VhdxBitLockerVolumes -Password $password)

        $summary = Format-MountPointSummary -MountPoints $mountPoints
        $doneMsg = if ($summary) { "已挂载并解锁：$summary" } else { '已挂载并解锁虚拟磁盘。' }
        Write-Ok $doneMsg
        Show-WindowsNotification -Title 'VHDX BitLocker' -Message $doneMsg -Level 'Info'
    }
    catch {
        $originalMessage = $_.Exception.Message

        if ($mountedHere) {
            Write-Warn '解锁失败，正在回滚锁定并卸载虚拟磁盘以恢复原状...'
            try {
                Lock-VhdxBitLockerVolumes -BestEffort | Out-Null
                Dismount-VhdxWithRetry -MaxAttempts 3 -DelaySeconds 1
                Write-Ok '回滚完成：虚拟磁盘已卸载。'
            }
            catch {
                Write-Warn "回滚卸载失败：$($_.Exception.Message)"
            }
        }

        throw "挂载或解锁失败：$originalMessage 如 BitLocker 密码已变更，请进入「密码维护」更新密码。"
    }
}

function Lock-AndDismountVhdx {
    Import-ToolConfig -Quiet
    Assert-RequiredCommands
    Assert-VhdxExists

    $image = Get-VhdxDiskImage
    if (-not $image.Attached) {
        Write-Info '虚拟磁盘当前未挂载，无需卸载。'
        Show-WindowsNotification -Title 'VHDX BitLocker' -Message '虚拟磁盘当前未挂载。' -Level 'Info'
        return
    }

    Write-Info '正在锁定 BitLocker 卷并卸载虚拟磁盘...'
    $mountPoints = @(Lock-VhdxBitLockerVolumes)

    Write-Info '正在卸载虚拟磁盘...'
    try {
        Dismount-VhdxWithRetry -MaxAttempts 4 -DelaySeconds 1
        $summary = Format-MountPointSummary -MountPoints $mountPoints
        $doneMsg = if ($summary) { "已锁定并卸载：$summary" } else { '已锁定并卸载虚拟磁盘。' }
        Write-Ok $doneMsg
        Show-WindowsNotification -Title 'VHDX BitLocker' -Message $doneMsg -Level 'Info'
    }
    catch {
        throw "BitLocker 卷已处理，但虚拟磁盘卸载失败。请关闭仍在访问该磁盘的窗口或程序后重试。详情：$($_.Exception.Message)"
    }
}

function Invoke-Toggle {
    Import-ToolConfig -Quiet
    Assert-RequiredCommands
    Assert-VhdxExists

    $image = Get-VhdxDiskImage
    if ($image.Attached) {
        Lock-AndDismountVhdx
    }
    else {
        Mount-AndUnlockVhdx
    }
}

# =========================
# VHDX Backup & rclone Kit Replication
# =========================
function Format-ByteSize {
    param([long]$Bytes)

    if ($Bytes -lt 0) {
        return '0 B'
    }
    if ($Bytes -ge 1TB) {
        return ('{0:N2} TB' -f ($Bytes / 1TB))
    }
    if ($Bytes -ge 1GB) {
        return ('{0:N2} GB' -f ($Bytes / 1GB))
    }
    if ($Bytes -ge 1MB) {
        return ('{0:N2} MB' -f ($Bytes / 1MB))
    }
    if ($Bytes -ge 1KB) {
        return ('{0:N1} KB' -f ($Bytes / 1KB))
    }
    return "$Bytes B"
}

function Get-DirectorySizeBytes {
    param([Parameter(Mandatory = $true)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
        return [long]0
    }

    [long]$sum = 0
    foreach ($file in (Get-ChildItem -LiteralPath $Path -File -Recurse -ErrorAction SilentlyContinue)) {
        $sum += $file.Length
    }
    return $sum
}

function Get-UsbBackupDrives {
    $driveMap = @{}

    # 1. Standard removable drives (flash drives, SD readers, etc.)
    try {
        foreach ($drive in [System.IO.DriveInfo]::GetDrives()) {
            if ($drive.DriveType -eq [System.IO.DriveType]::Removable -and $drive.IsReady) {
                $letter = $drive.Name.Substring(0, 1).ToUpperInvariant()
                $driveMap[$letter] = $drive
            }
        }
    }
    catch {
        # Ignore transient drive enumeration issues.
    }

    # 2. USB-attached external SSDs/HDDs (often reported as Fixed rather than Removable)
    try {
        $usbDisks = @(Get-Disk -ErrorAction SilentlyContinue | Where-Object { $_.BusType -eq 'USB' })
        foreach ($disk in $usbDisks) {
            $partitions = @(Get-Partition -DiskNumber $disk.Number -ErrorAction SilentlyContinue)
            foreach ($partition in $partitions) {
                $letters = @()
                if ($partition.DriveLetter) {
                    $letters += [string]$partition.DriveLetter
                }
                try {
                    foreach ($vol in @($partition | Get-Volume -ErrorAction SilentlyContinue)) {
                        if ($vol.DriveLetter) {
                            $letters += [string]$vol.DriveLetter
                        }
                    }
                }
                catch {
                }

                foreach ($letterRaw in ($letters | Select-Object -Unique)) {
                    if ($letterRaw -match '^[A-Za-z]$') {
                        $letter = $letterRaw.ToUpperInvariant()
                        if (-not $driveMap.ContainsKey($letter)) {
                            try {
                                $di = New-Object System.IO.DriveInfo("${letter}:\")
                                if ($di.IsReady) {
                                    $driveMap[$letter] = $di
                                }
                            }
                            catch {
                            }
                        }
                    }
                }
            }
        }
    }
    catch {
        # Best-effort Storage module lookup.
    }

    $results = @()
    foreach ($letter in ($driveMap.Keys | Sort-Object)) {
        $di = $driveMap[$letter]
        $label = if ([string]::IsNullOrWhiteSpace($di.VolumeLabel)) { '无卷标' } else { $di.VolumeLabel }
        $results += [pscustomobject]@{
            DriveLetter        = $letter
            RootPath           = "${letter}:\"
            DefaultBackupDir   = "${letter}:\vhdx-backup"
            VolumeLabel        = $label
            DriveFormat        = $di.DriveFormat
            AvailableFreeSpace = [long]$di.AvailableFreeSpace
            TotalSize          = [long]$di.TotalSize
        }
    }

    return $results
}

function Resolve-BackupTargetDirectory {
    param([string]$ExplicitPath)

    if (-not [string]::IsNullOrWhiteSpace($ExplicitPath)) {
        $clean = Remove-SurroundingQuotes -Value $ExplicitPath
        $expanded = [Environment]::ExpandEnvironmentVariables($clean)
        if ([string]::IsNullOrWhiteSpace($expanded)) {
            throw '指定的备份目标目录为空。'
        }
        if ($expanded -match '^[A-Za-z]:[^\\/]') {
            throw "备份目标路径格式不完整：$clean（请使用完整路径，例如 E:\vhdx-backup）。"
        }
        return [System.IO.Path]::GetFullPath($expanded)
    }

    $usbDrives = @(Get-UsbBackupDrives)
    Write-Host ''

    if ($usbDrives.Count -eq 1) {
        $drv = $usbDrives[0]
        Write-Info "检测到 USB 存储盘：$($drv.RootPath)（$($drv.VolumeLabel)，$($drv.DriveFormat)，可用 $(Format-ByteSize -Bytes $drv.AvailableFreeSpace) / 总计 $(Format-ByteSize -Bytes $drv.TotalSize)）"
        $rawInput = Read-Host "请输入备份目标目录 [默认: $($drv.DefaultBackupDir)，直接回车采用，输入 0 取消]"
        if ($null -eq $rawInput) {
            return $null
        }
        $trimmed = Remove-SurroundingQuotes -Value $rawInput
        if ($trimmed -eq '0') {
            return $null
        }
        if ([string]::IsNullOrWhiteSpace($trimmed)) {
            return $drv.DefaultBackupDir
        }
        $expanded = [Environment]::ExpandEnvironmentVariables($trimmed)
        if ($expanded -match '^[A-Za-z]:[^\\/]') {
            throw "备份目标路径格式不完整：$trimmed（请使用完整路径，例如 E:\vhdx-backup）。"
        }
        return [System.IO.Path]::GetFullPath($expanded)
    }
    elseif ($usbDrives.Count -gt 1) {
        Write-Info '检测到多个 USB 存储盘，可输入编号快速选择或直接输入自定义路径：'
        for ($i = 0; $i -lt $usbDrives.Count; $i++) {
            $drv = $usbDrives[$i]
            Write-Host "  [$($i + 1)] $($drv.DefaultBackupDir)  （$($drv.VolumeLabel)，$($drv.DriveFormat)，可用 $(Format-ByteSize -Bytes $drv.AvailableFreeSpace)）" -ForegroundColor White
        }
        $rawInput = Read-Host "请输入编号（1-$($usbDrives.Count)，默认 1）、自定义目录路径，或输入 0 取消"
        if ($null -eq $rawInput) {
            return $null
        }
        $trimmed = Remove-SurroundingQuotes -Value $rawInput
        if ($trimmed -eq '0') {
            return $null
        }
        if ([string]::IsNullOrWhiteSpace($trimmed)) {
            return $usbDrives[0].DefaultBackupDir
        }
        $pick = 0
        if ([int]::TryParse($trimmed, [ref]$pick) -and $pick -ge 1 -and $pick -le $usbDrives.Count) {
            return $usbDrives[$pick - 1].DefaultBackupDir
        }
        $expanded = [Environment]::ExpandEnvironmentVariables($trimmed)
        if ($expanded -match '^[A-Za-z]:[^\\/]') {
            throw "备份目标路径格式不完整：$trimmed（请使用完整路径，例如 E:\vhdx-backup）。"
        }
        return [System.IO.Path]::GetFullPath($expanded)
    }
    else {
        Write-Warn '未检测到可用的 U 盘或 USB 移动硬盘。'
        $rawInput = Read-Host '请手动输入备份目标目录路径（例如 E:\vhdx-backup；直接回车或输入 0 取消）'
        if ($null -eq $rawInput) {
            return $null
        }
        $trimmed = Remove-SurroundingQuotes -Value $rawInput
        if ([string]::IsNullOrWhiteSpace($trimmed) -or $trimmed -eq '0') {
            return $null
        }
        $expanded = [Environment]::ExpandEnvironmentVariables($trimmed)
        if ($expanded -match '^[A-Za-z]:[^\\/]') {
            throw "备份目标路径格式不完整：$trimmed（请使用完整路径，例如 E:\vhdx-backup）。"
        }
        return [System.IO.Path]::GetFullPath($expanded)
    }
}

function Copy-FileWithProgress {
    param(
        [Parameter(Mandatory = $true)][string]$SourcePath,
        [Parameter(Mandatory = $true)][string]$DestinationPath
    )

    $bufferSize = 4 * 1024 * 1024
    $buffer = New-Object byte[] $bufferSize
    $sourceStream = $null
    $destStream = $null
    $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
    [long]$lastReportMs = -1000

    try {
        $sourceStream = [System.IO.File]::Open(
            $SourcePath,
            [System.IO.FileMode]::Open,
            [System.IO.FileAccess]::Read,
            [System.IO.FileShare]::Read
        )
        $destStream = [System.IO.File]::Open(
            $DestinationPath,
            [System.IO.FileMode]::Create,
            [System.IO.FileAccess]::Write,
            [System.IO.FileShare]::None
        )

        [long]$totalBytes = $sourceStream.Length
        [long]$copiedBytes = 0

        while (($bytesRead = $sourceStream.Read($buffer, 0, $buffer.Length)) -gt 0) {
            $destStream.Write($buffer, 0, $bytesRead)
            $copiedBytes += $bytesRead

            $elapsedMs = $stopwatch.ElapsedMilliseconds
            if (($elapsedMs - $lastReportMs) -ge 250 -or $copiedBytes -eq $totalBytes) {
                $lastReportMs = $elapsedMs
                $percent = if ($totalBytes -gt 0) { [math]::Min(100.0, ($copiedBytes * 100.0) / $totalBytes) } else { 100.0 }
                $elapsedSec = [math]::Max(0.001, $stopwatch.Elapsed.TotalSeconds)
                $speedBytesPerSec = $copiedBytes / $elapsedSec
                $etaText = '--:--:--'
                if ($speedBytesPerSec -gt 0 -and $copiedBytes -lt $totalBytes) {
                    $remainingSec = [math]::Max(0, [int][math]::Ceiling(($totalBytes - $copiedBytes) / $speedBytesPerSec))
                    $etaText = [TimeSpan]::FromSeconds($remainingSec).ToString('hh\:mm\:ss')
                }
                elseif ($copiedBytes -eq $totalBytes) {
                    $etaText = '00:00:00'
                }

                $statusLine = ('[进度] {0,5:N1}% | {1} / {2} | {3}/s | 剩余 {4}' -f $percent, (Format-ByteSize -Bytes $copiedBytes), (Format-ByteSize -Bytes $totalBytes), (Format-ByteSize -Bytes ([long]$speedBytesPerSec)), $etaText)
                Write-Host ("`r" + $statusLine.PadRight(76)) -NoNewline -ForegroundColor Cyan
            }
        }

        Write-Host ''
        Write-Info '正在刷新目标磁盘写入缓存...'
        $destStream.Flush($true)
    }
    finally {
        $stopwatch.Stop()
        if ($null -ne $destStream) {
            $destStream.Dispose()
        }
        if ($null -ne $sourceStream) {
            $sourceStream.Dispose()
        }
    }
}

function Update-CopiedSyncConfig {
    param(
        [Parameter(Mandatory = $true)][string]$SyncConfigPath,
        [Parameter(Mandatory = $true)][string]$VhdxFileName,
        [Parameter(Mandatory = $true)][string]$StorageType
    )

    if (-not (Test-Path -LiteralPath $SyncConfigPath -PathType Leaf)) {
        return
    }

    $lines = @(Read-ConfigLines -Path $SyncConfigPath)
    $result = New-Object System.Collections.Generic.List[string]
    $vhdxUpdated = $false
    $typeUpdated = $false
    $relativeVhdx = ".\$VhdxFileName"

    foreach ($line in $lines) {
        if ($line -match '^\s*VhdxPath\s*=') {
            if (-not $vhdxUpdated) {
                $result.Add("VhdxPath=$relativeVhdx")
                $vhdxUpdated = $true
            }
            continue
        }
        if ($line -match '^\s*ImageStorageType\s*=') {
            if (-not $typeUpdated) {
                $result.Add("ImageStorageType=$StorageType")
                $typeUpdated = $true
            }
            continue
        }
        $result.Add($line)
    }

    if (-not $vhdxUpdated) {
        $result.Add("VhdxPath=$relativeVhdx")
    }
    if (-not $typeUpdated) {
        $result.Add("ImageStorageType=$StorageType")
    }

    Write-ConfigLines -Path $SyncConfigPath -Lines $result.ToArray()
}

function Invoke-BackupVhdx {
    Import-ToolConfig -Quiet
    Assert-RequiredCommands
    Assert-VhdxExists

    # Step 1: Ensure VHDX is unmounted before file-level copy.
    $image = Get-VhdxDiskImage
    if ($image.Attached) {
        $driveLetters = @(
            Get-VhdxMountPoints |
                Where-Object { $_ -match '^[A-Za-z]:$' } |
                Select-Object -Unique
        )
        $mountSuffix = if ($driveLetters.Count -gt 0) { "（盘符：$($driveLetters -join ', ')）" } else { '' }
        Write-Warn "检测到虚拟磁盘当前已挂载$mountSuffix，备份前必须先锁定并卸载，以确保 VHDX 文件一致性。"

        $rawConfirmUnmount = Read-Host '是否立即执行锁定并卸载？[Y/n]'
        $confirmUnmount = if ($null -ne $rawConfirmUnmount) { $rawConfirmUnmount.Trim().ToLowerInvariant() } else { '' }
        if ($confirmUnmount -ne '' -and $confirmUnmount -ne 'y' -and $confirmUnmount -ne 'yes') {
            Write-Warn '已取消备份操作。'
            return
        }

        Lock-AndDismountVhdx

        $recheck = Get-VhdxDiskImage
        if ($recheck.Attached) {
            throw '虚拟磁盘仍处于挂载状态，无法继续备份。'
        }
    }

    # Step 2: Check source rclone-sync kit.
    if (-not (Test-Path -LiteralPath $script:RcloneSyncSourceDir -PathType Container)) {
        throw "未找到 rclone 同步套件目录：$script:RcloneSyncSourceDir。请确认目录完整后再执行备份。"
    }

    $sourceRcloneExe = Join-Path -Path $script:RcloneSyncSourceDir -ChildPath 'rclone.exe'
    if (-not (Test-Path -LiteralPath $sourceRcloneExe -PathType Leaf)) {
        Write-Warn "未在 $script:RcloneSyncSourceDir 中检测到 rclone.exe，备份后的同步套件将缺少 rclone 主程序。"
        $rawProceedMissing = Read-Host '是否仍要继续备份？[y/N]'
        $proceedMissing = if ($null -ne $rawProceedMissing) { $rawProceedMissing.Trim().ToLowerInvariant() } else { '' }
        if ($proceedMissing -ne 'y' -and $proceedMissing -ne 'yes') {
            Write-Warn '已取消备份操作。'
            return
        }
    }

    # Step 3: Resolve target backup directory.
    $backupDir = Resolve-BackupTargetDirectory -ExplicitPath $BackupPath
    if ([string]::IsNullOrWhiteSpace($backupDir)) {
        Write-Warn '已取消备份操作。'
        return
    }

    $vhdxFile = Get-Item -LiteralPath $script:VhdxPath
    $destVhdxPath = Join-Path -Path $backupDir -ChildPath $vhdxFile.Name

    $fullSourceVhdx = [System.IO.Path]::GetFullPath($script:VhdxPath)
    $fullDestVhdx = [System.IO.Path]::GetFullPath($destVhdxPath)
    if ($fullSourceVhdx.Equals($fullDestVhdx, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "备份目标文件与源 VHDX 路径相同（$fullDestVhdx），已阻止自覆盖。"
    }

    $fullSourceKit = [System.IO.Path]::GetFullPath($script:RcloneSyncSourceDir).TrimEnd('\') + '\'
    $fullBackupDir = [System.IO.Path]::GetFullPath($backupDir).TrimEnd('\') + '\'
    if ($fullBackupDir.Equals($fullSourceKit, [System.StringComparison]::OrdinalIgnoreCase) -or
        $fullBackupDir.StartsWith($fullSourceKit, [System.StringComparison]::OrdinalIgnoreCase) -or
        $fullSourceKit.StartsWith($fullBackupDir, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "备份目标目录与源 rclone-sync 目录冲突（$backupDir），请更换其他备份路径。"
    }

    $kitItems = @(Get-ChildItem -LiteralPath $script:RcloneSyncSourceDir -Force -ErrorAction Stop)
    foreach ($kitItem in $kitItems) {
        if ($kitItem.Name.Equals($vhdxFile.Name, [System.StringComparison]::OrdinalIgnoreCase)) {
            throw "rclone 同步套件中存在与 VHDX 镜像同名的项目（$($kitItem.Name)），无法平铺复制到同一目录。"
        }
    }

    # Step 4: Validate target drive, FAT32 limit, overwrite confirmation, and free space.
    $targetRoot = [System.IO.Path]::GetPathRoot($backupDir)
    $targetDriveInfo = $null
    if (-not [string]::IsNullOrWhiteSpace($targetRoot) -and $targetRoot -match '^[A-Za-z]:\\$') {
        try {
            $targetDriveInfo = New-Object System.IO.DriveInfo($targetRoot)
            if (-not $targetDriveInfo.IsReady) {
                throw "目标驱动器 $targetRoot 未就绪，请检查磁盘连接状态。"
            }
        }
        catch [System.ArgumentException] {
            throw "无效的目标驱动器路径：$backupDir"
        }
    }

    [long]$vhdxSize = $vhdxFile.Length
    [long]$kitSize = Get-DirectorySizeBytes -Path $script:RcloneSyncSourceDir

    if ($null -ne $targetDriveInfo -and $targetDriveInfo.DriveFormat -eq 'FAT32' -and $vhdxSize -ge [long]4294967295) {
        throw "目标驱动器 $targetRoot 文件系统为 FAT32，不支持大于等于 4 GB 的单个文件（当前 VHDX 大小：$(Format-ByteSize -Bytes $vhdxSize)）。请改用 exFAT 或 NTFS 格式的 U 盘/磁盘。"
    }

    $destExists = Test-Path -LiteralPath $destVhdxPath -PathType Leaf
    [long]$existingDestSize = 0
    if ($destExists) {
        $existingFile = Get-Item -LiteralPath $destVhdxPath
        $existingDestSize = $existingFile.Length
        Write-Host ''
        Write-Warn "目标目录已存在同名备份：$destVhdxPath"
        Write-Info "旧备份信息：大小 $(Format-ByteSize -Bytes $existingDestSize)，修改时间 $($existingFile.LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss'))"
        $rawOverwrite = Read-Host '是否覆盖更新此备份？[Y/n]'
        $overwriteChoice = if ($null -ne $rawOverwrite) { $rawOverwrite.Trim().ToLowerInvariant() } else { '' }
        if ($overwriteChoice -ne '' -and $overwriteChoice -ne 'y' -and $overwriteChoice -ne 'yes') {
            Write-Warn '已取消备份操作。'
            return
        }
    }

    $useAtomicTemp = $true
    if ($null -ne $targetDriveInfo) {
        [long]$freeBytes = $targetDriveInfo.AvailableFreeSpace
        [long]$safeOverhead = 32MB
        [long]$atomicRequired = $vhdxSize + $kitSize + $safeOverhead

        if ($freeBytes -lt $atomicRequired) {
            [long]$directRequired = $vhdxSize + $kitSize + 16MB
            if ($destExists -and ($freeBytes + $existingDestSize) -ge $directRequired) {
                Write-Warn "目标盘当前剩余空间为 $(Format-ByteSize -Bytes $freeBytes)，不足以先写临时文件再原子替换（需 $(Format-ByteSize -Bytes $atomicRequired)），但直接覆盖旧备份空间足够。"
                $rawDirect = Read-Host '是否改为直接覆盖旧备份（注意：若中途断电或拔盘会损坏旧备份）？[y/N]'
                $directChoice = if ($null -ne $rawDirect) { $rawDirect.Trim().ToLowerInvariant() } else { '' }
                if ($directChoice -ne 'y' -and $directChoice -ne 'yes') {
                    Write-Warn '已取消备份操作。'
                    return
                }
                $useAtomicTemp = $false
            }
            else {
                throw "目标磁盘 $targetRoot 可用空间不足。需要约 $(Format-ByteSize -Bytes ($vhdxSize + $kitSize))，当前仅剩 $(Format-ByteSize -Bytes $freeBytes)。"
            }
        }
    }

    # Step 5: Execute backup copy.
    Write-Host ''
    Write-Info "准备备份到：$backupDir"
    Write-Info "源镜像：$script:VhdxPath（$(Format-ByteSize -Bytes $vhdxSize)）"
    Write-Info "同步套件：$script:RcloneSyncSourceDir（$(Format-ByteSize -Bytes $kitSize)）"

    if (-not (Test-Path -LiteralPath $backupDir -PathType Container)) {
        New-Item -ItemType Directory -Path $backupDir -Force -ErrorAction Stop | Out-Null
    }

    if ($useAtomicTemp) {
        $tempDestVhdx = Join-Path -Path $backupDir -ChildPath ($vhdxFile.Name + ".$PID.backup.tmp")
        Write-Info "正在安全复制 VHDX 镜像（临时文件原子替换模式）..."
        try {
            Copy-FileWithProgress -SourcePath $script:VhdxPath -DestinationPath $tempDestVhdx

            $copiedSize = (Get-Item -LiteralPath $tempDestVhdx).Length
            if ($copiedSize -ne $vhdxSize) {
                throw "复制后文件大小校验不一致（预期 $vhdxSize 字节，实际 $copiedSize 字节）。"
            }

            if (Test-Path -LiteralPath $destVhdxPath -PathType Leaf) {
                try {
                    [System.IO.File]::Replace($tempDestVhdx, $destVhdxPath, $null, $true)
                }
                catch {
                    # FAT32/exFAT volumes may not support ReplaceFileW; fall back to remove + move.
                    Remove-Item -LiteralPath $destVhdxPath -Force -ErrorAction Stop
                    Move-Item -LiteralPath $tempDestVhdx -Destination $destVhdxPath -Force -ErrorAction Stop
                }
            }
            else {
                Move-Item -LiteralPath $tempDestVhdx -Destination $destVhdxPath -Force -ErrorAction Stop
            }
        }
        catch {
            if (Test-Path -LiteralPath $tempDestVhdx -PathType Leaf) {
                Remove-Item -LiteralPath $tempDestVhdx -Force -ErrorAction SilentlyContinue
            }
            throw
        }
    }
    else {
        Write-Info '正在直接覆盖复制 VHDX 镜像...'
        Copy-FileWithProgress -SourcePath $script:VhdxPath -DestinationPath $destVhdxPath
        $copiedSize = (Get-Item -LiteralPath $destVhdxPath).Length
        if ($copiedSize -ne $vhdxSize) {
            throw "复制后文件大小校验不一致（预期 $vhdxSize 字节，实际 $copiedSize 字节）。"
        }
    }
    Write-Ok "VHDX 镜像备份完成：$destVhdxPath"

    # Step 6: Copy rclone-sync kit files directly into $backupDir alongside the VHDX and adapt sync-config.ini.
    Write-Info "正在将 rclone 同步套件复制到备份目录（与镜像同目录）：$backupDir"
    foreach ($kitItem in $kitItems) {
        $destItemPath = Join-Path -Path $backupDir -ChildPath $kitItem.Name
        if ($kitItem.PSIsContainer) {
            if (Test-Path -LiteralPath $destItemPath) {
                Remove-Item -LiteralPath $destItemPath -Recurse -Force -ErrorAction Stop
            }
            Copy-Item -LiteralPath $kitItem.FullName -Destination $destItemPath -Recurse -Force -ErrorAction Stop
        }
        else {
            Copy-Item -LiteralPath $kitItem.FullName -Destination $destItemPath -Force -ErrorAction Stop
        }
    }

    $copiedSyncConfig = Join-Path -Path $backupDir -ChildPath 'sync-config.ini'
    Update-CopiedSyncConfig -SyncConfigPath $copiedSyncConfig -VhdxFileName $vhdxFile.Name -StorageType $script:ImageStorageType

    $legacyKitDir = Join-Path -Path $backupDir -ChildPath 'rclone-sync'
    if (Test-Path -LiteralPath $legacyKitDir -PathType Container) {
        Write-Warn "检测到旧版备份遗留的 rclone-sync 子目录：$legacyKitDir。新版同步脚本已直接放在 $backupDir，旧子目录可按需手动删除。"
    }

    Write-Ok "rclone 同步套件已复制并配置完成：$backupDir"
    Write-Host ''
    $syncCmdPath = Join-Path -Path $backupDir -ChildPath 'sync.cmd'
    Write-Ok "全部备份已完成！后续可在任意 Windows 电脑上双击 $syncCmdPath 挂载解锁备份 VHDX 并执行 rclone sync。"
    Show-WindowsNotification -Title 'VHDX BitLocker 备份完成' -Message "已备份到 $backupDir" -Level 'Info'
}

# =========================
# Auto-Start Management (Task Scheduler)
# =========================
function Write-AutoStartLog {
    param(
        [Parameter(Mandatory = $true)][string]$Message,
        [ValidateSet('信息', '成功', '警告', '错误')][string]$Level = '信息'
    )

    try {
        $timestamp = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
        $entry = "[$timestamp] [$Level] $Message"
        $utf8NoBom = New-Object System.Text.UTF8Encoding($false)

        $lines = New-Object System.Collections.Generic.List[string]
        if (Test-Path -LiteralPath $script:AutoStartLogPath -PathType Leaf) {
            foreach ($existing in [System.IO.File]::ReadAllLines($script:AutoStartLogPath, $utf8NoBom)) {
                $lines.Add($existing)
            }
        }

        $lines.Add($entry)

        $maxLines = 200
        if ($lines.Count -gt $maxLines) {
            $startIndex = $lines.Count - $maxLines
            $trimmed = New-Object System.Collections.Generic.List[string]
            for ($i = $startIndex; $i -lt $lines.Count; $i++) {
                $trimmed.Add($lines[$i])
            }
            $lines = $trimmed
        }

        [System.IO.File]::WriteAllLines($script:AutoStartLogPath, $lines.ToArray(), $utf8NoBom)
    }
    catch {
        # Auto-start log persistence is best-effort and must never interrupt mounting.
    }
}

function Get-AutoStartLogLines {
    param([int]$Tail = 30)

    if (-not (Test-Path -LiteralPath $script:AutoStartLogPath -PathType Leaf)) {
        return @()
    }

    try {
        $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
        $allLines = @([System.IO.File]::ReadAllLines($script:AutoStartLogPath, $utf8NoBom))
        if ($Tail -le 0 -or $allLines.Count -le $Tail) {
            return $allLines
        }
        return @($allLines[($allLines.Count - $Tail)..($allLines.Count - 1)])
    }
    catch {
        return @()
    }
}

function Clear-AutoStartLog {
    if (-not (Test-Path -LiteralPath $script:AutoStartLogPath -PathType Leaf)) {
        Write-Info '当前没有可清理的自启动日志文件。'
        return
    }

    Remove-Item -LiteralPath $script:AutoStartLogPath -Force -ErrorAction Stop
    Write-Ok "已清理自启动日志：$script:AutoStartLogPath"
}

function Get-AutoStartTaskName {
    $keyText = [System.IO.Path]::GetFullPath($script:ConfigPath).ToLowerInvariant()
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($keyText)
        $hashBytes = $sha.ComputeHash($bytes)
        $hash = ([BitConverter]::ToString($hashBytes)).Replace('-', '').Substring(0, 8)
    }
    finally {
        $sha.Dispose()
    }

    return "VhdBitLocker_AutoMount_$hash"
}

function Get-MissingAutoStartCommands {
    $requiredCommands = @(
        'Get-ScheduledTask',
        'Register-ScheduledTask',
        'Unregister-ScheduledTask',
        'Enable-ScheduledTask',
        'Disable-ScheduledTask',
        'Start-ScheduledTask',
        'Get-ScheduledTaskInfo',
        'New-ScheduledTaskAction',
        'New-ScheduledTaskTrigger',
        'New-ScheduledTaskPrincipal',
        'New-ScheduledTaskSettingsSet'
    )

    $missing = @()
    foreach ($cmd in $requiredCommands) {
        if (-not (Get-Command -Name $cmd -ErrorAction SilentlyContinue)) {
            $missing += $cmd
        }
    }

    return $missing
}

function Assert-AutoStartCommands {
    $missing = @(Get-MissingAutoStartCommands)
    if ($missing.Count -gt 0) {
        throw "缺少 Windows 计划任务管理命令：$($missing -join ', ')。请确认系统 ScheduledTasks 模块可用。"
    }
}

function Get-CurrentUserIdentityInfo {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $sid = if ($null -ne $identity.User) { $identity.User.Value } else { '' }
    return [pscustomobject]@{
        Name = $identity.Name
        Sid  = $sid
    }
}

function Resolve-AccountSid {
    param([string]$Account)

    if ([string]::IsNullOrWhiteSpace($Account)) {
        return $null
    }

    $trimmed = $Account.Trim()
    try {
        if ($trimmed -match '^S-\d-\d+(-\d+)+$') {
            return (New-Object System.Security.Principal.SecurityIdentifier($trimmed)).Value
        }

        $ntAccount = New-Object System.Security.Principal.NTAccount($trimmed)
        return $ntAccount.Translate([System.Security.Principal.SecurityIdentifier]).Value
    }
    catch {
        return $null
    }
}

function Test-TaskUserMatchesCurrent {
    param(
        [string]$TaskUserId,
        [Parameter(Mandatory = $true)]$CurrentUser
    )

    if ([string]::IsNullOrWhiteSpace($TaskUserId)) {
        return $false
    }

    $trimmed = $TaskUserId.Trim()
    if ($trimmed.Equals($CurrentUser.Name, [System.StringComparison]::OrdinalIgnoreCase) -or
        (-not [string]::IsNullOrWhiteSpace($CurrentUser.Sid) -and $trimmed.Equals($CurrentUser.Sid, [System.StringComparison]::OrdinalIgnoreCase))) {
        return $true
    }

    $taskSid = Resolve-AccountSid -Account $trimmed
    if (-not [string]::IsNullOrWhiteSpace($taskSid) -and -not [string]::IsNullOrWhiteSpace($CurrentUser.Sid)) {
        return $taskSid.Equals($CurrentUser.Sid, [System.StringComparison]::OrdinalIgnoreCase)
    }

    # Handle bare username vs DOMAIN\username fallback if translation fails.
    $currentShort = if ($CurrentUser.Name -match '\\([^\\]+)$') { $matches[1] } else { $CurrentUser.Name }
    $taskShort = if ($trimmed -match '\\([^\\]+)$') { $matches[1] } else { $trimmed }
    return $currentShort.Equals($taskShort, [System.StringComparison]::OrdinalIgnoreCase)
}

function ConvertFrom-TaskDelayToSeconds {
    param([string]$DelayText)

    if ([string]::IsNullOrWhiteSpace($DelayText)) {
        return 0
    }

    try {
        $ts = [System.Xml.XmlConvert]::ToTimeSpan($DelayText.Trim())
        return [int][math]::Max(0, [math]::Round($ts.TotalSeconds))
    }
    catch {
        return -1
    }
}

function Format-TaskResultCode {
    param($ResultCode)

    if ($null -eq $ResultCode) {
        return '未知'
    }

    try {
        $unsigned = [uint32]([BitConverter]::ToUInt32([BitConverter]::GetBytes([int]$ResultCode), 0))
    }
    catch {
        try {
            $unsigned = [uint32]$ResultCode
        }
        catch {
            return "$ResultCode"
        }
    }

    $hex = ('0x{0:X}' -f $unsigned)
    switch ($unsigned) {
        0 { return "成功 ($hex)" }
        1 { return "脚本执行失败 ($hex)" }
        267008 { return "已就绪 ($hex)" }
        267009 { return "正在运行 ($hex)" }
        267010 { return "任务已禁用 ($hex)" }
        267011 { return "尚未运行 ($hex)" }
        267014 { return "上次运行被终止 ($hex)" }
        2147942402 { return "找不到执行程序或文件 ($hex)" }
        2147943623 { return "操作已取消 ($hex)" }
        default { return "状态码 $hex" }
    }
}

function Get-ExistingAutoStartTask {
    param([Parameter(Mandatory = $true)][string]$TaskName)

    try {
        return Get-ScheduledTask -TaskName $TaskName -TaskPath '\' -ErrorAction Stop
    }
    catch {
        if ($null -ne $_.CategoryInfo -and $_.CategoryInfo.Category -eq [System.Management.Automation.ErrorCategory]::ObjectNotFound) {
            return $null
        }
        if ($_.Exception.Message -match 'No MSFT_ScheduledTask objects found') {
            return $null
        }
        throw
    }
}

function Get-AutoStartSnapshot {
    $taskName = Get-AutoStartTaskName
    $currentUser = Get-CurrentUserIdentityInfo
    $missing = @(Get-MissingAutoStartCommands)

    $snapshot = [ordered]@{
        TaskName           = $taskName
        TaskPath           = '\'
        CurrentUserName    = $currentUser.Name
        MissingCommands    = $missing
        QueryError         = $null
        Exists             = $false
        State              = 'NotInstalled'
        Enabled            = $false
        PrincipalUser      = $null
        RunLevel           = $null
        LogonType          = $null
        UserMatchesCurrent = $false
        ExecutePath        = $null
        Arguments          = $null
        DelaySeconds       = $script:AutoStartDelaySeconds
        HasRun             = $false
        LastRunTime        = $null
        LastTaskResult     = $null
        LastTaskResultText = '尚未运行'
        Issues             = @()
        NeedsRepair        = $false
        LatestLogLine      = $null
    }

    $tailLines = @(Get-AutoStartLogLines -Tail 1)
    if ($tailLines.Count -gt 0 -and -not [string]::IsNullOrWhiteSpace($tailLines[0])) {
        $snapshot.LatestLogLine = $tailLines[0]
    }

    if ($missing.Count -gt 0) {
        return [pscustomobject]$snapshot
    }

    try {
        $task = Get-ExistingAutoStartTask -TaskName $taskName
        if ($null -eq $task) {
            return [pscustomobject]$snapshot
        }

        $snapshot.Exists = $true
        $snapshot.State = [string]$task.State
        $snapshot.Enabled = ($snapshot.State -ne 'Disabled')

        if ($null -ne $task.Principal) {
            $snapshot.PrincipalUser = [string]$task.Principal.UserId
            $snapshot.RunLevel = [string]$task.Principal.RunLevel
            $snapshot.LogonType = [string]$task.Principal.LogonType
            $snapshot.UserMatchesCurrent = Test-TaskUserMatchesCurrent -TaskUserId $snapshot.PrincipalUser -CurrentUser $currentUser
        }

        $issues = @()
        if (-not $snapshot.UserMatchesCurrent) {
            $issues += "运行账户（$($snapshot.PrincipalUser)）与当前账户（$($currentUser.Name)）不一致，DPAPI 密码可能无法解密"
        }
        if ($snapshot.RunLevel -ne 'Highest') {
            $issues += '未启用最高权限运行（需要管理员权限才能挂载和解锁）'
        }
        if ($snapshot.LogonType -ne 'Interactive') {
            $issues += "登录类型非交互式会话（当前：$($snapshot.LogonType)），可能无法解密 DPAPI 密码"
        }

        $primaryAction = @($task.Actions) | Select-Object -First 1
        if ($null -ne $primaryAction) {
            $snapshot.ExecutePath = [string]$primaryAction.Execute
            $snapshot.Arguments = [string]$primaryAction.Arguments

            $cleanExec = Remove-SurroundingQuotes -Value $snapshot.ExecutePath
            if ([string]::IsNullOrWhiteSpace($cleanExec) -or -not (Test-Path -LiteralPath $cleanExec -PathType Leaf)) {
                $issues += "任务配置的 PowerShell 可执行文件不存在：$($snapshot.ExecutePath)"
            }

            $expectedScript = [System.IO.Path]::GetFullPath($PSCommandPath)
            if ([string]::IsNullOrWhiteSpace($snapshot.Arguments) -or
                $snapshot.Arguments.IndexOf($expectedScript, [System.StringComparison]::OrdinalIgnoreCase) -lt 0 -or
                $snapshot.Arguments -notmatch '(?i)-Action\s+AutoMount\b') {
                $issues += '任务脚本路径或启动参数与当前工具不一致'
            }
        }
        else {
            $issues += '计划任务缺少执行动作'
        }

        $logonTrigger = @($task.Triggers) | Where-Object {
            $null -ne $_ -and $null -ne $_.CimClass -and $_.CimClass.CimClassName -eq 'MSFT_TaskLogonTrigger'
        } | Select-Object -First 1

        if ($null -ne $logonTrigger) {
            $parsedDelay = ConvertFrom-TaskDelayToSeconds -DelayText ([string]$logonTrigger.Delay)
            if ($parsedDelay -ge 0) {
                $snapshot.DelaySeconds = $parsedDelay
            }
        }
        else {
            $issues += '计划任务缺少用户登录触发器（AtLogOn）'
        }

        try {
            $info = Get-ScheduledTaskInfo -TaskName $taskName -TaskPath '\' -ErrorAction Stop
            if ($null -ne $info) {
                $snapshot.LastTaskResult = $info.LastTaskResult
                $snapshot.LastTaskResultText = Format-TaskResultCode -ResultCode $info.LastTaskResult
                if ($null -ne $info.LastRunTime -and $info.LastRunTime.Year -ge 2000) {
                    $snapshot.HasRun = $true
                    $snapshot.LastRunTime = $info.LastRunTime
                }
            }
        }
        catch {
            # Task runtime metadata is best-effort.
        }

        $snapshot.Issues = $issues
        $snapshot.NeedsRepair = ($issues.Count -gt 0)
    }
    catch {
        $snapshot.QueryError = $_.Exception.Message
    }

    return [pscustomobject]$snapshot
}

function Read-AutoStartDelayInput {
    param([int]$DefaultSeconds = 10)

    while ($true) {
        Write-Info '登录后延迟一段时间再执行挂载，可等待系统磁盘、BitLocker 服务和桌面就绪（推荐 5-15 秒）。'
        $raw = Read-Host "请输入登录后延迟秒数（0-300，默认 $DefaultSeconds，直接回车采用，输入 C 取消）"
        if ($null -eq $raw) {
            return $null
        }

        $trimmed = $raw.Trim()
        if ($trimmed.Length -eq 0) {
            return $DefaultSeconds
        }
        if ($trimmed -match '^(?i)(c|q|cancel)$') {
            return $null
        }

        $parsed = 0
        if ([int]::TryParse($trimmed, [ref]$parsed) -and $parsed -ge 0 -and $parsed -le 300) {
            return $parsed
        }

        Write-Warn '输入无效，请输入 0 到 300 之间的整数，或输入 C 取消。'
    }
}

function Enable-OrUpdateAutoStart {
    param(
        [int]$DelaySecondsOverride = -1,
        [switch]$Interactive
    )

    Import-ToolConfig -Quiet
    Assert-AutoStartCommands

    if (-not (Test-Path -LiteralPath $script:VhdxPath -PathType Leaf)) {
        Write-Warn "当前配置的虚拟磁盘文件不存在：$script:VhdxPath"
        if ($Interactive) {
            $rawContinueMissing = Read-Host '仍要继续配置开机自启动吗？[y/N]'
            $continueChoice = if ($null -ne $rawContinueMissing) { $rawContinueMissing.Trim().ToLowerInvariant() } else { '' }
            if ($continueChoice -ne 'y' -and $continueChoice -ne 'yes') {
                Write-Warn '已取消配置开机自启动。'
                return
            }
        }
    }

    $pwCheck = Test-SavedPasswordState
    if ($pwCheck.State -ne 'SavedValid') {
        $reason = if ($pwCheck.State -eq 'SavedInvalid') {
            'config.ini 中保存的密码无法被当前账户解密'
        }
        else {
            'config.ini 中尚未保存 BitLocker 密码'
        }

        if ($Interactive) {
            Write-Warn "开机自动解密挂载需要本地已保存且可读的 DPAPI 密码，但当前 $reason。"
            $rawSetPw = Read-Host '是否现在设置并保存 BitLocker 密码？[Y/n]'
            $setPwChoice = if ($null -ne $rawSetPw) { $rawSetPw.Trim().ToLowerInvariant() } else { '' }
            if ($setPwChoice -ne '' -and $setPwChoice -ne 'y' -and $setPwChoice -ne 'yes') {
                Write-Warn '未保存密码，已取消启用开机自启动。'
                return
            }

            Write-Host ''
            Set-NewStoredPassword
            Write-Host ''

            $pwCheck = Test-SavedPasswordState
            if ($pwCheck.State -ne 'SavedValid') {
                Write-Warn '本地密码仍未就绪，已取消启用开机自启动。'
                return
            }
        }
        else {
            throw "无法启用开机自启动：$reason。请先执行密码设置（start.cmd -Action SetPassword）后再启用。"
        }
    }

    $existingSnapshot = Get-AutoStartSnapshot
    $defaultDelay = if ($existingSnapshot.Exists -and $existingSnapshot.DelaySeconds -ge 0) {
        $existingSnapshot.DelaySeconds
    }
    else {
        $script:AutoStartDelaySeconds
    }

    $chosenDelay = $defaultDelay
    if ($DelaySecondsOverride -ge 0) {
        if ($DelaySecondsOverride -gt 300) {
            throw "延迟秒数必须在 0 到 300 之间（当前：$DelaySecondsOverride）。"
        }
        $chosenDelay = $DelaySecondsOverride
    }
    elseif ($Interactive) {
        $inputDelay = Read-AutoStartDelayInput -DefaultSeconds $defaultDelay
        if ($null -eq $inputDelay) {
            Write-Warn '已取消配置开机自启动。'
            return
        }
        $chosenDelay = $inputDelay
    }

    $taskName = Get-AutoStartTaskName
    $currentUser = Get-CurrentUserIdentityInfo
    $psExe = Get-PreferredPowerShellExecutable
    $scriptFullPath = [System.IO.Path]::GetFullPath($PSCommandPath)
    $argString = "-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$scriptFullPath`" -Action AutoMount"

    $actionObj = New-ScheduledTaskAction -Execute $psExe -Argument $argString -WorkingDirectory $script:BaseDirectory
    $triggerObj = New-ScheduledTaskTrigger -AtLogOn -User $currentUser.Name
    if ($chosenDelay -gt 0) {
        $triggerObj.Delay = "PT${chosenDelay}S"
    }

    $principalObj = New-ScheduledTaskPrincipal -UserId $currentUser.Name -LogonType Interactive -RunLevel Highest
    $settingsObj = New-ScheduledTaskSettingsSet `
        -AllowStartIfOnBatteries `
        -DontStopIfGoingOnBatteries `
        -StartWhenAvailable `
        -MultipleInstances IgnoreNew `
        -ExecutionTimeLimit (New-TimeSpan -Minutes 5)

    $description = "自动挂载并解锁 VHDX BitLocker 虚拟磁盘（工具目录：$script:BaseDirectory；镜像：$script:VhdxPath）"

    Write-Info "正在注册 Windows 计划任务：$taskName ..."
    Register-ScheduledTask `
        -TaskName $taskName `
        -TaskPath '\' `
        -Action $actionObj `
        -Trigger $triggerObj `
        -Principal $principalObj `
        -Settings $settingsObj `
        -Description $description `
        -Force `
        -ErrorAction Stop | Out-Null

    try {
        Enable-ScheduledTask -TaskName $taskName -TaskPath '\' -ErrorAction SilentlyContinue | Out-Null
    }
    catch {
        # Newly registered task is enabled by default.
    }

    $script:AutoStartDelaySeconds = $chosenDelay
    Set-ConfigValue -Name 'AutoStartDelaySeconds' -Value "$chosenDelay"

    Write-Ok '开机自启动任务已启用并配置完成！'
    Write-Info "任务名称：$taskName"
    Write-Info "运行账户：$($currentUser.Name)（最高权限，登录时免 UAC 自动运行）"
    Write-Info "启动延迟：$chosenDelay 秒"
    Write-Info "执行程序：$psExe"
}

function Set-AutoStartEnabledState {
    param([Parameter(Mandatory = $true)][bool]$Enable)

    Import-ToolConfig -Quiet
    Assert-AutoStartCommands

    $snapshot = Get-AutoStartSnapshot
    if (-not $snapshot.Exists) {
        if ($Enable) {
            Write-Warn '当前尚未创建开机自启动任务，请先执行「启用 / 更新开机自动解密挂载」。'
        }
        else {
            Write-Info '当前未配置开机自启动任务，无需暂停。'
        }
        return
    }

    if ($Enable) {
        Enable-ScheduledTask -TaskName $snapshot.TaskName -TaskPath '\' -ErrorAction Stop | Out-Null
        Write-Ok "已恢复启用开机自启动任务：$($snapshot.TaskName)"

        $pwCheck = Test-SavedPasswordState
        if ($pwCheck.State -ne 'SavedValid') {
            Write-Warn '注意：当前本地密码未保存或无法解密，下次登录将无法自动解锁，请前往「密码维护」重新保存密码。'
        }
        if ($snapshot.NeedsRepair) {
            Write-Warn '检测到任务配置存在异常，建议执行「启用 / 更新开机自动解密挂载」以刷新修复配置。'
        }
    }
    else {
        Disable-ScheduledTask -TaskName $snapshot.TaskName -TaskPath '\' -ErrorAction Stop | Out-Null
        Write-Ok "已暂停（禁用）开机自启动任务：$($snapshot.TaskName)（任务配置已保留，可随时恢复）"
    }
}

function Toggle-AutoStartEnabledState {
    Import-ToolConfig -Quiet
    Assert-AutoStartCommands

    $snapshot = Get-AutoStartSnapshot
    if (-not $snapshot.Exists) {
        Write-Warn '当前尚未创建开机自启动任务，请先选择「[1] 启用 / 更新开机自动解密挂载」。'
        return
    }

    if ($snapshot.Enabled) {
        Set-AutoStartEnabledState -Enable $false
    }
    else {
        Set-AutoStartEnabledState -Enable $true
    }
}

function Remove-AutoStartTask {
    param([switch]$RequireConfirm)

    Assert-AutoStartCommands

    $snapshot = Get-AutoStartSnapshot
    if (-not $snapshot.Exists) {
        Write-Info '当前未配置开机自启动任务，无需删除。'
        return
    }

    if ($RequireConfirm) {
        $rawConfirm = Read-Host "确认永久删除开机自启动任务 $($snapshot.TaskName) 吗？[y/N]"
        $confirm = if ($null -ne $rawConfirm) { $rawConfirm.Trim().ToLowerInvariant() } else { '' }
        if ($confirm -ne 'y' -and $confirm -ne 'yes') {
            Write-Warn '已取消删除开机自启动任务。'
            return
        }
    }

    Unregister-ScheduledTask -TaskName $snapshot.TaskName -TaskPath '\' -Confirm:$false -ErrorAction Stop
    Write-Ok "已删除开机自启动任务：$($snapshot.TaskName)"
}

function Invoke-TestAutoStartTask {
    Import-ToolConfig -Quiet
    Assert-AutoStartCommands

    $snapshot = Get-AutoStartSnapshot
    if (-not $snapshot.Exists) {
        Write-Warn '当前尚未创建开机自启动任务，请先选择「[1] 启用 / 更新开机自动解密挂载」。'
        return
    }

    if (-not $snapshot.Enabled) {
        Write-Warn '当前自启动任务处于暂停（已禁用）状态，请先选择「[2] 暂停 / 恢复开机自启动」恢复后再测试。'
        return
    }

    if ($snapshot.NeedsRepair) {
        Write-Warn '检测到任务配置存在以下问题，建议先更新任务再测试：'
        foreach ($issue in $snapshot.Issues) {
            Write-Warn "  - $issue"
        }
        $rawProceed = Read-Host '仍要直接测试运行当前任务吗？[y/N]'
        $proceedChoice = if ($null -ne $rawProceed) { $rawProceed.Trim().ToLowerInvariant() } else { '' }
        if ($proceedChoice -ne 'y' -and $proceedChoice -ne 'yes') {
            Write-Warn '已取消测试运行。'
            return
        }
    }

    $pwCheck = Test-SavedPasswordState
    if ($pwCheck.State -ne 'SavedValid') {
        Write-Warn '当前本地密码未保存或无法解密，自动任务必定解锁失败。请先在「密码维护」中保存密码。'
        return
    }

    if (Test-Path -LiteralPath $script:VhdxPath -PathType Leaf) {
        try {
            $img = Get-VhdxDiskImage
            if ($img.Attached) {
                Write-Info '提示：虚拟磁盘当前已处于挂载状态。本次测试将通过计划任务验证后台调度、最高权限运行及 DPAPI 密码解密流程（如需验证从零挂载，可先卸载后再测）。'
            }
        }
        catch {
        }
    }

    $beforeInfo = Get-ScheduledTaskInfo -TaskName $snapshot.TaskName -TaskPath '\' -ErrorAction SilentlyContinue
    $beforeRunTime = if ($null -ne $beforeInfo) { $beforeInfo.LastRunTime } else { [DateTime]::MinValue }
    $beforeLogCount = @(Get-AutoStartLogLines -Tail 0).Count

    Write-Info "正在通过 Windows 计划任务触发测试运行：$($snapshot.TaskName) ..."

    $mutexReleased = $false
    try {
        # Release the interactive menu mutex temporarily so the background Scheduled Task can acquire it.
        if ($null -ne $script:RunMutex) {
            Exit-NamedMutex -Mutex $script:RunMutex
            $script:RunMutex = $null
            $mutexReleased = $true
        }

        Start-ScheduledTask -TaskName $snapshot.TaskName -TaskPath '\' -ErrorAction Stop

        $startDeadline = (Get-Date).AddSeconds(10)
        $sawRunning = $false
        $sawCompleted = $false

        while ((Get-Date) -lt $startDeadline) {
            Start-Sleep -Milliseconds 300
            $t = Get-ExistingAutoStartTask -TaskName $snapshot.TaskName
            if ($null -ne $t -and [string]$t.State -eq 'Running') {
                $sawRunning = $true
                break
            }
            $infoNow = Get-ScheduledTaskInfo -TaskName $snapshot.TaskName -TaskPath '\' -ErrorAction SilentlyContinue
            if ($null -ne $infoNow -and $infoNow.LastRunTime -gt $beforeRunTime) {
                $sawCompleted = $true
                break
            }
        }

        if ($sawRunning -and -not $sawCompleted) {
            Write-Info '计划任务正在后台执行，等待完成...'
            $finishDeadline = (Get-Date).AddSeconds($script:MountWaitSeconds + 35)
            while ((Get-Date) -lt $finishDeadline) {
                Start-Sleep -Milliseconds 400
                $t = Get-ExistingAutoStartTask -TaskName $snapshot.TaskName
                if ($null -eq $t -or [string]$t.State -ne 'Running') {
                    $sawCompleted = $true
                    break
                }
            }

            if (-not $sawCompleted) {
                Write-Warn '等待计划任务完成超时，任务可能仍在后台运行。请稍后刷新状态或查看运行日志。'
            }
        }
    }
    finally {
        if ($mutexReleased -and -not [string]::IsNullOrWhiteSpace($script:RunMutexName)) {
            $reacquireDeadline = (Get-Date).AddSeconds(3)
            while ((Get-Date) -lt $reacquireDeadline) {
                $script:RunMutex = Enter-NamedMutex -Name $script:RunMutexName
                if ($null -ne $script:RunMutex) {
                    break
                }
                Start-Sleep -Milliseconds 150
            }
        }
    }

    $afterInfo = Get-ScheduledTaskInfo -TaskName $snapshot.TaskName -TaskPath '\' -ErrorAction SilentlyContinue
    Write-Host ''
    if ($null -ne $afterInfo) {
        $resultText = Format-TaskResultCode -ResultCode $afterInfo.LastTaskResult
        $runTimeText = if ($afterInfo.LastRunTime.Year -ge 2000) { $afterInfo.LastRunTime.ToString('yyyy-MM-dd HH:mm:ss') } else { '未知' }
        if ($afterInfo.LastTaskResult -eq 0) {
            Write-Ok "计划任务测试运行成功！运行时间：$runTimeText | 返回结果：$resultText"
        }
        else {
            Write-Fail "计划任务测试运行异常！运行时间：$runTimeText | 返回结果：$resultText"
        }
    }

    $allLogLines = @(Get-AutoStartLogLines -Tail 0)
    if ($allLogLines.Count -gt $beforeLogCount) {
        Write-Host ''
        Write-Info '本次测试产生的运行日志：'
        for ($i = $beforeLogCount; $i -lt $allLogLines.Count; $i++) {
            Write-Host "  $($allLogLines[$i])" -ForegroundColor Gray
        }
    }
    elseif ($allLogLines.Count -gt 0) {
        Write-Host ''
        Write-Info '最近日志记录：'
        foreach ($line in @(Get-AutoStartLogLines -Tail 5)) {
            Write-Host "  $line" -ForegroundColor Gray
        }
    }
}

function Invoke-AutoMount {
    $currentUser = Get-CurrentUserIdentityInfo
    Write-AutoStartLog -Level '信息' -Message "开始执行开机自动解密挂载（账户：$($currentUser.Name)）"

    try {
        Import-ToolConfig -Quiet
        Assert-RequiredCommands

        $pwCheck = Test-SavedPasswordState
        if ($pwCheck.State -eq 'NotSaved') {
            throw 'config.ini 中未保存 BitLocker 密码（PasswordSecret 为空），无法执行自动解锁。请进入主菜单「密码维护」保存密码。'
        }
        if ($pwCheck.State -eq 'SavedInvalid') {
            throw "当前账户（$($currentUser.Name)）无法解密已保存的 DPAPI 密码：$($pwCheck.Error)"
        }

        # Shortly after Windows logon, secondary/external drives may still be coming online.
        if (-not (Test-Path -LiteralPath $script:VhdxPath -PathType Leaf)) {
            Write-AutoStartLog -Level '信息' -Message "等待虚拟磁盘文件就绪：$script:VhdxPath"
            $fileDeadline = (Get-Date).AddSeconds(15)
            while ((Get-Date) -lt $fileDeadline) {
                Start-Sleep -Seconds 1
                if (Test-Path -LiteralPath $script:VhdxPath -PathType Leaf) {
                    break
                }
            }
        }

        Assert-VhdxExists
        Mount-AndUnlockVhdx -NonInteractive

        $volumes = @(Get-VhdxBitLockerVolumes)
        $summary = Format-MountPointSummary -MountPoints @($volumes | ForEach-Object { $_.MountPoint })
        $okMsg = if ($summary) { "自动解密挂载完成：$summary" } else { '自动解密挂载完成。' }
        Write-AutoStartLog -Level '成功' -Message $okMsg
    }
    catch {
        $script:AutoMountFailureLogged = $true
        Write-AutoStartLog -Level '错误' -Message $_.Exception.Message
        throw
    }
}

# =========================
# Status Inspection & UI
# =========================
function Get-VhdxStatusSnapshot {
    $snapshot = [ordered]@{
        ConfigError      = $null
        QueryError       = $null
        VhdxPath         = $script:VhdxPath
        ImageStorageType = $script:ImageStorageType
        SafeUnmountOnly  = $script:SafeUnmountOnly
        FileExists       = $false
        MissingCommands  = @()
        Attached         = $false
        DiskNumber       = $null
        BitLockerVolumes = @()
        DriveLetters     = @()
        PasswordState    = 'NotSaved'
        PasswordError    = $null
        AutoStart        = $null
    }

    try {
        Import-ToolConfig -Quiet
    }
    catch {
        $snapshot.ConfigError = $_.Exception.Message
        return [pscustomobject]$snapshot
    }

    $snapshot.VhdxPath = $script:VhdxPath
    $snapshot.ImageStorageType = $script:ImageStorageType
    $snapshot.SafeUnmountOnly = $script:SafeUnmountOnly
    $snapshot.FileExists = Test-Path -LiteralPath $script:VhdxPath -PathType Leaf

    $pwCheck = Test-SavedPasswordState
    $snapshot.PasswordState = $pwCheck.State
    $snapshot.PasswordError = $pwCheck.Error

    $snapshot.AutoStart = Get-AutoStartSnapshot

    $missing = @(Get-MissingRequiredCommands)
    $snapshot.MissingCommands = $missing

    if ($snapshot.FileExists -and $missing.Count -eq 0) {
        try {
            $image = Get-VhdxDiskImage
            $snapshot.Attached = [bool]$image.Attached
            if ($snapshot.Attached) {
                $disk = Get-VhdxDisk
                if ($null -ne $disk) {
                    $snapshot.DiskNumber = $disk.Number
                }
                $snapshot.BitLockerVolumes = @(Get-VhdxBitLockerVolumes)
                $snapshot.DriveLetters = @(
                    Get-VhdxMountPoints |
                        Where-Object { $_ -match '^[A-Za-z]:$' } |
                        Select-Object -Unique
                )
            }
        }
        catch {
            $snapshot.QueryError = $_.Exception.Message
        }
    }

    return [pscustomobject]$snapshot
}

function Write-StatusField {
    param(
        [string]$Label,
        [string]$Value,
        [ConsoleColor]$ValueColor = 'White'
    )

    Write-Host "  $Label : " -NoNewline -ForegroundColor Gray
    Write-Host $Value -ForegroundColor $ValueColor
}

function Show-StatusPanel {
    param([Parameter(Mandatory = $true)]$Snapshot)

    if ($Snapshot.ConfigError) {
        Write-StatusField -Label '配置状态' -Value "读取失败（$($Snapshot.ConfigError)）" -ValueColor 'Red'
        return
    }

    $fileStatusText = if ($Snapshot.FileExists) { '存在' } else { '文件不存在' }
    $fileStatusColor = if ($Snapshot.FileExists) { 'White' } else { 'Red' }
    Write-StatusField -Label '镜像文件' -Value "$($Snapshot.VhdxPath) [$fileStatusText]" -ValueColor $fileStatusColor

    if ($Snapshot.MissingCommands.Count -gt 0) {
        Write-StatusField -Label '运行环境' -Value "缺少系统命令：$($Snapshot.MissingCommands -join ', ')" -ValueColor 'Red'
    }
    elseif ($Snapshot.QueryError) {
        Write-StatusField -Label '挂载状态' -Value "状态检测失败（$($Snapshot.QueryError)）" -ValueColor 'Red'
    }
    elseif ($Snapshot.Attached) {
        $diskSuffix = if ($null -ne $Snapshot.DiskNumber) { "（磁盘 $($Snapshot.DiskNumber)）" } else { '' }
        Write-StatusField -Label '挂载状态' -Value "已挂载$diskSuffix" -ValueColor 'Green'

        if ($Snapshot.BitLockerVolumes.Count -gt 0) {
            $volParts = @()
            $hasLocked = $false
            foreach ($vol in $Snapshot.BitLockerVolumes) {
                $mp = Normalize-BitLockerMountPoint -MountPoint $vol.MountPoint
                if ($vol.LockStatus -eq 'Unlocked') {
                    $volParts += "$mp [已解锁]"
                }
                elseif ($vol.LockStatus -eq 'Locked') {
                    $volParts += "$mp [已锁定]"
                    $hasLocked = $true
                }
                else {
                    $volParts += "$mp [$($vol.LockStatus)]"
                }
            }
            $volColor = if ($hasLocked) { 'Yellow' } else { 'Green' }
            Write-StatusField -Label '卷与加密' -Value ($volParts -join '，') -ValueColor $volColor
        }
        elseif ($Snapshot.DriveLetters.Count -gt 0) {
            Write-StatusField -Label '卷与加密' -Value "$($Snapshot.DriveLetters -join ', ')（未检测到 BitLocker 卷）" -ValueColor 'Yellow'
        }
        else {
            Write-StatusField -Label '卷与加密' -Value '已挂载，但未检测到可见盘符或 BitLocker 卷' -ValueColor 'Yellow'
        }
    }
    else {
        Write-StatusField -Label '挂载状态' -Value '未挂载' -ValueColor 'DarkGray'
        Write-StatusField -Label '卷与加密' -Value '-' -ValueColor 'DarkGray'
    }

    switch ($Snapshot.PasswordState) {
        'SavedValid' {
            Write-StatusField -Label '本地密码' -Value '已保存（当前账户可正常解密）' -ValueColor 'Green'
        }
        'SavedInvalid' {
            Write-StatusField -Label '本地密码' -Value '已保存，但当前账户无法解密（请在密码维护中重设或清除）' -ValueColor 'Red'
        }
        default {
            Write-StatusField -Label '本地密码' -Value '未保存（挂载时将手动输入）' -ValueColor 'Yellow'
        }
    }

    if ($Snapshot.SafeUnmountOnly) {
        Write-StatusField -Label '卸载策略' -Value '安全卸载（文件占用时拒绝卸载）' -ValueColor 'Green'
    }
    else {
        Write-StatusField -Label '卸载策略' -Value '允许强制锁定（SafeUnmountOnly=false）' -ValueColor 'Yellow'
    }

    $auto = $Snapshot.AutoStart
    if ($null -eq $auto) {
        Write-StatusField -Label '开机自启' -Value '未知' -ValueColor 'DarkGray'
    }
    elseif ($auto.MissingCommands.Count -gt 0) {
        Write-StatusField -Label '开机自启' -Value '当前系统缺少计划任务模块' -ValueColor 'Red'
    }
    elseif ($auto.QueryError) {
        Write-StatusField -Label '开机自启' -Value "检测失败（$($auto.QueryError)）" -ValueColor 'Red'
    }
    elseif (-not $auto.Exists) {
        Write-StatusField -Label '开机自启' -Value '未启用' -ValueColor 'DarkGray'
    }
    elseif (-not $auto.Enabled) {
        Write-StatusField -Label '开机自启' -Value '已暂停 / 已禁用（任务仍保留）' -ValueColor 'Yellow'
    }
    elseif ($auto.NeedsRepair) {
        Write-StatusField -Label '开机自启' -Value '已启用，但配置异常（请进入自启动维护更新修复）' -ValueColor 'Yellow'
    }
    elseif ($Snapshot.PasswordState -ne 'SavedValid') {
        Write-StatusField -Label '开机自启' -Value "已启用（延迟 $($auto.DelaySeconds) 秒），但本地密码未就绪" -ValueColor 'Yellow'
    }
    else {
        Write-StatusField -Label '开机自启' -Value "已启用（登录后延迟 $($auto.DelaySeconds) 秒自动解密挂载）" -ValueColor 'Green'
    }
}

function Show-AutoStartStatusPanel {
    param(
        [Parameter(Mandatory = $true)]$AutoSnapshot,
        [string]$PasswordState = 'NotSaved',
        [string]$ConfigError = ''
    )

    if (-not [string]::IsNullOrWhiteSpace($ConfigError)) {
        Write-StatusField -Label '配置状态' -Value "读取失败（$ConfigError）" -ValueColor 'Red'
    }

    if ($AutoSnapshot.MissingCommands.Count -gt 0) {
        Write-StatusField -Label '自启状态' -Value "缺少系统命令：$($AutoSnapshot.MissingCommands -join ', ')" -ValueColor 'Red'
        return
    }

    if ($AutoSnapshot.QueryError) {
        Write-StatusField -Label '自启状态' -Value "状态检测失败（$($AutoSnapshot.QueryError)）" -ValueColor 'Red'
        return
    }

    if (-not $AutoSnapshot.Exists) {
        Write-StatusField -Label '自启状态' -Value '未启用（尚未创建 Windows 计划任务）' -ValueColor 'DarkGray'
    }
    elseif (-not $AutoSnapshot.Enabled) {
        Write-StatusField -Label '自启状态' -Value '已暂停 / 已禁用（计划任务已保留）' -ValueColor 'Yellow'
    }
    elseif ($AutoSnapshot.NeedsRepair) {
        Write-StatusField -Label '自启状态' -Value '已启用，但配置存在异常（请执行「[1] 启用 / 更新」修复）' -ValueColor 'Yellow'
    }
    elseif ($PasswordState -ne 'SavedValid') {
        Write-StatusField -Label '自启状态' -Value '已启用，但本地密码未就绪（下次登录无法自动解锁）' -ValueColor 'Yellow'
    }
    else {
        Write-StatusField -Label '自启状态' -Value '已启用（当前用户登录时免 UAC 自动解密挂载）' -ValueColor 'Green'
    }

    Write-StatusField -Label '计划任务' -Value $AutoSnapshot.TaskName -ValueColor 'White'

    if ($AutoSnapshot.Exists) {
        $userDesc = $AutoSnapshot.PrincipalUser
        if ($AutoSnapshot.RunLevel -eq 'Highest') {
            $userDesc += '（最高权限）'
        }
        else {
            $userDesc += "（权限：$($AutoSnapshot.RunLevel)）"
        }
        $userColor = if ($AutoSnapshot.UserMatchesCurrent -and $AutoSnapshot.RunLevel -eq 'Highest') { 'White' } else { 'Yellow' }
        Write-StatusField -Label '运行账户' -Value $userDesc -ValueColor $userColor
        Write-StatusField -Label '启动延迟' -Value "$($AutoSnapshot.DelaySeconds) 秒" -ValueColor 'White'

        if ($AutoSnapshot.HasRun) {
            $lastRunStr = "$($AutoSnapshot.LastRunTime.ToString('yyyy-MM-dd HH:mm:ss')) | $($AutoSnapshot.LastTaskResultText)"
            $lastRunColor = if ($AutoSnapshot.LastTaskResult -eq 0) { 'Green' } else { 'Yellow' }
            Write-StatusField -Label '上次运行' -Value $lastRunStr -ValueColor $lastRunColor
        }
        else {
            Write-StatusField -Label '上次运行' -Value '尚未运行' -ValueColor 'DarkGray'
        }
    }
    else {
        Write-StatusField -Label '默认账户' -Value "$($AutoSnapshot.CurrentUserName)（最高权限，登录后自动运行）" -ValueColor 'DarkGray'
        Write-StatusField -Label '默认延迟' -Value "$($AutoSnapshot.DelaySeconds) 秒" -ValueColor 'DarkGray'
    }

    if ([string]::IsNullOrWhiteSpace($ConfigError)) {
        switch ($PasswordState) {
            'SavedValid' {
                Write-StatusField -Label '密码前提' -Value '已保存且当前账户可正常解密' -ValueColor 'Green'
            }
            'SavedInvalid' {
                Write-StatusField -Label '密码前提' -Value '已保存，但当前账户无法解密（无法自动解锁）' -ValueColor 'Red'
            }
            default {
                Write-StatusField -Label '密码前提' -Value '未保存密码（启用自启前需先保存 DPAPI 密码）' -ValueColor 'Yellow'
            }
        }
    }

    if ($AutoSnapshot.Issues.Count -gt 0) {
        foreach ($issue in $AutoSnapshot.Issues) {
            Write-StatusField -Label '异常提示' -Value $issue -ValueColor 'Yellow'
        }
    }

    if (-not [string]::IsNullOrWhiteSpace($AutoSnapshot.LatestLogLine)) {
        Write-StatusField -Label '最近日志' -Value $AutoSnapshot.LatestLogLine -ValueColor 'DarkGray'
    }
}

function Show-AutoStartLogViewer {
    Write-Info "日志文件：$script:AutoStartLogPath"
    Write-Host ''

    $lines = @(Get-AutoStartLogLines -Tail 40)
    if ($lines.Count -eq 0) {
        Write-Info '暂无自启动运行日志。'
        Wait-ForMenuReturn -Prompt '按回车键返回开机自启动维护菜单'
        return
    }

    Write-Host '------------------------------------------------------' -ForegroundColor DarkGray
    foreach ($line in $lines) {
        $color = 'Gray'
        if ($line -match '\[错误\]') {
            $color = 'Red'
        }
        elseif ($line -match '\[成功\]') {
            $color = 'Green'
        }
        elseif ($line -match '\[警告\]') {
            $color = 'Yellow'
        }
        Write-Host "  $line" -ForegroundColor $color
    }
    Write-Host '------------------------------------------------------' -ForegroundColor DarkGray
    Write-Host ''

    $rawClear = Read-Host '输入 C 清空日志，或直接按回车返回'
    if ($null -ne $rawClear -and $rawClear.Trim().ToUpperInvariant() -eq 'C') {
        Write-Host ''
        Clear-AutoStartLog
        Wait-ForMenuReturn -Prompt '按回车键返回开机自启动维护菜单'
    }
}

function Show-AutoStartMenu {
    while ($true) {
        try {
            Clear-Host
        }
        catch {
        }

        $configError = $null
        try {
            Import-ToolConfig -Quiet
        }
        catch {
            $configError = $_.Exception.Message
        }

        $pwState = if ($null -eq $configError) { (Test-SavedPasswordState).State } else { 'NotSaved' }
        $autoSnapshot = Get-AutoStartSnapshot

        $toggleLabel = if ($autoSnapshot.Exists -and $autoSnapshot.Enabled) {
            '暂停开机自启动（临时禁用，保留任务配置）'
        }
        elseif ($autoSnapshot.Exists -and -not $autoSnapshot.Enabled) {
            '恢复启用开机自启动'
        }
        else {
            '暂停 / 恢复开机自启动（需先创建任务）'
        }

        Write-Host '======================================================' -ForegroundColor Cyan
        Write-Host '           VHDX BitLocker - 开机自启动维护' -ForegroundColor White
        Write-Host '======================================================' -ForegroundColor Cyan
        Show-AutoStartStatusPanel -AutoSnapshot $autoSnapshot -PasswordState $pwState -ConfigError $configError
        Write-Host '------------------------------------------------------' -ForegroundColor DarkGray
        Write-Host '请选择操作：' -ForegroundColor White
        Write-Host '  [1] 启用 / 更新开机自动解密挂载（配置延迟与修复任务）' -ForegroundColor Gray
        Write-Host "  [2] $toggleLabel" -ForegroundColor Gray
        Write-Host '  [3] 删除开机自启动任务' -ForegroundColor Gray
        Write-Host '  [4] 立即测试运行自启动任务' -ForegroundColor Gray
        Write-Host '  [5] 查看 / 清理自启动运行日志' -ForegroundColor Gray
        Write-Host '  [0] 返回主菜单' -ForegroundColor Gray
        Write-Host '======================================================' -ForegroundColor Cyan
        Write-Host ''

        $rawChoice = Read-Host '请输入选项编号'
        if ($null -eq $rawChoice) {
            return
        }
        $choice = $rawChoice.Trim().ToUpperInvariant()
        Write-Host ''

        switch ($choice) {
            '1' {
                try {
                    Enable-OrUpdateAutoStart -Interactive
                }
                catch {
                    Write-Fail $_.Exception.Message
                }
                Wait-ForMenuReturn -Prompt '按回车键返回开机自启动维护菜单'
            }
            '2' {
                try {
                    Toggle-AutoStartEnabledState
                }
                catch {
                    Write-Fail $_.Exception.Message
                }
                Wait-ForMenuReturn -Prompt '按回车键返回开机自启动维护菜单'
            }
            '3' {
                try {
                    Remove-AutoStartTask -RequireConfirm
                }
                catch {
                    Write-Fail $_.Exception.Message
                }
                Wait-ForMenuReturn -Prompt '按回车键返回开机自启动维护菜单'
            }
            '4' {
                try {
                    Invoke-TestAutoStartTask
                }
                catch {
                    Write-Fail $_.Exception.Message
                }
                Wait-ForMenuReturn -Prompt '按回车键返回开机自启动维护菜单'
            }
            '5' {
                try {
                    Show-AutoStartLogViewer
                }
                catch {
                    Write-Fail $_.Exception.Message
                    Wait-ForMenuReturn -Prompt '按回车键返回开机自启动维护菜单'
                }
            }
            '0' { return }
            'Q' { return }
            'B' { return }
            default {
                Write-Warn '无效选项，请输入 1、2、3、4、5 或 0。'
                Start-Sleep -Milliseconds 900
            }
        }
    }
}

function Show-AutoStartCliStatus {
    $configError = $null
    try {
        Import-ToolConfig -Quiet
    }
    catch {
        $configError = $_.Exception.Message
    }

    $pwState = if ($null -eq $configError) { (Test-SavedPasswordState).State } else { 'NotSaved' }
    $autoSnapshot = Get-AutoStartSnapshot

    Write-Host '======================================================' -ForegroundColor Cyan
    Write-Host '           VHDX BitLocker 开机自启动状态' -ForegroundColor White
    Write-Host '======================================================' -ForegroundColor Cyan
    Show-AutoStartStatusPanel -AutoSnapshot $autoSnapshot -PasswordState $pwState -ConfigError $configError
    Write-Host '======================================================' -ForegroundColor Cyan

    if ($configError) {
        throw $configError
    }
    if ($autoSnapshot.QueryError) {
        throw $autoSnapshot.QueryError
    }
}

function Show-PasswordMenu {
    while ($true) {
        try {
            Clear-Host
        }
        catch {
        }

        $configError = $null
        try {
            Import-ToolConfig -Quiet
        }
        catch {
            $configError = $_.Exception.Message
        }

        $pwCheck = if ($null -eq $configError) { Test-SavedPasswordState } else { $null }

        Write-Host '======================================================' -ForegroundColor Cyan
        Write-Host '              VHDX BitLocker - 密码维护' -ForegroundColor White
        Write-Host '======================================================' -ForegroundColor Cyan
        Write-StatusField -Label '配置文件' -Value $script:ConfigPath -ValueColor 'White'

        if ($null -ne $configError) {
            Write-StatusField -Label '配置状态' -Value "读取失败（$configError）" -ValueColor 'Red'
        }
        else {
            switch ($pwCheck.State) {
                'SavedValid' {
                    Write-StatusField -Label '密码状态' -Value '已保存（当前账户可正常解密）' -ValueColor 'Green'
                }
                'SavedInvalid' {
                    Write-StatusField -Label '密码状态' -Value '已保存，但当前账户无法解密' -ValueColor 'Red'
                }
                default {
                    Write-StatusField -Label '密码状态' -Value '未保存（挂载时将手动输入）' -ValueColor 'Yellow'
                }
            }
        }

        Write-Host '------------------------------------------------------' -ForegroundColor DarkGray
        Write-Host '请选择操作：' -ForegroundColor White
        Write-Host '  [1] 设置 / 更新已保存的密码' -ForegroundColor Gray
        Write-Host '  [2] 清除已保存的密码（改为每次手动输入）' -ForegroundColor Gray
        Write-Host '  [3] 校验当前已保存密码是否可读' -ForegroundColor Gray
        Write-Host '  [0] 返回主菜单' -ForegroundColor Gray
        Write-Host '======================================================' -ForegroundColor Cyan
        Write-Host ''

        $rawChoice = Read-Host '请输入选项编号'
        if ($null -eq $rawChoice) {
            return
        }
        $choice = $rawChoice.Trim().ToUpperInvariant()
        Write-Host ''

        switch ($choice) {
            '1' {
                try {
                    Set-NewStoredPassword
                }
                catch {
                    Write-Fail $_.Exception.Message
                }
                Wait-ForMenuReturn -Prompt '按回车键返回密码维护菜单'
            }
            '2' {
                try {
                    Clear-StoredPassword -RequireConfirm
                }
                catch {
                    Write-Fail $_.Exception.Message
                }
                Wait-ForMenuReturn -Prompt '按回车键返回密码维护菜单'
            }
            '3' {
                try {
                    Invoke-TestStoredPassword
                }
                catch {
                    Write-Fail $_.Exception.Message
                }
                Wait-ForMenuReturn -Prompt '按回车键返回密码维护菜单'
            }
            '0' { return }
            'Q' { return }
            'B' { return }
            default {
                Write-Warn '无效选项，请输入 1、2、3 或 0。'
                Start-Sleep -Milliseconds 900
            }
        }
    }
}

function Show-MainMenu {
    while ($true) {
        try {
            Clear-Host
        }
        catch {
        }

        $snapshot = Get-VhdxStatusSnapshot

        Write-Host '======================================================' -ForegroundColor Cyan
        Write-Host '              VHDX BitLocker 管理工具' -ForegroundColor White
        Write-Host '======================================================' -ForegroundColor Cyan
        Show-StatusPanel -Snapshot $snapshot
        Write-Host '------------------------------------------------------' -ForegroundColor DarkGray
        Write-Host '请选择操作：' -ForegroundColor White
        Write-Host '  [1] 挂载并解锁' -ForegroundColor Gray
        Write-Host '  [2] 锁定并卸载' -ForegroundColor Gray
        Write-Host '  [3] 密码维护' -ForegroundColor Gray
        Write-Host '  [4] 备份 VHDX 卷（含 rclone 同步套件）' -ForegroundColor Gray
        Write-Host '  [5] 开机自启动维护（自动解密挂载）' -ForegroundColor Gray
        Write-Host '  [R] 刷新状态' -ForegroundColor Gray
        Write-Host '  [0] 退出' -ForegroundColor Gray
        Write-Host '======================================================' -ForegroundColor Cyan
        Write-Host ''

        $rawChoice = Read-Host '请输入选项编号'
        if ($null -eq $rawChoice) {
            return
        }
        $choice = $rawChoice.Trim().ToUpperInvariant()
        Write-Host ''

        switch ($choice) {
            '1' {
                try {
                    Mount-AndUnlockVhdx
                }
                catch {
                    Write-Fail $_.Exception.Message
                }
                Wait-ForMenuReturn -Prompt '按回车键刷新并返回主菜单'
            }
            '2' {
                try {
                    Lock-AndDismountVhdx
                }
                catch {
                    Write-Fail $_.Exception.Message
                }
                Wait-ForMenuReturn -Prompt '按回车键刷新并返回主菜单'
            }
            '3' {
                Show-PasswordMenu
            }
            '4' {
                try {
                    Invoke-BackupVhdx
                }
                catch {
                    Write-Fail $_.Exception.Message
                }
                Wait-ForMenuReturn -Prompt '按回车键刷新并返回主菜单'
            }
            '5' {
                Show-AutoStartMenu
            }
            'R' {
                continue
            }
            '0' {
                return
            }
            'Q' {
                return
            }
            default {
                Write-Warn '无效选项，请输入 1、2、3、4、5、R 或 0。'
                Start-Sleep -Milliseconds 900
            }
        }
    }
}

function Show-CliStatus {
    $snapshot = Get-VhdxStatusSnapshot
    Write-Host '======================================================' -ForegroundColor Cyan
    Write-Host '              VHDX BitLocker 当前状态' -ForegroundColor White
    Write-Host '======================================================' -ForegroundColor Cyan
    Show-StatusPanel -Snapshot $snapshot
    Write-Host '======================================================' -ForegroundColor Cyan

    if ($snapshot.ConfigError) {
        throw $snapshot.ConfigError
    }
    if ($snapshot.QueryError) {
        throw $snapshot.QueryError
    }
}

# =========================
# Main
# =========================
$exitCode = 0
$script:RunMutex = $null
$script:RunMutexName = $null
$script:AutoMountFailureLogged = $false
$launchMutex = $null
$delegatedToElevated = $false

try {
    if (-not $script:IsUnattended) {
        Set-ConsoleTheme
    }

    # Best-effort early config load so ShowNotifications works even for pre-elevation warnings.
    try {
        Import-ToolConfig -Quiet
    }
    catch {
        if (-not $script:IsInteractiveMenu) {
            throw
        }
    }

    $mutexNames = Get-InstanceMutexNames
    $script:RunMutexName = $mutexNames.Run

    if (-not (Test-IsAdministrator)) {
        if (Test-NamedMutexHeld -Name $mutexNames.Run) {
            Write-Warn '已有菜单窗口或操作任务正在运行，请勿重复启动。'
            if ($script:IsUnattended) {
                Write-AutoStartLog -Level '警告' -Message '检测到已有菜单或任务正在运行，本次自启动调用已跳过。'
            }
            Show-WindowsNotification -Title 'VHDX BitLocker' -Message '已有菜单或任务正在运行，请勿重复启动。' -Level 'Warning' -ForceInMenu
            if ($script:IsInteractiveMenu -and -not $script:ShowNotifications) {
                Start-Sleep -Seconds 2
            }
        }
        else {
            $launchMutex = Enter-NamedMutex -Name $mutexNames.Launch
            if ($null -eq $launchMutex) {
                Write-Warn '已有实例正在启动，请勿重复点击。'
                Show-WindowsNotification -Title 'VHDX BitLocker' -Message '已有实例正在启动，请勿重复点击。' -Level 'Warning' -ForceInMenu
                if ($script:IsInteractiveMenu -and -not $script:ShowNotifications) {
                    Start-Sleep -Seconds 2
                }
            }
            else {
                $delegatedToElevated = Start-ElevatedSelf -RunMutexName $mutexNames.Run
            }
        }
    }
    else {
        $script:RunMutex = Enter-NamedMutex -Name $script:RunMutexName
        if ($null -eq $script:RunMutex) {
            Write-Warn '已有菜单窗口或操作任务正在运行，请勿重复启动。'
            if ($script:IsUnattended) {
                Write-AutoStartLog -Level '警告' -Message '检测到已有菜单或任务正在运行，本次自启动调用已跳过。'
            }
            Show-WindowsNotification -Title 'VHDX BitLocker' -Message '已有菜单或任务正在运行，请勿重复启动。' -Level 'Warning' -ForceInMenu
            if ($script:IsInteractiveMenu -and -not $script:ShowNotifications) {
                Start-Sleep -Seconds 2
            }
        }
        else {
            switch ($Action) {
                'Menu' { Show-MainMenu }
                'Toggle' { Invoke-Toggle }
                'Mount' { Mount-AndUnlockVhdx }
                'Unmount' { Lock-AndDismountVhdx }
                'Status' { Show-CliStatus }
                'SetPassword' { Set-NewStoredPassword }
                'ClearPassword' { Clear-StoredPassword }
                'TestPassword' { Invoke-TestStoredPassword }
                'Backup' { Invoke-BackupVhdx }
                'AutoMount' { Invoke-AutoMount }
                'EnableAutoStart' { Enable-OrUpdateAutoStart -DelaySecondsOverride $DelaySeconds }
                'DisableAutoStart' { Set-AutoStartEnabledState -Enable $false }
                'RemoveAutoStart' { Remove-AutoStartTask }
                'AutoStartStatus' { Show-AutoStartCliStatus }
            }
        }
    }
}
catch {
    $exitCode = 1
    Write-Fail $_.Exception.Message
    if ($script:IsUnattended -and -not $script:AutoMountFailureLogged) {
        Write-AutoStartLog -Level '错误' -Message $_.Exception.Message
    }
    if (-not $script:IsInteractiveMenu -and $Action -notin @('SetPassword', 'ClearPassword', 'TestPassword', 'Status', 'EnableAutoStart', 'DisableAutoStart', 'RemoveAutoStart', 'AutoStartStatus')) {
        Show-WindowsNotification -Title 'VHDX BitLocker 失败' -Message $_.Exception.Message -Level 'Error'
    }
}
finally {
    Exit-NamedMutex -Mutex $launchMutex
    Exit-NamedMutex -Mutex $script:RunMutex

    if (-not $script:IsUnattended -and ((-not $delegatedToElevated -and $PauseOnExit) -or $exitCode -ne 0)) {
        Write-Host ''
        Read-Host '按回车键关闭窗口' | Out-Null
    }
}

exit $exitCode
