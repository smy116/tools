# Windows VHDX + BitLocker Toggle Tool

这个小工具用于在 Windows 上一键切换一个固定 VHDX 虚拟磁盘：

- VHDX 未挂载时：挂载 VHDX，并解锁其中的 BitLocker 卷。
- VHDX 已挂载时：锁定其中的 BitLocker 卷，并卸载 VHDX。

## 文件说明

| 文件 | 说明 |
| --- | --- |
| `start.cmd` | 双击这个文件执行“开关”操作。 |
| `status.cmd` | 双击这个文件只查看当前 VHDX 和 BitLocker 状态，不会执行挂载、解锁、锁定或卸载。 |
| `config.ini` | 本机私有配置文件。VHDX 路径、镜像类型、密码密文、安全卸载开关、等待时间都在这里。 |
| `config.sample.ini` | 可分发的配置样例。复制给别人或打包项目时使用它，不包含本机保存的密码密文。 |
| `toggle-vhd-bitlocker.ps1` | 核心 PowerShell 脚本。一般不需要修改。 |
| `reset-password.cmd` | 当 BitLocker 密码改过、输错过，或想重新保存密码时，双击这个文件。 |

## 配置文件

打开 `config.ini`，按需要修改。

### `VhdxPath`

```ini
VhdxPath=.\secure-disk.dat
```

VHDX 文件路径。后缀名不一定要是 `.vhdx`，可以伪装成 `.dat`、`.bin` 等。但文件真实内容必须仍然是 VHDX。相对路径从工具目录开始算。

相对路径例子：

```ini
VhdxPath=.\secure-disk.vhdx
VhdxPath=.\secure-disk.dat
VhdxPath=.\vault\secure-disk.vhdx
```

绝对路径例子：

```ini
VhdxPath=D:\Private\secure-disk.vhdx
VhdxPath=C:\Users\YourName\Documents\secure-disk.dat
```

### `ImageStorageType`

```ini
ImageStorageType=VHDX
```

强制告诉 Windows 这个文件是什么磁盘镜像类型。如果你的文件只是把 `.vhdx` 改成了其他后缀，这里保持 `VHDX`。

### `PasswordSecret`

```ini
PasswordSecret=
```

BitLocker 密码的 DPAPI 加密密文。不要手动填写真实密码。首次运行或双击 `reset-password.cmd` 后，脚本会自动写入这一行。

### `SafeUnmountOnly`

```ini
SafeUnmountOnly=true
```

`true` 表示卸载时如果有文件占用，就安全失败并提示关闭文件后重试。不建议改成 `false`，强制锁定可能导致未保存数据丢失。

### `MountWaitSeconds`

```ini
MountWaitSeconds=25
```

挂载 VHDX 后等待 Windows 识别卷的秒数。普通情况不用改。

## 首次使用

1. 把你的 VHDX 文件放在这个目录，并命名为 `secure-disk.dat`。也可以修改 `config.ini` 里的 `VhdxPath`。
2. 双击 `start.cmd`。
3. Windows 可能会弹出 UAC 管理员权限确认，请允许。
4. 首次运行会要求输入两次 BitLocker 密码。脚本会把 DPAPI 加密后的密文保存到 `config.ini` 的 `PasswordSecret` 行，后续运行通常不需要再输入密码。

## 日常使用

- 需要打开虚拟磁盘时，双击 `start.cmd`。
- 用完后再双击 `start.cmd`。
- 只想查看当前是否已挂载、盘符和 BitLocker 锁定状态时，双击 `status.cmd`。
- 正常执行完成后窗口会自动关闭；如果发生错误，窗口会停留以便查看错误信息。
- 如果卸载时提示文件被占用，请关闭资源管理器窗口、编辑器、压缩软件、命令行窗口等正在访问虚拟磁盘的程序，然后再双击 `start.cmd`。

## 安全说明

- 默认不会强制卸载被占用的磁盘，避免未保存数据丢失。
- 密码不会明文写入 `config.ini`，`PasswordSecret` 只是 DPAPI 加密密文。
- `config.ini` 是本机私有配置，不建议上传或分发；需要给别人样例时使用 `config.sample.ini`。
- 把这个工具目录复制到另一台电脑或另一个 Windows 用户下，原来的密码密文通常无法解密。
- 如果你不想继续保存密码，把 `config.ini` 里的 `PasswordSecret=` 后面的内容清空即可。下次运行会重新要求输入。

## 常见问题

### 提示找不到 VHDX 文件

修改 `config.ini` 里的 `VhdxPath`，确保路径指向真实存在的 `.vhdx` 文件。

如果你使用伪装后缀，也可以指向 `.dat`、`.bin` 等文件。这种情况下请保持 `ImageStorageType=VHDX`。

### 提示镜像类型错误或挂载失败

检查 `ImageStorageType`。VHDX 文件即使改了后缀，也应该写 `VHDX`。如果文件真实内容不是 VHDX，Windows 会拒绝挂载。

### 解锁失败

可能是 BitLocker 密码保存错了，或磁盘密码后来改过。双击 `reset-password.cmd` 重新保存密码，然后再双击 `start.cmd`。

### 卸载失败

通常是虚拟磁盘里有文件被打开。关闭相关程序后重试。

### PowerShell 执行策略阻止脚本

请从 `start.cmd` 启动。它会用 `ExecutionPolicy Bypass` 仅对本次运行放行，不会修改系统执行策略。
