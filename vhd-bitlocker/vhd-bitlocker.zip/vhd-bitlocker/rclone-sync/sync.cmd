@echo off
setlocal

color 07
set "SCRIPT_DIR=%~dp0"
set "PS_EXE="

for /f "delims=" %%I in ('where pwsh.exe 2^>nul') do (
    if not defined PS_EXE set "PS_EXE=%%~I"
)
if not defined PS_EXE if exist "%ProgramFiles%\PowerShell\7\pwsh.exe" (
    set "PS_EXE=%ProgramFiles%\PowerShell\7\pwsh.exe"
)
if not defined PS_EXE (
    set "PS_EXE=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
)

"%PS_EXE%" -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%sync-vhdx.ps1" %*
set "EXIT_CODE=%ERRORLEVEL%"

endlocal & exit /b %EXIT_CODE%
