﻿param(
    [ValidateSet('Interactive', 'Sync', 'DryRun', 'Config')]
    [string]$Mode = 'Interactive',
    [switch]$DryRun,
    [switch]$Yes,
    [switch]$PauseOnExit
)

$ErrorActionPreference = 'Stop'

# =========================
# Configuration & Globals
# =========================
$BaseDirectory = $PSScriptRoot
$ParentDirectory = Split-Path -Path $BaseDirectory -Parent
$SyncConfigPath = Join-Path -Path $BaseDirectory -ChildPath 'sync-config.ini'
$ParentConfigPath = if (-not [string]::IsNullOrWhiteSpace($ParentDirectory)) { Join-Path -Path $ParentDirectory -ChildPath 'config.ini' } else { '' }
$RcloneExePath = Join-Path -Path $BaseDirectory -ChildPath 'rclone.exe'
$RcloneConfPath = Join-Path -Path $BaseDirectory -ChildPath 'rclone.conf'

$DefaultExcludePaths = @(
    'System Volume Information/**',
    '$RECYCLE.BIN/**'
)

$RawVhdxPathSetting = 'AUTO'
$RawImageStorageTypeSetting = 'AUTO'
$VhdxPath = $null
$VhdxSourceNote = ''
$ImageStorageType = 'VHDX'
$SyncDestination = ''
$ExcludePaths = @()
$ExtraRcloneArgs = '--progress'
$SafeUnmountOnly = $true
$MountWaitSeconds = 25
$CandidatePasswordSecret = ''
$CandidatePasswordSource = ''

# =========================
# Console Helpers
# =========================
function Set-ConsoleTheme {
    try {
        $Host.UI.RawUI.WindowTitle = 'VHDX BitLocker - rclone 同步工具'
        $Host.UI.RawUI.BackgroundColor = 'Black'
        $Host.UI.RawUI.ForegroundColor = 'Gray'
        Clear-Host
    }
    catch {
        # Best-effort console styling.
    }
}

function Write-Info {
    param([string]$Message)
    Write-Host "[信息] $Message" -ForegroundColor Cyan
}

function Write-Ok {
    param([string]$Message)
    Write-Host "[成功] $Message" -ForegroundColor Green
}

function Write-Warn {
    param([string]$Message)
    Write-Host "[警告] $Message" -ForegroundColor Yellow
}

function Write-Fail {
    param([string]$Message)
    Write-Host "[错误] $Message" -ForegroundColor Red
}

function Write-StatusField {
    param(
        [string]$Label,
        [string]$Value,
        [ConsoleColor]$ValueColor = 'White'
    )

    Write-Host "  $Label : " -NoNewline -ForegroundColor Gray
    Write-Host $Value -ForegroundColor $ValueColor
}

# =========================
# Elevation & Single-Instance Mutex
# =========================
function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Get-InstanceMutexNames {
    $keyText = [System.IO.Path]::GetFullPath($script:SyncConfigPath).ToLowerInvariant()
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($keyText)
        $hashBytes = $sha.ComputeHash($bytes)
        $hash = ([BitConverter]::ToString($hashBytes)).Replace('-', '').Substring(0, 16)
    }
    finally {
        $sha.Dispose()
    }

    return @{
        Run    = "Local\VhdBitLockerRcloneSync_Run_$hash"
        Launch = "Local\VhdBitLockerRcloneSync_Launch_$hash"
    }
}

function Test-NamedMutexHeld {
    param([Parameter(Mandatory = $true)][string]$Name)

    $existing = $null
    try {
        $existing = [System.Threading.Mutex]::OpenExisting($Name)
        $acquired = $false
        try {
            $acquired = $existing.WaitOne(0)
        }
        catch [System.Threading.AbandonedMutexException] {
            $acquired = $true
        }

        if ($acquired) {
            $existing.ReleaseMutex()
            return $false
        }

        return $true
    }
    catch [System.Threading.WaitHandleCannotBeOpenedException] {
        return $false
    }
    catch [System.UnauthorizedAccessException] {
        return $true
    }
    finally {
        if ($null -ne $existing) {
            $existing.Dispose()
        }
    }
}

function Enter-NamedMutex {
    param([Parameter(Mandatory = $true)][string]$Name)

    $mutex = $null
    $acquired = $false

    try {
        $mutex = New-Object System.Threading.Mutex($false, $Name)
        try {
            $acquired = $mutex.WaitOne(0)
        }
        catch [System.Threading.AbandonedMutexException] {
            $acquired = $true
        }

        if (-not $acquired) {
            $mutex.Dispose()
            return $null
        }

        return $mutex
    }
    catch [System.UnauthorizedAccessException] {
        if ($null -ne $mutex) {
            $mutex.Dispose()
        }
        return $null
    }
    catch {
        if ($null -ne $mutex) {
            $mutex.Dispose()
        }
        throw
    }
}

function Exit-NamedMutex {
    param([System.Threading.Mutex]$Mutex)

    if ($null -eq $Mutex) {
        return
    }

    try {
        $Mutex.ReleaseMutex()
    }
    catch {
    }
    finally {
        $Mutex.Dispose()
    }
}

function Quote-ProcessArgument {
    param([Parameter(Mandatory = $true)][string]$Argument)

    if ($Argument.Length -eq 0) {
        return '""'
    }

    return '"' + $Argument.Replace('"', '\"') + '"'
}

function Get-PreferredPowerShellExecutable {
    if ($PSVersionTable.PSEdition -eq 'Core') {
        try {
            $currentExe = [System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
            if (-not [string]::IsNullOrWhiteSpace($currentExe) -and (Test-Path -LiteralPath $currentExe -PathType Leaf)) {
                return $currentExe
            }
        }
        catch {
        }
    }

    $pwshCmd = Get-Command -Name 'pwsh.exe' -ErrorAction SilentlyContinue
    if ($null -ne $pwshCmd -and -not [string]::IsNullOrWhiteSpace($pwshCmd.Source)) {
        return $pwshCmd.Source
    }

    if (-not [string]::IsNullOrWhiteSpace($env:ProgramFiles)) {
        $defaultPwsh = Join-Path -Path $env:ProgramFiles -ChildPath 'PowerShell\7\pwsh.exe'
        if (Test-Path -LiteralPath $defaultPwsh -PathType Leaf) {
            return $defaultPwsh
        }
    }

    return (Join-Path -Path $env:SystemRoot -ChildPath 'System32\WindowsPowerShell\v1.0\powershell.exe')
}

function Start-ElevatedSelf {
    param([string]$RunMutexName)

    $powershell = Get-PreferredPowerShellExecutable
    $arguments = @(
        '-NoProfile',
        '-ExecutionPolicy',
        'Bypass',
        '-File',
        (Quote-ProcessArgument -Argument $PSCommandPath),
        '-Mode',
        $Mode
    )

    if ($DryRun) {
        $arguments += '-DryRun'
    }
    if ($Yes) {
        $arguments += '-Yes'
    }
    if ($PauseOnExit) {
        $arguments += '-PauseOnExit'
    }

    Write-Info '需要管理员权限挂载与解锁 VHDX，正在请求 UAC 授权...'
    try {
        $child = Start-Process -FilePath $powershell -ArgumentList $arguments -Verb RunAs -PassThru
        if ($RunMutexName) {
            $handoffDeadline = (Get-Date).AddMilliseconds(2500)
            while ((Get-Date) -lt $handoffDeadline) {
                if (Test-NamedMutexHeld -Name $RunMutexName) {
                    break
                }
                if ($null -ne $child) {
                    try {
                        if ($child.HasExited) {
                            break
                        }
                    }
                    catch {
                    }
                }
                Start-Sleep -Milliseconds 50
            }
        }
        return $true
    }
    catch [System.ComponentModel.Win32Exception] {
        if ($_.Exception.NativeErrorCode -eq 1223) {
            Write-Warn '已取消管理员权限授权。'
            return $false
        }
        throw
    }
}

# =========================
# Config File Management
# =========================
function Read-ConfigLines {
    param([Parameter(Mandatory = $true)][string]$Path)

    $bytes = [System.IO.File]::ReadAllBytes($Path)
    if ($bytes.Length -eq 0) {
        return @()
    }

    if ($bytes.Length -ge 2 -and $bytes[0] -eq 0xFF -and $bytes[1] -eq 0xFE) {
        $text = [System.Text.Encoding]::Unicode.GetString($bytes, 2, $bytes.Length - 2)
    }
    elseif ($bytes.Length -ge 2 -and $bytes[0] -eq 0xFE -and $bytes[1] -eq 0xFF) {
        $text = [System.Text.Encoding]::BigEndianUnicode.GetString($bytes, 2, $bytes.Length - 2)
    }
    elseif ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
        $text = [System.Text.Encoding]::UTF8.GetString($bytes, 3, $bytes.Length - 3)
    }
    else {
        $strictUtf8 = New-Object System.Text.UTF8Encoding($false, $true)
        try {
            $text = $strictUtf8.GetString($bytes)
        }
        catch [System.Text.DecoderFallbackException] {
            $text = [System.Text.Encoding]::Default.GetString($bytes)
        }
    }

    $normalized = $text.Replace("`r`n", "`n").Replace("`r", "`n")
    if ($normalized.EndsWith("`n")) {
        $normalized = $normalized.Substring(0, $normalized.Length - 1)
    }

    if ($normalized.Length -eq 0) {
        return @()
    }

    return @($normalized -split "`n")
}

function Write-ConfigLines {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [AllowEmptyCollection()]
        [AllowEmptyString()]
        [Parameter(Mandatory = $true)][string[]]$Lines
    )

    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    $tempPath = "$Path.$PID.tmp"
    try {
        [System.IO.File]::WriteAllLines($tempPath, $Lines, $utf8NoBom)
        Move-Item -LiteralPath $tempPath -Destination $Path -Force -ErrorAction Stop
    }
    finally {
        if (Test-Path -LiteralPath $tempPath -PathType Leaf) {
            Remove-Item -LiteralPath $tempPath -Force -ErrorAction SilentlyContinue
        }
    }
}

function Remove-SurroundingQuotes {
    param([string]$Value)

    if ($null -eq $Value) {
        return ''
    }

    $trimmed = $Value.Trim()
    if ($trimmed.Length -ge 2) {
        $first = $trimmed[0]
        $last = $trimmed[$trimmed.Length - 1]
        if (($first -eq '"' -and $last -eq '"') -or ($first -eq "'" -and $last -eq "'")) {
            return $trimmed.Substring(1, $trimmed.Length - 2).Trim()
        }
    }

    return $trimmed
}

function Resolve-PathAgainstBase {
    param(
        [Parameter(Mandatory = $true)][string]$PathValue,
        [Parameter(Mandatory = $true)][string]$BaseDir
    )

    $unquoted = Remove-SurroundingQuotes -Value $PathValue
    $expanded = [Environment]::ExpandEnvironmentVariables($unquoted)
    if ([string]::IsNullOrWhiteSpace($expanded)) {
        throw '路径配置为空。'
    }

    if ([System.IO.Path]::IsPathRooted($expanded)) {
        return [System.IO.Path]::GetFullPath($expanded)
    }

    return [System.IO.Path]::GetFullPath((Join-Path -Path $BaseDir -ChildPath $expanded))
}

function ConvertTo-ConfigBoolean {
    param(
        [Parameter(Mandatory = $true)][string]$Name,
        [Parameter(Mandatory = $true)][string]$Value
    )

    switch ($Value.Trim().ToLowerInvariant()) {
        'true' { return $true }
        'yes' { return $true }
        '1' { return $true }
        'false' { return $false }
        'no' { return $false }
        '0' { return $false }
        default { throw "sync-config.ini 中 $Name 的布尔值无效：$Value（请使用 true 或 false）。" }
    }
}

function ConvertTo-StorageType {
    param([Parameter(Mandatory = $true)][string]$Value)

    $normalized = $Value.Trim().ToUpperInvariant()
    $allowed = @('Unknown', 'ISO', 'VHD', 'VHDX', 'VHDSet')

    foreach ($candidate in $allowed) {
        if ($candidate.ToUpperInvariant() -eq $normalized) {
            return $candidate
        }
    }

    throw "ImageStorageType 无效：$Value（可选值：$($allowed -join ', ')）。"
}

function Normalize-ExcludePattern {
    param([string]$Pattern)

    $clean = Remove-SurroundingQuotes -Value $Pattern
    if ([string]::IsNullOrWhiteSpace($clean)) {
        return ''
    }

    $normalized = $clean.Replace('\', '/')
    if ($normalized.EndsWith('/')) {
        $normalized = $normalized + '**'
    }

    return $normalized
}

function New-DefaultSyncConfigFile {
    $defaultLines = @(
        '# VHDX + BitLocker rclone sync configuration',
        '# Lines starting with # or ; are comments.',
        '# Relative paths start in the folder containing sync-config.ini.',
        '',
        '# VHDX file path.',
        '# AUTO: automatically resolve from parent ..\config.ini (or detect a single image in current/parent folder).',
        '# In a backup copy, the backup tool automatically sets this to .\your-vhdx-file.',
        'VhdxPath=AUTO',
        '',
        '# Image storage type. AUTO inherits from parent ..\config.ini (fallback: VHDX).',
        'ImageStorageType=AUTO',
        '',
        '# Persistent rclone sync destination directory or remote path.',
        '# Local example:  SyncDestination=D:\Backup\VaultFiles',
        '# Remote example: SyncDestination=myremote:vault-backup',
        'SyncDestination=',
        '',
        '# Persistent exclude rules (rclone filter syntax; one ExcludePath=... per line).',
        '# Windows backslashes \ are converted to / automatically.',
        '# Directory exclusion should end with /** (e.g. temp/** or /Cache/**).',
        'ExcludePath=System Volume Information/**',
        'ExcludePath=$RECYCLE.BIN/**',
        '',
        '# Extra rclone arguments (space-separated).',
        'ExtraRcloneArgs=--progress',
        '',
        '# true: fail safely if files are open when auto-unmounting after sync.',
        '# false: allow forced BitLocker lock.',
        'SafeUnmountOnly=true',
        '',
        '# Seconds to wait for Windows to expose the VHDX volume after mount (1-300).',
        'MountWaitSeconds=25'
    )

    Write-ConfigLines -Path $script:SyncConfigPath -Lines $defaultLines
}

function Read-ParentToolConfig {
    if ([string]::IsNullOrWhiteSpace($script:ParentConfigPath) -or -not (Test-Path -LiteralPath $script:ParentConfigPath -PathType Leaf)) {
        return $null
    }

    $settings = @{}
    foreach ($line in (Read-ConfigLines -Path $script:ParentConfigPath)) {
        $trimmed = $line.Trim()
        if ($trimmed.Length -eq 0 -or $trimmed.StartsWith('#') -or $trimmed.StartsWith(';')) {
            continue
        }

        $sep = $trimmed.IndexOf('=')
        if ($sep -lt 1) {
            continue
        }

        $k = $trimmed.Substring(0, $sep).Trim()
        $v = $trimmed.Substring($sep + 1).Trim()
        if ($k.Length -gt 0) {
            $settings[$k] = $v
        }
    }

    $resolvedVhdx = $null
    if ($settings.ContainsKey('VhdxPath') -and -not [string]::IsNullOrWhiteSpace($settings['VhdxPath'])) {
        try {
            $resolvedVhdx = Resolve-PathAgainstBase -PathValue $settings['VhdxPath'] -BaseDir $script:ParentDirectory
        }
        catch {
            $resolvedVhdx = $null
        }
    }

    $storageType = 'VHDX'
    if ($settings.ContainsKey('ImageStorageType') -and -not [string]::IsNullOrWhiteSpace($settings['ImageStorageType'])) {
        try {
            $storageType = ConvertTo-StorageType -Value $settings['ImageStorageType']
        }
        catch {
            $storageType = 'VHDX'
        }
    }

    $passwordSecret = ''
    if ($settings.ContainsKey('PasswordSecret')) {
        $passwordSecret = $settings['PasswordSecret'].Trim()
    }

    return [pscustomobject]@{
        VhdxPath         = $resolvedVhdx
        ImageStorageType = $storageType
        PasswordSecret   = $passwordSecret
    }
}

function Save-SyncConfig {
    param(
        [AllowEmptyString()][string]$Destination = $script:SyncDestination,
        [AllowEmptyCollection()][string[]]$Excludes = $script:ExcludePaths
    )

    if (-not (Test-Path -LiteralPath $script:SyncConfigPath -PathType Leaf)) {
        New-DefaultSyncConfigFile
    }

    $lines = @(Read-ConfigLines -Path $script:SyncConfigPath)
    $result = New-Object System.Collections.Generic.List[string]

    $destWritten = $false
    $excludeWritten = $false
    $cleanExcludes = New-Object System.Collections.Generic.List[string]
    foreach ($item in @($Excludes)) {
        $norm = Normalize-ExcludePattern -Pattern $item
        if (-not [string]::IsNullOrWhiteSpace($norm) -and -not $cleanExcludes.Contains($norm)) {
            $cleanExcludes.Add($norm)
        }
    }

    foreach ($line in $lines) {
        if ($line -match '^\s*SyncDestination\s*=') {
            if (-not $destWritten) {
                $result.Add("SyncDestination=$Destination")
                $destWritten = $true
            }
            continue
        }

        if ($line -match '^\s*ExcludePaths?\s*=') {
            if (-not $excludeWritten) {
                foreach ($ex in $cleanExcludes) {
                    $result.Add("ExcludePath=$ex")
                }
                $excludeWritten = $true
            }
            continue
        }

        $result.Add($line)
    }

    if (-not $destWritten) {
        if ($result.Count -gt 0 -and $result[$result.Count - 1].Trim().Length -ne 0) {
            $result.Add('')
        }
        $result.Add("SyncDestination=$Destination")
    }

    if (-not $excludeWritten -and $cleanExcludes.Count -gt 0) {
        if ($result.Count -gt 0 -and $result[$result.Count - 1].Trim().Length -ne 0) {
            $result.Add('')
        }
        foreach ($ex in $cleanExcludes) {
            $result.Add("ExcludePath=$ex")
        }
    }

    Write-ConfigLines -Path $script:SyncConfigPath -Lines $result.ToArray()
    $script:SyncDestination = $Destination
    $script:ExcludePaths = @($cleanExcludes.ToArray())
}

function Import-SyncConfig {
    param([switch]$Quiet)

    if (-not (Test-Path -LiteralPath $script:SyncConfigPath -PathType Leaf)) {
        New-DefaultSyncConfigFile
        if (-not $Quiet) {
            Write-Warn "未找到同步配置文件，已自动生成默认配置：$script:SyncConfigPath"
        }
    }

    $settings = @{}
    $excludeList = New-Object System.Collections.Generic.List[string]
    $lineNumber = 0

    foreach ($line in (Read-ConfigLines -Path $script:SyncConfigPath)) {
        $lineNumber++
        $trimmed = $line.Trim()

        if ($trimmed.Length -eq 0 -or $trimmed.StartsWith('#') -or $trimmed.StartsWith(';')) {
            continue
        }

        $sep = $trimmed.IndexOf('=')
        if ($sep -lt 1) {
            throw "sync-config.ini 第 $lineNumber 行格式错误，请使用 Key=Value 格式。"
        }

        $key = $trimmed.Substring(0, $sep).Trim()
        $value = $trimmed.Substring($sep + 1).Trim()

        if ($key.Length -eq 0) {
            throw "sync-config.ini 第 $lineNumber 行键名为空。"
        }

        if ($key -ieq 'ExcludePath') {
            $norm = Normalize-ExcludePattern -Pattern $value
            if (-not [string]::IsNullOrWhiteSpace($norm) -and -not $excludeList.Contains($norm)) {
                $excludeList.Add($norm)
            }
        }
        elseif ($key -ieq 'ExcludePaths') {
            foreach ($part in ($value -split ';')) {
                $norm = Normalize-ExcludePattern -Pattern $part
                if (-not [string]::IsNullOrWhiteSpace($norm) -and -not $excludeList.Contains($norm)) {
                    $excludeList.Add($norm)
                }
            }
        }
        else {
            $settings[$key] = $value
        }
    }

    $parentCfg = Read-ParentToolConfig

    $rawVhdx = if ($settings.ContainsKey('VhdxPath')) { Remove-SurroundingQuotes -Value $settings['VhdxPath'] } else { 'AUTO' }
    if ([string]::IsNullOrWhiteSpace($rawVhdx)) {
        $rawVhdx = 'AUTO'
    }
    $script:RawVhdxPathSetting = $rawVhdx

    $script:VhdxPath = $null
    $script:VhdxSourceNote = ''

    if ($rawVhdx -ieq 'AUTO') {
        if ($null -ne $parentCfg -and -not [string]::IsNullOrWhiteSpace($parentCfg.VhdxPath)) {
            $script:VhdxPath = $parentCfg.VhdxPath
            $script:VhdxSourceNote = '自动继承自上级 config.ini'
        }
        else {
            $localCandidates = @(
                Get-ChildItem -LiteralPath $script:BaseDirectory -File -ErrorAction SilentlyContinue |
                    Where-Object { $_.Extension -in @('.vhdx', '.vhd', '.dat') }
            )
            if ($localCandidates.Count -eq 1) {
                $script:VhdxPath = $localCandidates[0].FullName
                $script:VhdxSourceNote = '自动检测到当前目录中的镜像文件'
            }
            elseif ($localCandidates.Count -gt 1) {
                throw '当前目录存在多个可能的镜像文件，请在 sync-config.ini 中明确指定 VhdxPath。'
            }
            else {
                $parentCandidates = if (-not [string]::IsNullOrWhiteSpace($script:ParentDirectory)) {
                    @(
                        Get-ChildItem -LiteralPath $script:ParentDirectory -File -ErrorAction SilentlyContinue |
                            Where-Object { $_.Extension -in @('.vhdx', '.vhd', '.dat') }
                    )
                }
                else {
                    @()
                }

                if ($parentCandidates.Count -eq 1) {
                    $script:VhdxPath = $parentCandidates[0].FullName
                    $script:VhdxSourceNote = '自动检测到上级目录中的镜像文件'
                }
                elseif ($parentCandidates.Count -gt 1) {
                    throw '上级目录存在多个可能的镜像文件，请在 sync-config.ini 中明确指定 VhdxPath。'
                }
                else {
                    throw '无法自动定位 VHDX 文件（未找到上级 config.ini，且当前/上级目录无单一镜像文件）。请在 sync-config.ini 中设置 VhdxPath。'
                }
            }
        }
    }
    else {
        $script:VhdxPath = Resolve-PathAgainstBase -PathValue $rawVhdx -BaseDir $script:BaseDirectory
        $script:VhdxSourceNote = "来自 sync-config.ini ($rawVhdx)"
    }

    $rawType = if ($settings.ContainsKey('ImageStorageType')) { $settings['ImageStorageType'].Trim() } else { 'AUTO' }
    if ([string]::IsNullOrWhiteSpace($rawType)) {
        $rawType = 'AUTO'
    }
    $script:RawImageStorageTypeSetting = $rawType

    if ($rawType -ieq 'AUTO') {
        if ($null -ne $parentCfg -and -not [string]::IsNullOrWhiteSpace($parentCfg.ImageStorageType)) {
            $script:ImageStorageType = $parentCfg.ImageStorageType
        }
        else {
            $script:ImageStorageType = 'VHDX'
        }
    }
    else {
        $script:ImageStorageType = ConvertTo-StorageType -Value $rawType
    }

    $script:SyncDestination = if ($settings.ContainsKey('SyncDestination')) {
        Remove-SurroundingQuotes -Value $settings['SyncDestination']
    }
    else {
        ''
    }

    $script:ExcludePaths = @($excludeList.ToArray())

    $script:ExtraRcloneArgs = if ($settings.ContainsKey('ExtraRcloneArgs')) {
        $settings['ExtraRcloneArgs'].Trim()
    }
    else {
        '--progress'
    }

    if ($settings.ContainsKey('SafeUnmountOnly')) {
        $script:SafeUnmountOnly = ConvertTo-ConfigBoolean -Name 'SafeUnmountOnly' -Value $settings['SafeUnmountOnly']
    }
    else {
        $script:SafeUnmountOnly = $true
    }

    if ($settings.ContainsKey('MountWaitSeconds')) {
        $waitSeconds = 0
        if (-not [int]::TryParse($settings['MountWaitSeconds'], [ref]$waitSeconds)) {
            throw "sync-config.ini 中 MountWaitSeconds 不是有效整数：$($settings['MountWaitSeconds'])。"
        }
        if ($waitSeconds -lt 1 -or $waitSeconds -gt 300) {
            throw 'sync-config.ini 中 MountWaitSeconds 必须在 1 到 300 之间。'
        }
        $script:MountWaitSeconds = $waitSeconds
    }
    else {
        $script:MountWaitSeconds = 25
    }

    # Optional DPAPI secret lookup (prefer local sync-config.ini if set, else parent config.ini on the same machine).
    $script:CandidatePasswordSecret = ''
    $script:CandidatePasswordSource = ''
    if ($settings.ContainsKey('PasswordSecret') -and -not [string]::IsNullOrWhiteSpace($settings['PasswordSecret'])) {
        $script:CandidatePasswordSecret = $settings['PasswordSecret'].Trim()
        $script:CandidatePasswordSource = 'sync-config.ini'
    }
    elseif ($null -ne $parentCfg -and -not [string]::IsNullOrWhiteSpace($parentCfg.PasswordSecret)) {
        $sameVhdx = ($null -ne $parentCfg.VhdxPath) -and ($parentCfg.VhdxPath.Equals($script:VhdxPath, [System.StringComparison]::OrdinalIgnoreCase))
        if ($sameVhdx -or ($rawVhdx -ieq 'AUTO')) {
            $script:CandidatePasswordSecret = $parentCfg.PasswordSecret
            $script:CandidatePasswordSource = '上级 config.ini'
        }
    }
}

# =========================
# Destination & Argument Helpers
# =========================
function Test-IsRcloneRemote {
    param([Parameter(Mandatory = $true)][string]$Path)

    $trimmed = $Path.Trim()
    if ($trimmed -match '^[A-Za-z]:([\\/]|$)') {
        return $false
    }
    if ($trimmed.StartsWith('\\')) {
        return $false
    }
    return ($trimmed -match '^[A-Za-z0-9_.-]{2,}:')
}

function Resolve-SyncDestination {
    param([Parameter(Mandatory = $true)][string]$Destination)

    $clean = Remove-SurroundingQuotes -Value $Destination
    if ([string]::IsNullOrWhiteSpace($clean)) {
        throw '同步目标路径为空。'
    }

    if (Test-IsRcloneRemote -Path $clean) {
        return [pscustomobject]@{
            IsRemote     = $true
            DisplayPath  = $clean
            ResolvedPath = $clean
        }
    }

    $expanded = [Environment]::ExpandEnvironmentVariables($clean)
    if ($expanded -match '^[A-Za-z]:[^\\/]') {
        throw "同步目标路径格式不完整：$clean（本地盘符路径请写完整，例如 D:\SyncTarget）。"
    }

    $fullPath = if ([System.IO.Path]::IsPathRooted($expanded)) {
        [System.IO.Path]::GetFullPath($expanded)
    }
    else {
        [System.IO.Path]::GetFullPath((Join-Path -Path $script:BaseDirectory -ChildPath $expanded))
    }

    return [pscustomobject]@{
        IsRemote     = $false
        DisplayPath  = $fullPath
        ResolvedPath = $fullPath
    }
}

function Split-CommandLineArgs {
    param([string]$ArgumentText)

    $tokens = New-Object System.Collections.Generic.List[string]
    if ([string]::IsNullOrWhiteSpace($ArgumentText)) {
        return @()
    }

    $current = New-Object System.Text.StringBuilder
    $inQuotes = $false
    $quoteChar = [char]0

    for ($i = 0; $i -lt $ArgumentText.Length; $i++) {
        $ch = $ArgumentText[$i]
        if ($inQuotes) {
            if ($ch -eq $quoteChar) {
                $inQuotes = $false
            }
            else {
                $null = $current.Append($ch)
            }
        }
        else {
            if ($ch -eq '"' -or $ch -eq "'") {
                $inQuotes = $true
                $quoteChar = $ch
            }
            elseif ([char]::IsWhiteSpace($ch)) {
                if ($current.Length -gt 0) {
                    $tokens.Add($current.ToString())
                    $null = $current.Clear()
                }
            }
            else {
                $null = $current.Append($ch)
            }
        }
    }

    if ($current.Length -gt 0) {
        $tokens.Add($current.ToString())
    }

    return @($tokens.ToArray())
}

# =========================
# Environment & Password Helpers
# =========================
function Assert-RequiredCommands {
    $requiredCommands = @(
        'Get-DiskImage',
        'Mount-DiskImage',
        'Dismount-DiskImage',
        'Get-Disk',
        'Get-Partition',
        'Get-Volume',
        'Get-BitLockerVolume',
        'Unlock-BitLocker',
        'Lock-BitLocker'
    )

    $missing = @()
    foreach ($cmd in $requiredCommands) {
        if (-not (Get-Command -Name $cmd -ErrorAction SilentlyContinue)) {
            $missing += $cmd
        }
    }

    if ($missing.Count -gt 0) {
        throw "缺少必需的 Windows 系统命令：$($missing -join ', ')。本工具依赖 Windows 内置的 Storage 和 BitLocker 模块。"
    }
}

function Assert-RcloneAvailable {
    if (-not (Test-Path -LiteralPath $script:RcloneExePath -PathType Leaf)) {
        throw "未找到 rclone 主程序：$script:RcloneExePath。请将 Windows 版 rclone.exe 放入脚本同目录（$script:BaseDirectory）后重试。"
    }
}

function Assert-VhdxExists {
    if ([string]::IsNullOrWhiteSpace($script:VhdxPath) -or -not (Test-Path -LiteralPath $script:VhdxPath -PathType Leaf)) {
        throw "找不到虚拟磁盘文件：$script:VhdxPath。请检查 sync-config.ini 中的 VhdxPath 配置。"
    }
}

function Try-GetSavedPassword {
    if ([string]::IsNullOrWhiteSpace($script:CandidatePasswordSecret)) {
        return $null
    }

    try {
        return ($script:CandidatePasswordSecret | ConvertTo-SecureString -ErrorAction Stop)
    }
    catch {
        return $null
    }
}

function Read-ManualBitLockerPassword {
    param([string]$Prompt = '请输入 BitLocker 解锁密码（直接按回车取消）')

    $entered = Read-Host $Prompt -AsSecureString
    if ($null -eq $entered -or $entered.Length -eq 0) {
        return $null
    }
    return $entered
}

# =========================
# VHDX & BitLocker Operations
# =========================
function Get-VhdxDiskImage {
    return Get-DiskImage -ImagePath $script:VhdxPath -StorageType $script:ImageStorageType -ErrorAction Stop
}

function Get-VhdxDisk {
    $image = Get-VhdxDiskImage
    if (-not $image.Attached) {
        return $null
    }

    try {
        return ($image | Get-Disk -ErrorAction Stop)
    }
    catch {
        return $null
    }
}

function Get-VhdxPartitions {
    $disk = Get-VhdxDisk
    if ($null -eq $disk) {
        return @()
    }

    return @(Get-Partition -DiskNumber $disk.Number -ErrorAction SilentlyContinue)
}

function Normalize-BitLockerMountPoint {
    param([Parameter(Mandatory = $true)][string]$MountPoint)

    $trimmed = $MountPoint.Trim()
    if ($trimmed -match '^[A-Za-z]:\\?$') {
        return $trimmed.Substring(0, 2).ToUpperInvariant()
    }

    return $trimmed
}

function Get-VhdxMountPoints {
    $points = @()

    foreach ($partition in Get-VhdxPartitions) {
        if ($partition.DriveLetter) {
            $points += "$($partition.DriveLetter):"
        }

        foreach ($accessPath in @($partition.AccessPaths)) {
            if (-not [string]::IsNullOrWhiteSpace($accessPath)) {
                $points += $accessPath
            }
        }

        try {
            $volumes = @($partition | Get-Volume -ErrorAction SilentlyContinue)
            foreach ($volume in $volumes) {
                if ($volume.DriveLetter) {
                    $points += "$($volume.DriveLetter):"
                }
                if (-not [string]::IsNullOrWhiteSpace($volume.Path)) {
                    $points += $volume.Path
                }
            }
        }
        catch {
        }
    }

    $points = @(
        $points |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) } |
            ForEach-Object { Normalize-BitLockerMountPoint -MountPoint $_ } |
            Select-Object -Unique
    )

    return $points
}

function Get-VhdxDriveLetters {
    return @(
        Get-VhdxMountPoints |
            Where-Object { $_ -match '^[A-Za-z]:$' } |
            Select-Object -Unique
    )
}

function Get-VhdxBitLockerVolumes {
    $volumes = @()
    $mountPoints = @(Get-VhdxMountPoints)

    foreach ($mountPoint in $mountPoints) {
        try {
            $volumes += @(Get-BitLockerVolume -MountPoint $mountPoint -ErrorAction Stop)
        }
        catch {
        }
    }

    if ($volumes.Count -eq 0 -and $mountPoints.Count -gt 0) {
        try {
            $knownPointSet = @{}
            foreach ($mountPoint in $mountPoints) {
                $knownPointSet[$mountPoint.ToUpperInvariant()] = $true
            }

            foreach ($volume in @(Get-BitLockerVolume -ErrorAction SilentlyContinue)) {
                if (-not [string]::IsNullOrWhiteSpace($volume.MountPoint)) {
                    $candidate = (Normalize-BitLockerMountPoint -MountPoint $volume.MountPoint).ToUpperInvariant()
                    if ($knownPointSet.ContainsKey($candidate)) {
                        $volumes += $volume
                    }
                }
            }
        }
        catch {
        }
    }

    $unique = @{}
    $result = @()
    foreach ($volume in $volumes) {
        if ([string]::IsNullOrWhiteSpace($volume.MountPoint)) {
            continue
        }
        $key = (Normalize-BitLockerMountPoint -MountPoint $volume.MountPoint).ToUpperInvariant()
        if (-not $unique.ContainsKey($key)) {
            $unique[$key] = $true
            $result += $volume
        }
    }

    return $result
}

function Wait-VhdxBitLockerVolumes {
    $deadline = (Get-Date).AddSeconds($script:MountWaitSeconds)
    do {
        $volumes = @(Get-VhdxBitLockerVolumes)
        if ($volumes.Count -gt 0) {
            return $volumes
        }
        Start-Sleep -Milliseconds 300
    } while ((Get-Date) -lt $deadline)

    return @()
}

function Wait-DriveRootReady {
    param([Parameter(Mandatory = $true)][string]$DriveRoot)

    $deadline = (Get-Date).AddSeconds($script:MountWaitSeconds)
    do {
        if (Test-Path -LiteralPath $DriveRoot -PathType Container) {
            try {
                $null = [System.IO.Directory]::GetFileSystemEntries($DriveRoot)
                return $true
            }
            catch {
            }
        }
        Start-Sleep -Milliseconds 300
    } while ((Get-Date) -lt $deadline)

    return $false
}

function Flush-VolumeCacheBestEffort {
    param([Parameter(Mandatory = $true)][string]$MountPoint)

    if ($MountPoint -match '^([A-Za-z]):$') {
        $driveLetter = $matches[1]
        if (Get-Command -Name 'Write-VolumeCache' -ErrorAction SilentlyContinue) {
            try {
                Write-VolumeCache -DriveLetter $driveLetter -ErrorAction Stop
            }
            catch {
            }
        }
    }
}

function Dismount-VhdxWithRetry {
    param(
        [int]$MaxAttempts = 4,
        [int]$DelaySeconds = 1
    )

    $lastError = $null
    for ($attempt = 1; $attempt -le $MaxAttempts; $attempt++) {
        try {
            $image = Get-VhdxDiskImage
            if (-not $image.Attached) {
                return
            }

            Dismount-DiskImage -ImagePath $script:VhdxPath -StorageType $script:ImageStorageType -ErrorAction Stop | Out-Null
            return
        }
        catch {
            $lastError = $_
            if ($attempt -lt $MaxAttempts) {
                Start-Sleep -Seconds $DelaySeconds
            }
        }
    }

    if ($null -ne $lastError) {
        throw $lastError.Exception
    }
}

function Lock-VhdxBitLockerVolumes {
    param([switch]$BestEffort)

    $volumes = @(Get-VhdxBitLockerVolumes)
    foreach ($volume in $volumes) {
        $mountPoint = Normalize-BitLockerMountPoint -MountPoint $volume.MountPoint
        if ($volume.LockStatus -eq 'Locked') {
            continue
        }

        Flush-VolumeCacheBestEffort -MountPoint $mountPoint
        Write-Info "正在锁定 BitLocker 卷 $mountPoint..."

        $lockParams = @{
            MountPoint  = $mountPoint
            ErrorAction = 'Stop'
            Confirm     = $false
        }
        if (-not $script:SafeUnmountOnly -or $BestEffort) {
            $lockParams['ForceDismount'] = $true
        }

        try {
            Lock-BitLocker @lockParams | Out-Null
            Write-Ok "已锁定 $mountPoint。"
        }
        catch {
            if ($BestEffort) {
                Write-Warn "自动卸载期间未能锁定 $mountPoint：$($_.Exception.Message)"
            }
            else {
                throw "无法锁定 $mountPoint。请关闭占用该盘的程序后重试。详情：$($_.Exception.Message)"
            }
        }
    }
}

function Unlock-LockedVolumesWithFallback {
    param([Parameter(Mandatory = $true)]$Volumes)

    $locked = @($Volumes | Where-Object { $_.LockStatus -eq 'Locked' })
    if ($locked.Count -eq 0) {
        return $true
    }

    $savedPassword = Try-GetSavedPassword
    $usedSaved = $false
    $password = $null

    if ($null -ne $savedPassword) {
        Write-Info "检测到本机可用的已保存密码（来自 $script:CandidatePasswordSource），将尝试自动解锁..."
        $password = $savedPassword
        $usedSaved = $true
    }
    else {
        Write-Info '未检测到本机可用的已保存密码，请手动输入 BitLocker 密码。'
        $password = Read-ManualBitLockerPassword
        if ($null -eq $password) {
            return $false
        }
    }

    foreach ($volume in $locked) {
        $mountPoint = Normalize-BitLockerMountPoint -MountPoint $volume.MountPoint
        Write-Info "正在解锁 BitLocker 卷 $mountPoint..."
        try {
            Unlock-BitLocker -MountPoint $mountPoint -Password $password -ErrorAction Stop | Out-Null
            Write-Ok "已解锁 $mountPoint。"
        }
        catch {
            if ($usedSaved) {
                Write-Warn "已保存密码解锁 $mountPoint 失败，改为手动输入密码重试。"
                $manualPassword = Read-ManualBitLockerPassword
                if ($null -eq $manualPassword) {
                    return $false
                }
                $password = $manualPassword
                $usedSaved = $false
                Unlock-BitLocker -MountPoint $mountPoint -Password $password -ErrorAction Stop | Out-Null
                Write-Ok "已解锁 $mountPoint。"
            }
            else {
                throw
            }
        }
    }

    return $true
}

# =========================
# Interactive Config Editor & Summary UI
# =========================
function Show-SyncSummary {
    $vhdxExists = (-not [string]::IsNullOrWhiteSpace($script:VhdxPath)) -and (Test-Path -LiteralPath $script:VhdxPath -PathType Leaf)
    $rcloneExists = Test-Path -LiteralPath $script:RcloneExePath -PathType Leaf
    $rcloneConfExists = Test-Path -LiteralPath $script:RcloneConfPath -PathType Leaf

    $attachedText = '未检测'
    $attachedColor = 'DarkGray'
    if ($vhdxExists) {
        try {
            $img = Get-VhdxDiskImage
            if ($img.Attached) {
                $letters = @(Get-VhdxDriveLetters)
                $suffix = if ($letters.Count -gt 0) { "（$($letters -join ', ')）" } else { '' }
                $attachedText = "已挂载$suffix（同步后将保持原状）"
                $attachedColor = 'Green'
            }
            else {
                $attachedText = '未挂载（同步时自动挂载解锁，结束后自动卸载）'
                $attachedColor = 'Cyan'
            }
        }
        catch {
            $attachedText = "状态检测失败（$($_.Exception.Message)）"
            $attachedColor = 'Yellow'
        }
    }

    Write-Host '======================================================' -ForegroundColor Cyan
    Write-Host '          VHDX BitLocker - rclone 同步工具' -ForegroundColor White
    Write-Host '======================================================' -ForegroundColor Cyan
    Write-StatusField -Label '配置文件' -Value $script:SyncConfigPath -ValueColor 'White'
    Write-StatusField -Label '镜像文件' -Value "$script:VhdxPath [$(if ($vhdxExists) { '存在' } else { '不存在' })]" -ValueColor $(if ($vhdxExists) { 'White' } else { 'Red' })
    if ($script:VhdxSourceNote) {
        Write-StatusField -Label '镜像来源' -Value $script:VhdxSourceNote -ValueColor 'DarkGray'
    }
    Write-StatusField -Label '挂载状态' -Value $attachedText -ValueColor $attachedColor
    Write-StatusField -Label 'rclone  ' -Value "$(if ($rcloneExists) { $script:RcloneExePath + ' [就绪]' } else { '缺失 rclone.exe' })" -ValueColor $(if ($rcloneExists) { 'Green' } else { 'Red' })
    if ($rcloneConfExists) {
        Write-StatusField -Label '远程配置' -Value "$script:RcloneConfPath [已检测到，将自动加载]" -ValueColor 'Green'
    }

    if ([string]::IsNullOrWhiteSpace($script:SyncDestination)) {
        Write-StatusField -Label '同步目标' -Value '未设置' -ValueColor 'Yellow'
    }
    else {
        Write-StatusField -Label '同步目标' -Value $script:SyncDestination -ValueColor 'Green'
    }

    if ($script:ExcludePaths.Count -eq 0) {
        Write-StatusField -Label '排除路径' -Value '（无）' -ValueColor 'DarkGray'
    }
    else {
        Write-Host '  排除路径 :' -ForegroundColor Gray
        for ($i = 0; $i -lt $script:ExcludePaths.Count; $i++) {
            Write-Host "    [$($i + 1)] $($script:ExcludePaths[$i])" -ForegroundColor DarkYellow
        }
    }

    if (-not [string]::IsNullOrWhiteSpace($script:ExtraRcloneArgs)) {
        Write-StatusField -Label '附加参数' -Value $script:ExtraRcloneArgs -ValueColor 'DarkGray'
    }
    Write-Host '======================================================' -ForegroundColor Cyan
}

function Edit-SyncConfigInteractive {
    param([switch]$RequireDestinationOnly)

    $dest = $script:SyncDestination
    $excludes = New-Object System.Collections.Generic.List[string]
    foreach ($ex in $script:ExcludePaths) {
        $excludes.Add($ex)
    }

    Write-Host ''
    Write-Info '配置同步目标路径（支持本地目录如 D:\SyncVault，或 rclone 远程如 remote:vault）。'
    while ($true) {
        $prompt = if ([string]::IsNullOrWhiteSpace($dest)) {
            '请输入同步目标路径（直接回车取消）'
        }
        else {
            "请输入新的同步目标路径 [当前: $dest，直接回车保持不变]"
        }

        $rawDest = Read-Host $prompt
        if ($null -eq $rawDest) {
            return $false
        }
        $trimmedDest = Remove-SurroundingQuotes -Value $rawDest

        if ([string]::IsNullOrWhiteSpace($trimmedDest)) {
            if ([string]::IsNullOrWhiteSpace($dest)) {
                Write-Warn '未设置同步目标路径，已取消。'
                return $false
            }
            break
        }

        try {
            $null = Resolve-SyncDestination -Destination $trimmedDest
            $dest = $trimmedDest
            break
        }
        catch {
            Write-Warn $_.Exception.Message
        }
    }

    if (-not $RequireDestinationOnly) {
        while ($true) {
            Write-Host ''
            Write-Host '当前排除路径规则（rclone 过滤语法，目录请以 /** 结尾，如 temp/** 或 /Cache/**）：' -ForegroundColor White
            if ($excludes.Count -eq 0) {
                Write-Host '  （无）' -ForegroundColor DarkGray
            }
            else {
                for ($i = 0; $i -lt $excludes.Count; $i++) {
                    Write-Host "  [$($i + 1)] $($excludes[$i])" -ForegroundColor Yellow
                }
            }

            $action = Read-Host '排除路径操作：[A]新增 / [R]删除编号 / [D]恢复默认 / [直接回车]保存并返回'
            if ($null -eq $action -or [string]::IsNullOrWhiteSpace($action)) {
                break
            }

            switch ($action.Trim().ToUpperInvariant()) {
                'A' {
                    $newRule = Read-Host '请输入要排除的相对路径或通配符（例如 temp/** 或 *.log，回车取消）'
                    $norm = Normalize-ExcludePattern -Pattern $newRule
                    if (-not [string]::IsNullOrWhiteSpace($norm)) {
                        if ($excludes.Contains($norm)) {
                            Write-Warn "规则已存在：$norm"
                        }
                        else {
                            $excludes.Add($norm)
                            Write-Ok "已添加排除规则：$norm"
                        }
                    }
                }
                'R' {
                    if ($excludes.Count -eq 0) {
                        Write-Warn '当前没有可删除的排除规则。'
                    }
                    else {
                        $idxText = Read-Host "请输入要删除的编号（1-$($excludes.Count)）"
                        $idx = 0
                        if ([int]::TryParse($idxText, [ref]$idx) -and $idx -ge 1 -and $idx -le $excludes.Count) {
                            $removed = $excludes[$idx - 1]
                            $excludes.RemoveAt($idx - 1)
                            Write-Ok "已删除排除规则：$removed"
                        }
                        else {
                            Write-Warn '编号无效。'
                        }
                    }
                }
                'D' {
                    $excludes.Clear()
                    foreach ($d in $script:DefaultExcludePaths) {
                        $excludes.Add($d)
                    }
                    Write-Ok '已恢复默认排除规则。'
                }
                default {
                    Write-Warn '无效选项，请输入 A、R、D 或直接回车。'
                }
            }
        }
    }

    Save-SyncConfig -Destination $dest -Excludes @($excludes.ToArray())
    Write-Ok "已保存配置到：$script:SyncConfigPath"
    return $true
}

# =========================
# Core Sync Execution
# =========================
function Select-SourceDriveRoot {
    param([string[]]$DriveLetters)

    if ($DriveLetters.Count -eq 0) {
        throw '虚拟磁盘已解锁，但未检测到可用盘符（如 Z:）。请确认该 BitLocker 卷已分配盘符。'
    }

    if ($DriveLetters.Count -eq 1) {
        return ($DriveLetters[0] + '\')
    }

    if ($Mode -ne 'Interactive') {
        throw "检测到多个可见盘符（$($DriveLetters -join ', ')），非交互模式下无法自动选择。"
    }

    Write-Info '检测到虚拟磁盘包含多个分区盘符，请选择要同步的源盘符：'
    for ($i = 0; $i -lt $DriveLetters.Count; $i++) {
        Write-Host "  [$($i + 1)] $($DriveLetters[$i])\" -ForegroundColor White
    }

    while ($true) {
        $rawPick = Read-Host "请输入编号（1-$($DriveLetters.Count)，默认 1）"
        if ([string]::IsNullOrWhiteSpace($rawPick)) {
            return ($DriveLetters[0] + '\')
        }
        $pick = 0
        if ([int]::TryParse($rawPick.Trim(), [ref]$pick) -and $pick -ge 1 -and $pick -le $DriveLetters.Count) {
            return ($DriveLetters[$pick - 1] + '\')
        }
        Write-Warn '编号无效，请重新输入。'
    }
}

function Invoke-VhdxRcloneSync {
    param([switch]$Simulate)

    Assert-RequiredCommands
    Assert-RcloneAvailable
    Assert-VhdxExists

    if ([string]::IsNullOrWhiteSpace($script:SyncDestination)) {
        throw 'sync-config.ini 中尚未配置 SyncDestination（同步目标路径）。'
    }

    $destInfo = Resolve-SyncDestination -Destination $script:SyncDestination

    $mountedByUs = $false
    $excludeTempFile = $null
    $sourceRoot = $null

    try {
        $image = Get-VhdxDiskImage
        if (-not $image.Attached) {
            Write-Info "正在挂载虚拟磁盘：$script:VhdxPath"
            Mount-DiskImage -ImagePath $script:VhdxPath -StorageType $script:ImageStorageType -ErrorAction Stop | Out-Null
            $mountedByUs = $true
            Write-Ok '虚拟磁盘已挂载。'
        }
        else {
            Write-Info '检测到虚拟磁盘已处于挂载状态，将直接使用（同步结束后保持原状不卸载）。'
        }

        $volumes = @(Wait-VhdxBitLockerVolumes)
        if ($volumes.Count -gt 0) {
            $unlockedOk = Unlock-LockedVolumesWithFallback -Volumes $volumes
            if (-not $unlockedOk) {
                Write-Warn '已取消解锁操作，同步已中止。'
                return
            }

            $postVolumes = @(Get-VhdxBitLockerVolumes)
            $stillLocked = @($postVolumes | Where-Object { $_.LockStatus -eq 'Locked' })
            if ($stillLocked.Count -gt 0) {
                throw '解锁后仍有 BitLocker 卷处于锁定状态。'
            }
        }
        else {
            Write-Warn '未检测到 BitLocker 卷，将直接检查虚拟磁盘上的普通分区盘符。'
        }

        # Wait briefly for drive letters to appear after unlock.
        $driveLetters = @()
        $deadline = (Get-Date).AddSeconds($script:MountWaitSeconds)
        do {
            $driveLetters = @(Get-VhdxDriveLetters)
            if ($driveLetters.Count -gt 0) {
                break
            }
            Start-Sleep -Milliseconds 300
        } while ((Get-Date) -lt $deadline)

        $sourceRoot = Select-SourceDriveRoot -DriveLetters $driveLetters
        if (-not (Wait-DriveRootReady -DriveRoot $sourceRoot)) {
            throw "源卷 $sourceRoot 在等待时间内未能就绪，无法读取目录内容。"
        }

        # Guard against syncing the VHDX volume into itself.
        if (-not $destInfo.IsRemote) {
            $normSource = $sourceRoot.TrimEnd('\').ToUpperInvariant() + '\'
            $normDest = $destInfo.ResolvedPath.TrimEnd('\').ToUpperInvariant() + '\'
            if ($normDest.StartsWith($normSource, [System.StringComparison]::OrdinalIgnoreCase)) {
                throw "同步目标路径（$($destInfo.ResolvedPath)）位于源虚拟磁盘（$sourceRoot）内部，已阻止以防止递归覆盖。"
            }

            if (-not $Simulate -and -not (Test-Path -LiteralPath $destInfo.ResolvedPath -PathType Container)) {
                Write-Info "同步目标目录不存在，正在创建：$($destInfo.ResolvedPath)"
                New-Item -ItemType Directory -Path $destInfo.ResolvedPath -Force -ErrorAction Stop | Out-Null
            }
        }

        # Build rclone arguments.
        $rcloneArgs = New-Object System.Collections.Generic.List[string]
        $rcloneArgs.Add('sync')
        $rcloneArgs.Add($sourceRoot)
        $rcloneArgs.Add($destInfo.ResolvedPath)

        if (Test-Path -LiteralPath $script:RcloneConfPath -PathType Leaf) {
            $rcloneArgs.Add('--config')
            $rcloneArgs.Add($script:RcloneConfPath)
        }

        if ($script:ExcludePaths.Count -gt 0) {
            $excludeTempFile = Join-Path -Path ([System.IO.Path]::GetTempPath()) -ChildPath ("vhdx-rclone-exclude-$PID-" + [guid]::NewGuid().ToString('N') + '.txt')
            $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
            [System.IO.File]::WriteAllLines($excludeTempFile, $script:ExcludePaths, $utf8NoBom)
            $rcloneArgs.Add('--exclude-from')
            $rcloneArgs.Add($excludeTempFile)
        }

        foreach ($extraArg in (Split-CommandLineArgs -ArgumentText $script:ExtraRcloneArgs)) {
            $rcloneArgs.Add($extraArg)
        }

        if ($Simulate) {
            $rcloneArgs.Add('--dry-run')
            Write-Info "开始模拟预演（--dry-run）：$sourceRoot -> $($destInfo.DisplayPath)"
        }
        else {
            Write-Info "开始执行 rclone sync：$sourceRoot -> $($destInfo.DisplayPath)"
        }

        Write-Host ''
        $rcloneArgArray = $rcloneArgs.ToArray()
        & $script:RcloneExePath @rcloneArgArray
        $rcloneExit = $LASTEXITCODE
        Write-Host ''

        if ($rcloneExit -ne 0) {
            throw "rclone sync 执行失败（退出码：$rcloneExit）。请检查上方输出日志与排除规则。"
        }

        if ($Simulate) {
            Write-Ok "模拟预演完成（未改动目标文件）：$sourceRoot -> $($destInfo.DisplayPath)"
        }
        else {
            Write-Ok "同步完成：$sourceRoot -> $($destInfo.DisplayPath)"
        }
    }
    finally {
        if ($null -ne $excludeTempFile -and (Test-Path -LiteralPath $excludeTempFile -PathType Leaf)) {
            Remove-Item -LiteralPath $excludeTempFile -Force -ErrorAction SilentlyContinue
        }

        if ($mountedByUs) {
            Write-Host ''
            Write-Info '同步流程结束，正在自动锁定并卸载本次挂载的虚拟磁盘...'
            try {
                Lock-VhdxBitLockerVolumes
                Dismount-VhdxWithRetry -MaxAttempts 4 -DelaySeconds 1
                Write-Ok '虚拟磁盘已锁定并安全卸载。'
            }
            catch {
                Write-Warn "自动卸载虚拟磁盘失败，请手动检查并卸载。详情：$($_.Exception.Message)"
            }
        }
    }
}

# =========================
# Interactive Flow
# =========================
function Start-InteractiveFlow {
    while ($true) {
        try {
            Clear-Host
        }
        catch {
        }

        Import-SyncConfig -Quiet
        Show-SyncSummary

        if ([string]::IsNullOrWhiteSpace($script:SyncDestination)) {
            Write-Host ''
            Write-Warn '检测到首次运行尚未设置同步目标路径（SyncDestination），请先进行配置：'
            $saved = Edit-SyncConfigInteractive
            if (-not $saved) {
                return
            }
            continue
        }

        Write-Host ''
        Write-Warn '注意：rclone sync 为镜像同步，目标目录中源卷不存在的多余文件将被删除！'
        Write-Host '请选择操作：' -ForegroundColor White
        Write-Host '  [Y] 开始同步（挂载 -> 解锁 -> rclone sync -> 自动卸载）' -ForegroundColor Green
        Write-Host '  [D] 模拟预演（--dry-run，不修改目标文件）' -ForegroundColor Cyan
        Write-Host '  [E] 修改同步目标与排除路径' -ForegroundColor Gray
        Write-Host '  [N] 取消并退出' -ForegroundColor Gray
        Write-Host ''

        $rawChoice = Read-Host '请输入选项 [Y/D/E/N，默认 N]'
        if ($null -eq $rawChoice -or [string]::IsNullOrWhiteSpace($rawChoice)) {
            Write-Info '已取消同步。'
            return
        }

        switch ($rawChoice.Trim().ToUpperInvariant()) {
            'Y' {
                Write-Host ''
                Invoke-VhdxRcloneSync
                return
            }
            'D' {
                Write-Host ''
                Invoke-VhdxRcloneSync -Simulate
                Write-Host ''
                Read-Host '模拟预演结束，按回车键返回确认界面' | Out-Null
            }
            'E' {
                $null = Edit-SyncConfigInteractive
                Start-Sleep -Milliseconds 600
            }
            'N' {
                Write-Info '已取消同步。'
                return
            }
            'Q' {
                Write-Info '已取消同步。'
                return
            }
            '0' {
                Write-Info '已取消同步。'
                return
            }
            default {
                Write-Warn '无效选项，请输入 Y、D、E 或 N。'
                Start-Sleep -Milliseconds 900
            }
        }
    }
}

# =========================
# Main
# =========================
$exitCode = 0
$runMutex = $null
$launchMutex = $null
$delegatedToElevated = $false

try {
    Set-ConsoleTheme
    $mutexNames = Get-InstanceMutexNames

    if (-not (Test-IsAdministrator)) {
        if (Test-NamedMutexHeld -Name $mutexNames.Run) {
            Write-Warn '已有同步任务正在运行，请勿重复启动。'
            Start-Sleep -Seconds 2
        }
        else {
            $launchMutex = Enter-NamedMutex -Name $mutexNames.Launch
            if ($null -eq $launchMutex) {
                Write-Warn '已有同步实例正在启动，请勿重复点击。'
                Start-Sleep -Seconds 2
            }
            else {
                $delegatedToElevated = Start-ElevatedSelf -RunMutexName $mutexNames.Run
            }
        }
    }
    else {
        $runMutex = Enter-NamedMutex -Name $mutexNames.Run
        if ($null -eq $runMutex) {
            Write-Warn '已有同步任务正在运行，请勿重复启动。'
            Start-Sleep -Seconds 2
        }
        else {
            switch ($Mode) {
                'Interactive' {
                    if ($DryRun) {
                        Import-SyncConfig -Quiet
                        Show-SyncSummary
                        Write-Host ''
                        Invoke-VhdxRcloneSync -Simulate
                    }
                    else {
                        Start-InteractiveFlow
                    }
                }
                'Sync' {
                    Import-SyncConfig -Quiet
                    Show-SyncSummary
                    Write-Host ''
                    if (-not $Yes -and -not $DryRun) {
                        Write-Warn '注意：rclone sync 为镜像同步，目标目录中源卷不存在的多余文件将被删除！'
                        $confirm = Read-Host '确认立即执行 rclone sync 吗？[y/N]'
                        if ($null -eq $confirm -or ($confirm.Trim().ToLowerInvariant() -notin @('y', 'yes'))) {
                            Write-Info '已取消同步。'
                            break
                        }
                    }
                    Invoke-VhdxRcloneSync -Simulate:$DryRun
                }
                'DryRun' {
                    Import-SyncConfig -Quiet
                    Show-SyncSummary
                    Write-Host ''
                    Invoke-VhdxRcloneSync -Simulate
                }
                'Config' {
                    Import-SyncConfig -Quiet
                    Show-SyncSummary
                    $null = Edit-SyncConfigInteractive
                }
            }
        }
    }
}
catch {
    $exitCode = 1
    Write-Fail $_.Exception.Message
}
finally {
    Exit-NamedMutex -Mutex $launchMutex
    Exit-NamedMutex -Mutex $runMutex

    if (-not $delegatedToElevated -and ($Mode -eq 'Interactive' -or $PauseOnExit -or $exitCode -ne 0)) {
        Write-Host ''
        Read-Host '按回车键关闭窗口' | Out-Null
    }
}

exit $exitCode
