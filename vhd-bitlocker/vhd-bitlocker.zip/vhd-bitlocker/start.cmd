@echo off
setlocal

color 07
set "SCRIPT_DIR=%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%toggle-vhd-bitlocker.ps1"

endlocal
