param(
    [switch]$ResetPassword,
    [switch]$Status,
    [switch]$PauseOnExit
)

$ErrorActionPreference = 'Stop'

# =========================
# Configuration
# =========================
$BaseDirectory = $PSScriptRoot
$ConfigPath = Join-Path -Path $BaseDirectory -ChildPath 'config.ini'
$VhdxPath = $null
$ImageStorageType = 'VHDX'
$PasswordSecret = $null
$SafeUnmountOnly = $true
$MountWaitSeconds = 25

# =========================
# Helpers
# =========================
function Set-ConsoleTheme {
    try {
        $host.UI.RawUI.BackgroundColor = 'Black'
        $host.UI.RawUI.ForegroundColor = 'Gray'
        Clear-Host
    }
    catch {
        # Console color control is best-effort, especially in redirected hosts.
    }
}

function Write-Info {
    param([string]$Message)
    Write-Host "[INFO] $Message" -ForegroundColor Cyan
}

function Write-Ok {
    param([string]$Message)
    Write-Host "[OK] $Message" -ForegroundColor Green
}

function Write-Warn {
    param([string]$Message)
    Write-Host "[WARN] $Message" -ForegroundColor Yellow
}

function Write-Fail {
    param([string]$Message)
    Write-Host "[ERROR] $Message" -ForegroundColor Red
}

function Write-StatusItem {
    param(
        [Parameter(Mandatory = $true)][string]$Name,
        [AllowEmptyString()][string]$Value
    )

    if ([string]::IsNullOrWhiteSpace($Value)) {
        $Value = '(none)'
    }

    Write-Host ("{0}: {1}" -f $Name, $Value)
}

function Format-StatusList {
    param([object[]]$Values)

    $items = @(
        $Values |
            Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) } |
            ForEach-Object { [string]$_ }
    )

    if ($items.Count -eq 0) {
        return '(none)'
    }

    return ($items -join ', ')
}

function ConvertTo-StatusYesNo {
    param([bool]$Value)

    if ($Value) {
        return 'Yes'
    }

    return 'No'
}

function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Quote-ProcessArgument {
    param([Parameter(Mandatory = $true)][string]$Argument)

    if ($Argument.Length -eq 0) {
        return '""'
    }

    return '"' + $Argument.Replace('"', '\"') + '"'
}

function Start-ElevatedSelf {
    $powershell = Join-Path -Path $env:SystemRoot -ChildPath 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $arguments = @(
        '-NoProfile',
        '-ExecutionPolicy',
        'Bypass',
        '-File',
        (Quote-ProcessArgument -Argument $PSCommandPath)
    )

    if ($ResetPassword) {
        $arguments += '-ResetPassword'
    }

    if ($Status) {
        $arguments += '-Status'
    }

    if ($PauseOnExit) {
        $arguments += '-PauseOnExit'
    }

    Write-Info 'Administrator permission is required. Opening a UAC prompt...'
    Start-Process -FilePath $powershell -ArgumentList $arguments -Verb RunAs | Out-Null
}

function New-DefaultConfigFile {
    $defaultConfig = @'
# Windows VHDX + BitLocker Toggle Tool configuration
# Lines starting with # are comments.
# Relative paths start in this tool folder.

# Your VHDX file path. The file extension can be disguised.
# Relative path examples:
#   VhdxPath=.\secure-disk.vhdx
#   VhdxPath=.\secure-disk.dat
# Absolute path examples:
#   VhdxPath=D:\Private\secure-disk.vhdx
#   VhdxPath=C:\Users\YourName\Documents\secure-disk.dat
VhdxPath=.\secure-disk.dat

# Force Windows to treat the file as this image type.
# Keep VHDX when the real file content is VHDX, even if the suffix is disguised.
ImageStorageType=VHDX

# DPAPI-encrypted BitLocker password.
# Do not edit this by hand. It is not the plain text password.
# Run reset-password.cmd to save or change the password.
PasswordSecret=

# true: fail safely if files are open on the virtual disk.
# false: allow forced BitLocker lock. This can lose unsaved data.
SafeUnmountOnly=true

# Seconds to wait for Windows to expose the VHDX volume after mount.
MountWaitSeconds=25
'@

    Set-Content -LiteralPath $script:ConfigPath -Value $defaultConfig -Encoding ASCII
}

function Set-ConfigValue {
    param(
        [Parameter(Mandatory = $true)][string]$Name,
        [AllowEmptyString()][string]$Value
    )

    if (-not (Test-Path -LiteralPath $script:ConfigPath -PathType Leaf)) {
        New-DefaultConfigFile
    }

    $lines = @(Get-Content -LiteralPath $script:ConfigPath -ErrorAction Stop)
    $pattern = '^\s*' + [regex]::Escape($Name) + '\s*='
    $updated = $false
    $result = @()

    foreach ($line in $lines) {
        if ($line -match $pattern) {
            $result += "$Name=$Value"
            $updated = $true
        }
        else {
            $result += $line
        }
    }

    if (-not $updated) {
        if ($result.Count -gt 0 -and $result[$result.Count - 1].Trim().Length -ne 0) {
            $result += ''
        }
        $result += "$Name=$Value"
    }

    Set-Content -LiteralPath $script:ConfigPath -Value $result -Encoding ASCII
}

function Resolve-ConfigPath {
    param([Parameter(Mandatory = $true)][string]$PathValue)

    $expanded = [Environment]::ExpandEnvironmentVariables($PathValue.Trim())
    if ([string]::IsNullOrWhiteSpace($expanded)) {
        throw 'A path value in config.ini is empty.'
    }

    if ([System.IO.Path]::IsPathRooted($expanded)) {
        return [System.IO.Path]::GetFullPath($expanded)
    }

    return [System.IO.Path]::GetFullPath((Join-Path -Path $script:BaseDirectory -ChildPath $expanded))
}

function ConvertTo-ConfigBoolean {
    param(
        [Parameter(Mandatory = $true)][string]$Name,
        [Parameter(Mandatory = $true)][string]$Value
    )

    switch ($Value.Trim().ToLowerInvariant()) {
        'true' { return $true }
        'yes' { return $true }
        '1' { return $true }
        'false' { return $false }
        'no' { return $false }
        '0' { return $false }
        default { throw "Invalid boolean value for $Name in config.ini: $Value. Use true or false." }
    }
}

function ConvertTo-StorageType {
    param([Parameter(Mandatory = $true)][string]$Value)

    $normalized = $Value.Trim().ToUpperInvariant()
    $allowed = @('Unknown', 'ISO', 'VHD', 'VHDX', 'VHDSet')

    foreach ($candidate in $allowed) {
        if ($candidate.ToUpperInvariant() -eq $normalized) {
            return $candidate
        }
    }

    throw "Invalid ImageStorageType in config.ini: $Value. Use one of: $($allowed -join ', ')."
}

function Import-ToolConfig {
    if (-not (Test-Path -LiteralPath $script:ConfigPath -PathType Leaf)) {
        New-DefaultConfigFile
        Write-Warn "Created default config file: $script:ConfigPath"
    }

    $settings = @{}
    $lineNumber = 0

    foreach ($line in Get-Content -LiteralPath $script:ConfigPath -ErrorAction Stop) {
        $lineNumber++
        $trimmed = $line.Trim()

        if ($trimmed.Length -eq 0 -or $trimmed.StartsWith('#')) {
            continue
        }

        $separatorIndex = $trimmed.IndexOf('=')
        if ($separatorIndex -lt 1) {
            throw "Invalid config.ini line $lineNumber. Use Key=Value."
        }

        $key = $trimmed.Substring(0, $separatorIndex).Trim()
        $value = $trimmed.Substring($separatorIndex + 1).Trim()

        if ($key.Length -eq 0) {
            throw "Invalid config.ini line $lineNumber. The key is empty."
        }

        $settings[$key] = $value
    }

    if (-not $settings.ContainsKey('VhdxPath')) {
        throw 'config.ini is missing VhdxPath.'
    }

    $script:VhdxPath = Resolve-ConfigPath -PathValue $settings['VhdxPath']

    if ($settings.ContainsKey('ImageStorageType')) {
        $script:ImageStorageType = ConvertTo-StorageType -Value $settings['ImageStorageType']
    }
    else {
        $script:ImageStorageType = 'VHDX'
    }

    if ($settings.ContainsKey('PasswordSecret')) {
        $script:PasswordSecret = $settings['PasswordSecret'].Trim()
    }
    else {
        $script:PasswordSecret = ''
    }

    if ($settings.ContainsKey('SafeUnmountOnly')) {
        $script:SafeUnmountOnly = ConvertTo-ConfigBoolean -Name 'SafeUnmountOnly' -Value $settings['SafeUnmountOnly']
    }
    else {
        $script:SafeUnmountOnly = $true
    }

    if ($settings.ContainsKey('MountWaitSeconds')) {
        $waitSeconds = 0
        if (-not [int]::TryParse($settings['MountWaitSeconds'], [ref]$waitSeconds)) {
            throw "Invalid integer value for MountWaitSeconds in config.ini: $($settings['MountWaitSeconds'])."
        }
        if ($waitSeconds -lt 1 -or $waitSeconds -gt 300) {
            throw 'MountWaitSeconds in config.ini must be between 1 and 300.'
        }

        $script:MountWaitSeconds = $waitSeconds
    }
    else {
        $script:MountWaitSeconds = 25
    }
}

function Assert-VhdxExists {
    if (-not (Test-Path -LiteralPath $script:VhdxPath -PathType Leaf)) {
        throw "VHDX file not found: $script:VhdxPath. Edit VhdxPath in config.ini."
    }
}

function Assert-RequiredCommands {
    $requiredCommands = @(
        'Get-DiskImage',
        'Mount-DiskImage',
        'Dismount-DiskImage',
        'Get-Disk',
        'Get-Partition',
        'Get-Volume',
        'Get-BitLockerVolume',
        'Unlock-BitLocker',
        'Lock-BitLocker'
    )

    $missingCommands = @()
    foreach ($commandName in $requiredCommands) {
        if (-not (Get-Command -Name $commandName -ErrorAction SilentlyContinue)) {
            $missingCommands += $commandName
        }
    }

    if ($missingCommands.Count -gt 0) {
        throw "Missing required Windows commands: $($missingCommands -join ', '). This tool requires the built-in Storage and BitLocker PowerShell modules."
    }
}

function Assert-StatusCommands {
    $requiredCommands = @(
        'Get-DiskImage',
        'Get-Disk',
        'Get-Partition',
        'Get-Volume',
        'Get-BitLockerVolume'
    )

    $missingCommands = @()
    foreach ($commandName in $requiredCommands) {
        if (-not (Get-Command -Name $commandName -ErrorAction SilentlyContinue)) {
            $missingCommands += $commandName
        }
    }

    if ($missingCommands.Count -gt 0) {
        throw "Missing required Windows commands: $($missingCommands -join ', '). Status mode requires the built-in Storage and BitLocker PowerShell modules."
    }
}

function Test-SecureStringEqual {
    param(
        [Parameter(Mandatory = $true)][securestring]$Left,
        [Parameter(Mandatory = $true)][securestring]$Right
    )

    $leftPtr = [IntPtr]::Zero
    $rightPtr = [IntPtr]::Zero

    try {
        $leftPtr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Left)
        $rightPtr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Right)
        $leftText = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($leftPtr)
        $rightText = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($rightPtr)
        return [string]::Equals($leftText, $rightText, [StringComparison]::Ordinal)
    }
    finally {
        if ($leftPtr -ne [IntPtr]::Zero) {
            [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($leftPtr)
        }
        if ($rightPtr -ne [IntPtr]::Zero) {
            [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($rightPtr)
        }
    }
}

function Read-NewBitLockerPassword {
    while ($true) {
        $first = Read-Host 'Enter BitLocker password' -AsSecureString
        if ($first.Length -eq 0) {
            Write-Warn 'Password cannot be empty.'
            continue
        }

        $second = Read-Host 'Enter BitLocker password again' -AsSecureString
        if (Test-SecureStringEqual -Left $first -Right $second) {
            return $first
        }

        Write-Warn 'Passwords did not match. Please try again.'
    }
}

function Save-BitLockerPassword {
    param([Parameter(Mandatory = $true)][securestring]$Password)

    $script:PasswordSecret = ($Password | ConvertFrom-SecureString)
    Set-ConfigValue -Name 'PasswordSecret' -Value $script:PasswordSecret
}

function Set-NewStoredPassword {
    Write-Info 'Saving a new DPAPI-encrypted BitLocker password for this Windows user.'
    $password = Read-NewBitLockerPassword
    Save-BitLockerPassword -Password $password
    Write-Ok "Password saved in config.ini as PasswordSecret."
}

function Get-StoredPassword {
    if ([string]::IsNullOrWhiteSpace($script:PasswordSecret)) {
        Write-Warn 'No saved BitLocker password was found. This is expected on first run.'
        Set-NewStoredPassword
    }

    try {
        return ($script:PasswordSecret.Trim() | ConvertTo-SecureString -ErrorAction Stop)
    }
    catch {
        throw "Could not read saved password from config.ini. Run reset-password.cmd to save it again. Details: $($_.Exception.Message)"
    }
}

function Get-VhdxDiskImage {
    return Get-DiskImage -ImagePath $script:VhdxPath -StorageType $script:ImageStorageType -ErrorAction Stop
}

function Get-VhdxDisk {
    $image = Get-VhdxDiskImage
    if (-not $image.Attached) {
        return $null
    }

    try {
        return ($image | Get-Disk -ErrorAction Stop)
    }
    catch {
        return $null
    }
}

function Get-VhdxPartitions {
    $disk = Get-VhdxDisk
    if ($null -eq $disk) {
        return @()
    }

    return @(Get-Partition -DiskNumber $disk.Number -ErrorAction SilentlyContinue)
}

function Normalize-BitLockerMountPoint {
    param([Parameter(Mandatory = $true)][string]$MountPoint)

    $trimmed = $MountPoint.Trim()
    if ($trimmed -match '^[A-Za-z]:\\?$') {
        return $trimmed.Substring(0, 2).ToUpperInvariant()
    }

    return $trimmed
}

function Get-VhdxMountPoints {
    $points = @()

    foreach ($partition in Get-VhdxPartitions) {
        if ($partition.DriveLetter) {
            $points += "$($partition.DriveLetter):"
        }

        foreach ($accessPath in @($partition.AccessPaths)) {
            if (-not [string]::IsNullOrWhiteSpace($accessPath)) {
                $points += $accessPath
            }
        }

        try {
            $volumes = @($partition | Get-Volume -ErrorAction SilentlyContinue)
            foreach ($volume in $volumes) {
                if ($volume.DriveLetter) {
                    $points += "$($volume.DriveLetter):"
                }
                if (-not [string]::IsNullOrWhiteSpace($volume.Path)) {
                    $points += $volume.Path
                }
            }
        }
        catch {
            # Some locked or special partitions do not expose a regular volume yet.
        }
    }

    $points = @(
        $points |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) } |
            ForEach-Object { Normalize-BitLockerMountPoint -MountPoint $_ } |
            Select-Object -Unique
    )

    return $points
}

function Get-VhdxBitLockerVolumes {
    $volumes = @()
    $mountPoints = @(Get-VhdxMountPoints)

    foreach ($mountPoint in $mountPoints) {
        try {
            $volumes += @(Get-BitLockerVolume -MountPoint $mountPoint -ErrorAction Stop)
        }
        catch {
            # Not every partition/access path is expected to be BitLocker-managed.
        }
    }

    try {
        $knownPointSet = @{}
        foreach ($mountPoint in $mountPoints) {
            $knownPointSet[$mountPoint.ToUpperInvariant()] = $true
        }

        foreach ($volume in @(Get-BitLockerVolume -ErrorAction SilentlyContinue)) {
            if (-not [string]::IsNullOrWhiteSpace($volume.MountPoint)) {
                $candidate = (Normalize-BitLockerMountPoint -MountPoint $volume.MountPoint).ToUpperInvariant()
                if ($knownPointSet.ContainsKey($candidate)) {
                    $volumes += $volume
                }
            }
        }
    }
    catch {
        # The direct MountPoint lookup above is the primary path.
    }

    $unique = @{}
    $result = @()

    foreach ($volume in $volumes) {
        if ([string]::IsNullOrWhiteSpace($volume.MountPoint)) {
            continue
        }

        $key = (Normalize-BitLockerMountPoint -MountPoint $volume.MountPoint).ToUpperInvariant()
        if (-not $unique.ContainsKey($key)) {
            $unique[$key] = $true
            $result += $volume
        }
    }

    return $result
}

function Wait-VhdxBitLockerVolumes {
    $deadline = (Get-Date).AddSeconds($script:MountWaitSeconds)

    do {
        $volumes = @(Get-VhdxBitLockerVolumes)
        if ($volumes.Count -gt 0) {
            return $volumes
        }

        Start-Sleep -Seconds 1
    } while ((Get-Date) -lt $deadline)

    return @()
}

function Lock-VhdxBitLockerVolumes {
    $volumes = @(Get-VhdxBitLockerVolumes)

    if ($volumes.Count -eq 0) {
        Write-Warn 'No BitLocker volume was found inside the mounted VHDX. The image will still be dismounted.'
        return
    }

    foreach ($volume in $volumes) {
        $mountPoint = Normalize-BitLockerMountPoint -MountPoint $volume.MountPoint

        if ($volume.LockStatus -eq 'Locked') {
            Write-Info "BitLocker volume $mountPoint is already locked."
            continue
        }

        Write-Info "Locking BitLocker volume $mountPoint..."
        $lockParams = @{
            MountPoint  = $mountPoint
            ErrorAction = 'Stop'
            Confirm     = $false
        }

        if (-not $script:SafeUnmountOnly) {
            $lockParams['ForceDismount'] = $true
        }

        try {
            Lock-BitLocker @lockParams | Out-Null
            Write-Ok "Locked $mountPoint."
        }
        catch {
            throw "Could not lock $mountPoint. Close files or programs using the virtual disk, then run start.cmd again. Details: $($_.Exception.Message)"
        }
    }
}

function Unlock-VhdxBitLockerVolumes {
    $password = Get-StoredPassword
    $volumes = @(Wait-VhdxBitLockerVolumes)

    if ($volumes.Count -eq 0) {
        throw 'The VHDX mounted, but no BitLocker volume was found. Check that the VHDX contains a BitLocker-protected volume with a drive letter or mount point.'
    }

    foreach ($volume in $volumes) {
        $mountPoint = Normalize-BitLockerMountPoint -MountPoint $volume.MountPoint

        if ($volume.LockStatus -eq 'Unlocked') {
            Write-Info "BitLocker volume $mountPoint is already unlocked."
            continue
        }

        Write-Info "Unlocking BitLocker volume $mountPoint..."
        Unlock-BitLocker -MountPoint $mountPoint -Password $password -ErrorAction Stop | Out-Null
        Write-Ok "Unlocked $mountPoint."
    }

    $stillLocked = @(
        Get-VhdxBitLockerVolumes |
            Where-Object { $_.LockStatus -eq 'Locked' }
    )

    if ($stillLocked.Count -gt 0) {
        throw 'At least one BitLocker volume is still locked after the unlock attempt.'
    }
}

function Mount-AndUnlockVhdx {
    Write-Info "Mounting VHDX: $script:VhdxPath"
    $mountedHere = $false

    try {
        Mount-DiskImage -ImagePath $script:VhdxPath -StorageType $script:ImageStorageType -ErrorAction Stop | Out-Null
        $mountedHere = $true
        Write-Ok 'VHDX mounted.'

        Unlock-VhdxBitLockerVolumes
        Write-Ok 'Toggle complete: mounted and unlocked.'
    }
    catch {
        $originalMessage = $_.Exception.Message

        if ($mountedHere) {
            Write-Warn 'Unlock failed. Dismounting the VHDX to return to the previous state...'
            try {
                Dismount-DiskImage -ImagePath $script:VhdxPath -StorageType $script:ImageStorageType -ErrorAction Stop | Out-Null
                Write-Ok 'VHDX dismounted after failed unlock.'
            }
            catch {
                Write-Warn "Could not dismount after failed unlock: $($_.Exception.Message)"
            }
        }

        throw "Mount/unlock failed. $originalMessage If the BitLocker password changed, run reset-password.cmd."
    }
}

function Lock-AndDismountVhdx {
    Write-Info 'VHDX is already mounted. Switching it off...'

    Lock-VhdxBitLockerVolumes

    Write-Info 'Dismounting VHDX...'
    try {
        Dismount-DiskImage -ImagePath $script:VhdxPath -StorageType $script:ImageStorageType -ErrorAction Stop | Out-Null
        Write-Ok 'Toggle complete: locked and dismounted.'
    }
    catch {
        throw "The BitLocker volume was handled, but the VHDX could not be dismounted. Close any remaining windows or programs using it, then run start.cmd again. Details: $($_.Exception.Message)"
    }
}

function Invoke-Toggle {
    Assert-RequiredCommands
    Assert-VhdxExists

    $image = Get-VhdxDiskImage
    if ($image.Attached) {
        Lock-AndDismountVhdx
    }
    else {
        Mount-AndUnlockVhdx
    }
}

function Invoke-Status {
    Assert-StatusCommands
    Assert-VhdxExists

    Write-Host 'VHDX BitLocker status'
    Write-Host ''
    Write-StatusItem -Name 'Config file' -Value $script:ConfigPath
    Write-StatusItem -Name 'VHDX path' -Value $script:VhdxPath
    Write-StatusItem -Name 'Image storage type' -Value $script:ImageStorageType

    $image = Get-VhdxDiskImage
    if (-not $image.Attached) {
        Write-StatusItem -Name 'State' -Value 'Not mounted'
        Write-StatusItem -Name 'PasswordSecret saved' -Value (ConvertTo-StatusYesNo -Value (-not [string]::IsNullOrWhiteSpace($script:PasswordSecret)))
        return
    }

    Write-StatusItem -Name 'State' -Value 'Mounted'

    $disk = Get-VhdxDisk
    if ($null -eq $disk) {
        Write-StatusItem -Name 'Disk number' -Value 'Unknown'
    }
    else {
        Write-StatusItem -Name 'Disk number' -Value ([string]$disk.Number)
    }

    $mountPoints = @(Get-VhdxMountPoints)
    Write-StatusItem -Name 'Mount points' -Value (Format-StatusList -Values $mountPoints)

    $volumes = @(Get-VhdxBitLockerVolumes)
    if ($volumes.Count -eq 0) {
        Write-Warn 'No BitLocker volume was found inside the mounted VHDX. No lock or dismount action was performed.'
        return
    }

    Write-Host 'BitLocker volumes:'
    foreach ($volume in $volumes) {
        $mountPoint = '(unknown)'
        if (-not [string]::IsNullOrWhiteSpace($volume.MountPoint)) {
            $mountPoint = Normalize-BitLockerMountPoint -MountPoint $volume.MountPoint
        }

        Write-Host ("  MountPoint: {0}" -f $mountPoint)
        Write-Host ("    LockStatus: {0}" -f $volume.LockStatus)
        Write-Host ("    ProtectionStatus: {0}" -f $volume.ProtectionStatus)
        Write-Host ("    EncryptionPercentage: {0}" -f $volume.EncryptionPercentage)
    }
}

# =========================
# Main
# =========================
$exitCode = 0

try {
    Set-ConsoleTheme
    Import-ToolConfig

    if ($ResetPassword) {
        Set-NewStoredPassword
    }
    elseif ($Status) {
        if (-not (Test-IsAdministrator)) {
            Start-ElevatedSelf
        }
        else {
            Invoke-Status
        }
    }
    else {
        if (-not (Test-IsAdministrator)) {
            Start-ElevatedSelf
        }
        else {
            Invoke-Toggle
        }
    }
}
catch {
    $exitCode = 1
    Write-Fail $_.Exception.Message
}
finally {
    if ($PauseOnExit -or $exitCode -ne 0) {
        Write-Host ''
        Read-Host 'Press Enter to close this window' | Out-Null
    }
}

exit $exitCode
